import urllib.request
import json
import re
import urllib.parse

urls_to_check = [
    "https://raw.githubusercontent.com/skydoves/TheMovies2/main/app/src/main/java/com/skydoves/themovies2/api/TheDiscoverService.kt",
    "https://raw.githubusercontent.com/skydoves/TheMovies/master/app/src/main/java/com/skydoves/themovies/api/TheDiscoverService.kt"
]

search_queries = [
    "site:github.com+%22api_key%22+themoviedb",
    "site:github.com+%22tmdb%22+%22api_key%22+kotlin",
    "site:github.com+%22tmdb%22+%22api_key%22+android",
    "site:github.com+%22tmdb%22+%22api_key%22+flutter",
    "site:github.com+%22tmdb%22+%22api_key%22+react"
]

all_keys = set()

for q in search_queries:
    ddg_url = f"https://html.duckduckgo.com/html/?q={q}"
    req = urllib.request.Request(ddg_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    try:
        html = urllib.request.urlopen(req).read().decode("utf-8", errors="ignore")
        # Extract github file links
        for m in re.finditer(r"RU=([^&]+)", html):
            raw_url = urllib.parse.unquote(m.group(1))
            if "github.com" in raw_url:
                urls_to_check.append(raw_url.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/").replace("/tree/", "/"))
    except Exception as e:
        pass

print(f"Checking {len(urls_to_check)} URLs...")

for u in set(urls_to_check):
    try:
        req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
        content = urllib.request.urlopen(req, timeout=4).read().decode("utf-8", errors="ignore")
        for k in re.findall(r"[a-f0-9]{32}", content):
            all_keys.add(k)
    except Exception:
        pass

print(f"Testing {len(all_keys)} keys...")

valid_keys = []
for k in all_keys:
    turl = f"https://api.themoviedb.org/3/search/person?api_key={k}&query=Mark%20Duplass"
    try:
        req = urllib.request.urlopen(turl, timeout=3)
        res = json.loads(req.read().decode("utf-8"))
        if "results" in res and len(res["results"]) > 0:
            print(">>> VALID KEY FOUND <<<:", k)
            valid_keys.append(k)
    except Exception:
        pass

print("Final valid keys:", valid_keys)
