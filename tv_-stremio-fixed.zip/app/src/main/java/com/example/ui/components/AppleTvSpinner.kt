package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Authentic Apple TV+ / iOS radial activity indicator spinner with 12 rounded spokes and step fade animation.
 */
@Composable
fun AppleTvSpinner(
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    color: Color = Color.White,
    spokeCount: Int = 12
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AppleTvSpinnerTransition")
    
    val currentStepFloat by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = spokeCount.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "AppleTvSpinnerStep"
    )
    val currentStep = currentStepFloat.toInt() % spokeCount

    Canvas(modifier = modifier.size(size)) {
        val width = this.size.width
        val radius = width / 2f
        
        val spokeWidth = width * 0.082f
        val spokeLength = width * 0.25f
        val innerRadius = width * 0.22f

        for (i in 0 until spokeCount) {
            val angle = i * (360f / spokeCount)
            
            val stepDistance = (currentStep - i + spokeCount) % spokeCount
            val alpha = when (stepDistance) {
                0 -> 1.0f
                1 -> 0.88f
                2 -> 0.75f
                3 -> 0.62f
                4 -> 0.50f
                5 -> 0.38f
                6 -> 0.28f
                7 -> 0.20f
                else -> 0.12f
            }

            rotate(degrees = angle, pivot = Offset(radius, radius)) {
                drawRoundRect(
                    color = color.copy(alpha = alpha),
                    topLeft = Offset(radius - (spokeWidth / 2f), radius - innerRadius - spokeLength),
                    size = Size(spokeWidth, spokeLength),
                    cornerRadius = CornerRadius(spokeWidth / 2f, spokeWidth / 2f)
                )
            }
        }
    }
}
