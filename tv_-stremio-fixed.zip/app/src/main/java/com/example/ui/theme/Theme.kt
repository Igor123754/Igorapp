package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale

private val AppleTvColorScheme = darkColorScheme(
    primary = AppleWhite,
    secondary = AppleLightGray,
    tertiary = AppleAccentBlue,
    background = AppleBlack,
    surface = AppleCharcoal,
    onPrimary = AppleBlack,
    onSecondary = AppleWhite,
    onBackground = AppleWhite,
    onSurface = AppleWhite,
    surfaceVariant = AppleGray,
    onSurfaceVariant = AppleWhite
)

@Composable
fun AppleTvTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppleTvColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun Modifier.appleTvScaleEffect(
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() }
): Modifier {
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = when {
            isPressed -> 0.96f
            isHovered -> 1.05f
            else -> 1.0f
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "AppleTvScale"
    )

    return this
        .hoverable(interactionSource)
        .scale(scale)
}
