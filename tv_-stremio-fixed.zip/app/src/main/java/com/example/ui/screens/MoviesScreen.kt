package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WatchlistItem
import com.example.data.network.model.StremioMetaSummary
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleWhite
import com.example.viewmodel.HomeUiState
import com.example.viewmodel.HomeViewModel
import com.example.viewmodel.MainViewModel

private data class MovieCatalogRows(
    val popular: List<StremioMetaSummary>,
    val animation: List<StremioMetaSummary>,
    val family: List<StremioMetaSummary>,
    val action: List<StremioMetaSummary>,
    val sciFi: List<StremioMetaSummary>,
    val drama: List<StremioMetaSummary>,
    val thriller: List<StremioMetaSummary>,
    val comedy: List<StremioMetaSummary>,
    val horror: List<StremioMetaSummary>,
    val adventure: List<StremioMetaSummary>
)

@Composable
fun MoviesScreen(
    mainViewModel: MainViewModel,
    homeViewModel: HomeViewModel,
    onNavigateToDetail: (String, String) -> Unit
) {
    val homeState by homeViewModel.uiState.collectAsState()
    val watchlist by mainViewModel.watchlist.collectAsState()
    val addons by mainViewModel.addons.collectAsState()
    val continueWatchingList by mainViewModel.continueWatchingList.collectAsState()
    val currentLang by mainViewModel.currentLanguage.collectAsState()

    LaunchedEffect(addons, currentLang) {
        val activeCatalog = addons.firstOrNull { it.isActive && (it.type == "catalog" || it.type == "both") }
        homeViewModel.loadContent(activeCatalog?.url)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppleBlack)
    ) {
        when (val state = homeState) {
            is HomeUiState.Loading -> {
                HomeShimmerSkeleton()
            }
            is HomeUiState.Error -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    androidx.compose.material3.Text(
                        text = "Greška pri učitavanju filmova",
                        color = AppleWhite,
                        fontSize = 16.sp
                    )
                }
            }
            is HomeUiState.Success -> {
                // Combine all movies from various lists
                val allMovies = remember(state.popularMovies, state.tmdbTop10Movies, state.featuredItems) {
                    (state.popularMovies + state.tmdbTop10Movies + state.featuredItems.filter { it.type == "movie" })
                        .distinctBy { it.id }
                        .filter { it.type == "movie" }
                }

                // Featured movies for Hero Carousel
                val movieFeatured = remember(allMovies, state.featuredItems) {
                    val fromFeatured = state.featuredItems.filter { it.type == "movie" }
                    if (fromFeatured.isNotEmpty()) fromFeatured else allMovies.take(5)
                }

                val movieWatchlist = remember(watchlist) {
                    watchlist.filter { it.type == "movie" }
                }

                val movieContinueWatching = remember(continueWatchingList) {
                    continueWatchingList.filter { it.type == "movie" }
                }

                // Strictly deduplicated catalog rows across categories
                val catalogRows = remember(allMovies) {
                    val usedIds = mutableSetOf<String>()

                    fun getGenreItems(genreKeys: List<String>, limit: Int = 25): List<StremioMetaSummary> {
                        var items = allMovies.filter { item ->
                            item.id !in usedIds && genreKeys.any { g -> getGenresForMeta(item).contains(g) }
                        }.take(limit)

                        // Fallback if strict deduplication left fewer than 3 items: allow matching items even if used, but prioritizing unused
                        if (items.size < 3) {
                            val extra = allMovies.filter { item ->
                                genreKeys.any { g -> getGenresForMeta(item).contains(g) }
                            }.distinctBy { it.id }
                            items = (items + extra).distinctBy { it.id }.take(limit)
                        }

                        items.forEach { usedIds.add(it.id) }
                        return items
                    }

                    val pop = allMovies.take(10)
                    pop.forEach { usedIds.add(it.id) }

                    val anim = getGenreItems(listOf("Animacija", "Crtani"))
                    val fam = getGenreItems(listOf("Porodični", "Porodicni"))
                    val act = getGenreItems(listOf("Akcija"))
                    val sci = getGenreItems(listOf("Sci-Fi"))
                    val dra = getGenreItems(listOf("Drama"))
                    val thr = getGenreItems(listOf("Triler"))
                    val com = getGenreItems(listOf("Komedija"))
                    val hor = getGenreItems(listOf("Horor"))
                    val adv = getGenreItems(listOf("Avantura"))

                    MovieCatalogRows(
                        popular = pop,
                        animation = anim,
                        family = fam,
                        action = act,
                        sciFi = sci,
                        drama = dra,
                        thriller = thr,
                        comedy = com,
                        horror = hor,
                        adventure = adv
                    )
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    // 1. Featured Hero Banner Carousel for Movies
                    if (movieFeatured.isNotEmpty()) {
                        item {
                            HeroCarouselBanner(
                                items = movieFeatured,
                                watchlist = watchlist,
                                onPlayClick = { featuredMovie ->
                                    onNavigateToDetail(featuredMovie.type, featuredMovie.id)
                                },
                                onWatchlistToggle = { featuredMovie ->
                                    val isInList = watchlist.any { it.id == featuredMovie.id }
                                    mainViewModel.toggleWatchlist(
                                        WatchlistItem(
                                            id = featuredMovie.id,
                                            title = featuredMovie.name,
                                            type = featuredMovie.type,
                                            poster = featuredMovie.poster,
                                            backdrop = featuredMovie.background,
                                            year = featuredMovie.releaseInfo,
                                            rating = featuredMovie.imdbRating
                                        ),
                                        isInList
                                    )
                                },
                                onClick = { featuredMovie ->
                                    onNavigateToDetail(featuredMovie.type, featuredMovie.id)
                                }
                            )
                        }
                    }

                    // 2. Continue Watching (Movies)
                    if (movieContinueWatching.isNotEmpty()) {
                        item {
                            ContinueWatchingRow(
                                list = movieContinueWatching,
                                onNavigateToDetail = onNavigateToDetail,
                                onRemoveItem = { id -> mainViewModel.removeFromContinueWatching(id) }
                            )
                        }
                    }

                    // 3. Watchlist (Movies)
                    if (movieWatchlist.isNotEmpty()) {
                        item {
                            WatchlistRow(
                                list = movieWatchlist,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // Domaci Filmovi
                    if (state.domaciMovies.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Домаћи Филмови",
                                items = state.domaciMovies,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 4. Popular Movies
                    if (catalogRows.popular.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Najpopularniji Filmovi",
                                items = catalogRows.popular,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 5. Crtani & Animirani Filmovi
                    if (catalogRows.animation.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Crtani & Animirani Filmovi",
                                items = catalogRows.animation,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 6. Porodični Filmovi
                    if (catalogRows.family.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Porodični Filmovi",
                                items = catalogRows.family,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 7. Akcioni Filmovi
                    if (catalogRows.action.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Akcioni Filmovi",
                                items = catalogRows.action,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 8. Sci-Fi & Fantazija
                    if (catalogRows.sciFi.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Sci-Fi & Fantazija",
                                items = catalogRows.sciFi,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 9. Filmske Drame
                    if (catalogRows.drama.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Filmske Drame",
                                items = catalogRows.drama,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 10. Trileri & Kriminal
                    if (catalogRows.thriller.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Trileri & Kriminal",
                                items = catalogRows.thriller,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 11. Filmske Komedije
                    if (catalogRows.comedy.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Filmske Komedije",
                                items = catalogRows.comedy,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 12. Horor Filmovi
                    if (catalogRows.horror.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Horor Filmovi",
                                items = catalogRows.horror,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 13. Avanturistički Filmovi
                    if (catalogRows.adventure.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Avanturistički Filmovi",
                                items = catalogRows.adventure,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }
                }
            }
        }
    }
}
