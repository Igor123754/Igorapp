package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AppleBlack = Color(0xFF0D0D0D) // Elegant Dark base background (#0D0D0D)
val AppleCharcoal = Color(0xFF161616) // Elegant Dark surface/navigation (#161616)
val AppleGray = Color(0xFF222222) // Intermediate dark element surface
val AppleLightGray = Color(0xCCFFFFFF) // white/80 secondary text
val AppleWhite = Color(0xFFFFFFFF)
val AppleAccentBlue = Color(0xFF0A84FF)
val AppleAccentPink = Color(0xFFFF2D55)

// Transparent variations and gradients matching Elegant Dark
val AppleSurfaceTransparent = Color(0xCC161616) // #161616 with 80% opacity for glassmorphism
val AppleScrimGradientStart = Color(0x000D0D0D)
val AppleScrimGradientEnd = Color(0xFF0D0D0D)
val AppleCardHoverGlow = Color(0xFF2C2C2E)

// Elegant Dark exact opacity variables for fine-tuning
val WhiteOpacity5 = Color(0x0DFFFFFF)
val WhiteOpacity10 = Color(0x1AFFFFFF)
val WhiteOpacity20 = Color(0x33FFFFFF)
val WhiteOpacity40 = Color(0x66FFFFFF)
val WhiteOpacity60 = Color(0x99FFFFFF)
val WhiteOpacity80 = Color(0xCCFFFFFF)

