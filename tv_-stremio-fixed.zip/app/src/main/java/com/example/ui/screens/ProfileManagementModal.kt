package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.AvatarCatalog
import com.example.data.model.AvatarItem
import com.example.data.model.UserProfile
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleCharcoal
import com.example.ui.theme.AppleLightGray
import com.example.ui.theme.AppleWhite
import com.example.viewmodel.MainViewModel

/**
 * Screen 1: "Who's Watching?" ("Ko gleda?") Modal / Dialog
 */
@Composable
fun WhosWatchingDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit,
    onEditProfileRequested: (UserProfile?) -> Unit
) {
    val profiles by mainViewModel.allProfiles.collectAsState()
    val activeProfile by mainViewModel.activeProfile.collectAsState()
    val context = LocalContext.current

    var selectedForPin by remember { mutableStateOf<UserProfile?>(null) }
    var pinError by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = AppleBlack
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF2A0000).copy(alpha = 0.35f),
                                AppleBlack,
                                AppleBlack
                            )
                        )
                    )
                    .statusBarsPadding()
                    .padding(24.dp)
            ) {
                // Top Right Close Button
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Zatvori",
                        tint = AppleWhite
                    )
                }

                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Ko gleda?",
                        color = AppleWhite,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(32.dp))

                    // Profiles Grid / Row (Max 6)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        profiles.take(6).forEach { profile ->
                            val isCurrent = profile.id == activeProfile?.id
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    if (!profile.pin.isNullOrEmpty()) {
                                        selectedForPin = profile
                                    } else {
                                        mainViewModel.selectProfile(profile)
                                        Toast.makeText(context, "Profil: ${profile.name}", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    }
                                }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .border(
                                            width = if (isCurrent) 3.dp else 1.5.dp,
                                            color = if (isCurrent) Color(0xFFE50914) else Color.White.copy(alpha = 0.2f),
                                            shape = CircleShape
                                        )
                                        .background(AppleCharcoal),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = profile.avatarUrl,
                                        contentDescription = profile.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )

                                    if (!profile.pin.isNullOrEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(AppleBlack.copy(alpha = 0.85f))
                                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Lock,
                                                contentDescription = "PIN",
                                                tint = AppleWhite,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = profile.name,
                                    color = AppleWhite,
                                    fontSize = 16.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }

                        // Add Profile Button if count < 6
                        if (profiles.size < 6) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    onEditProfileRequested(null)
                                }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                                        .background(AppleCharcoal),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Dodaj profil",
                                        tint = AppleLightGray,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Dodaj profil",
                                    color = AppleLightGray,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))

                    // Manage Profiles Button
                    Button(
                        onClick = {
                            onEditProfileRequested(activeProfile)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent,
                            contentColor = AppleLightGray
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                            .padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = "Upravljanje profilima",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    // PIN Prompt Dialog if selecting locked profile
    selectedForPin?.let { targetProfile ->
        PinVerificationDialog(
            profileName = targetProfile.name,
            onPinSubmitted = { enteredPin ->
                if (targetProfile.pin == enteredPin) {
                    mainViewModel.selectProfile(targetProfile)
                    selectedForPin = null
                    Toast.makeText(context, "Dobrodošli, ${targetProfile.name}!", Toast.LENGTH_SHORT).show()
                    onDismiss()
                } else {
                    pinError = true
                }
            },
            onDismiss = { selectedForPin = null },
            hasError = pinError
        )
    }
}

/**
 * Screen 2: PIN Verification Overlay
 */
@Composable
fun PinVerificationDialog(
    profileName: String,
    onPinSubmitted: (String) -> Unit,
    onDismiss: () -> Unit,
    hasError: Boolean
) {
    var pinValue by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = AppleCharcoal,
            modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = AppleWhite,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Unesite PIN za profil $profileName",
                    color = AppleWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Ovaj profil je zaštićen sigurnosnim kodom.",
                    color = AppleLightGray,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = pinValue,
                    onValueChange = {
                        if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                            pinValue = it
                        }
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleWhite,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedTextColor = AppleWhite,
                        unfocusedTextColor = AppleWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pin_input_field")
                )

                if (hasError) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Netačan PIN. Pokušajte ponovo.",
                        color = Color(0xFFEF5350),
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(text = "Otkaži", color = AppleLightGray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onPinSubmitted(pinValue) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AppleWhite,
                            contentColor = AppleBlack
                        ),
                        enabled = pinValue.length >= 4,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "Potvrdi", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Screen 3: "Edit Profile" / "Add Profile" Screen
 */
@Composable
fun EditProfileDialog(
    profileToEdit: UserProfile?,
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var profileName by remember { mutableStateOf(profileToEdit?.name ?: "") }
    var selectedAvatarUrl by remember { mutableStateOf(profileToEdit?.avatarUrl ?: AvatarCatalog.defaultAvatar.url) }
    var customAvatarUrl by remember { mutableStateOf("") }
    var pinCode by remember { mutableStateOf(profileToEdit?.pin ?: "") }
    var enablePinLock by remember { mutableStateOf(!profileToEdit?.pin.isNullOrEmpty()) }

    val isEditing = profileToEdit != null

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = AppleBlack
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AppleBlack)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Bar
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            IconButton(onClick = onDismiss) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Nazad",
                                    tint = AppleWhite
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isEditing) "Izmeni Profil" else "Novi Profil",
                                color = AppleWhite,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    // Top Preview Card
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(AppleCharcoal)
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, Color(0xFFE50914), CircleShape)
                                    .background(AppleBlack)
                            ) {
                                AsyncImage(
                                    model = if (customAvatarUrl.isNotBlank()) customAvatarUrl else selectedAvatarUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = if (profileName.isBlank()) "Naziv profila" else profileName,
                                    color = AppleWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (profileToEdit?.isPrimary == true) "Glavni profil" else "Korisnički profil",
                                    color = AppleLightGray,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "Slika: ${AvatarCatalog.avatars.find { it.url == selectedAvatarUrl }?.name ?: "Prilagođena"}",
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Profile Name Input
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(AppleCharcoal)
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Ime profila",
                                color = AppleWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = profileName,
                                onValueChange = { profileName = it },
                                placeholder = { Text("Unesite ime profila", color = AppleLightGray) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AppleWhite,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                    focusedTextColor = AppleWhite,
                                    unfocusedTextColor = AppleWhite
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // Custom Avatar URL
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(AppleCharcoal)
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Provoljna slika (URL link)",
                                color = AppleWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Možete uneti sopstveni link do slike ili izabrati lik iz galerije ispod.",
                                color = AppleLightGray,
                                fontSize = 11.5.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = customAvatarUrl,
                                onValueChange = { customAvatarUrl = it },
                                placeholder = { Text("https://example.com/avatar.png", color = AppleLightGray) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AppleWhite,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                    focusedTextColor = AppleWhite,
                                    unfocusedTextColor = AppleWhite
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // Avatar Selection Grid
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(AppleCharcoal)
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Izaberite sliku ili animirani lik",
                                color = AppleWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Grid of Avatar Choices
                            Box(modifier = Modifier.height(280.dp)) {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(5),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(AvatarCatalog.avatars) { avatar ->
                                        val isSelected = selectedAvatarUrl == avatar.url && customAvatarUrl.isBlank()
                                        Box(
                                            modifier = Modifier
                                                .size(54.dp)
                                                .clip(CircleShape)
                                                .border(
                                                    width = if (isSelected) 2.5.dp else 1.dp,
                                                    color = if (isSelected) Color(0xFFE50914) else Color.White.copy(alpha = 0.15f),
                                                    shape = CircleShape
                                                )
                                                .clickable {
                                                    selectedAvatarUrl = avatar.url
                                                    customAvatarUrl = ""
                                                }
                                                .background(AppleBlack),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AsyncImage(
                                                model = avatar.url,
                                                contentDescription = avatar.name,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Security & PIN Section
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(AppleCharcoal)
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Zaštita PIN kodom",
                                        color = AppleWhite,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Zaključajte profil tako da drugi korisnici ne mogu gledati sadržaj bez PIN-a.",
                                        color = AppleLightGray,
                                        fontSize = 11.5.sp
                                    )
                                }
                                androidx.compose.material3.Switch(
                                    checked = enablePinLock,
                                    onCheckedChange = { enablePinLock = it }
                                )
                            }

                            if (enablePinLock) {
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = pinCode,
                                    onValueChange = {
                                        if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                                            pinCode = it
                                        }
                                    },
                                    placeholder = { Text("Unesite 4 cifre za PIN", color = AppleLightGray) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AppleWhite,
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                        focusedTextColor = AppleWhite,
                                        unfocusedTextColor = AppleWhite
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    // Save / Delete Actions
                    item {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    val finalAvatar = if (customAvatarUrl.isNotBlank()) customAvatarUrl else selectedAvatarUrl
                                    val finalPin = if (enablePinLock && pinCode.length == 4) pinCode else null

                                    if (profileName.isBlank()) {
                                        Toast.makeText(context, "Unesite ime profila", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }

                                    if (isEditing && profileToEdit != null) {
                                        val updated = profileToEdit.copy(
                                            name = profileName,
                                            avatarUrl = finalAvatar,
                                            pin = finalPin
                                        )
                                        mainViewModel.updateProfile(updated)
                                        Toast.makeText(context, "Profil sačuvan!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        mainViewModel.createProfile(
                                            name = profileName,
                                            avatarUrl = finalAvatar,
                                            pin = finalPin
                                        )
                                        Toast.makeText(context, "Novi profil kreiran!", Toast.LENGTH_SHORT).show()
                                    }
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AppleWhite,
                                    contentColor = AppleBlack
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                Text(
                                    text = if (isEditing) "Sačuvaj izmene" else "Kreiraj profil",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (isEditing && profileToEdit != null && !profileToEdit.isPrimary) {
                                Button(
                                    onClick = {
                                        mainViewModel.deleteProfile(profileToEdit)
                                        Toast.makeText(context, "Profil je obrisan", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFD32F2F).copy(alpha = 0.2f),
                                        contentColor = Color(0xFFEF5350)
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = "Obriši profil", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(40.dp))
                    }
                }
            }
        }
    }
}
