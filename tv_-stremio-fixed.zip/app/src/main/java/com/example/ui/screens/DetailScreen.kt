package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import com.example.data.network.model.CastMember
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import com.example.ui.components.AppleTvSpinner
import com.example.ui.theme.AppleAccentBlue
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.core.tween
import com.example.trailer.InAppYouTubeExtractor
import com.example.trailer.TrailerPlaybackSource
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.WatchlistItem
import com.example.data.network.model.StremioMetaDetail
import com.example.data.network.model.StremioMetaSummary
import com.example.data.network.model.StremioStream
import com.example.data.network.model.StremioVideo
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleCharcoal
import com.example.ui.theme.AppleLightGray
import com.example.ui.theme.AppleWhite
import com.example.ui.theme.appleTvScaleEffect
import com.example.viewmodel.DetailUiState
import com.example.viewmodel.DetailViewModel
import com.example.viewmodel.MainViewModel

@Composable
fun DetailScreen(
    type: String,
    id: String,
    mainViewModel: MainViewModel,
    detailViewModel: DetailViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val detailState by detailViewModel.uiState.collectAsState()
    val watchlist by mainViewModel.watchlist.collectAsState()
    val addons by mainViewModel.addons.collectAsState()

    var showStreamPicker by remember { mutableStateOf(false) }
    var showExtendedOverview by remember { mutableStateOf(false) }

    // Load details and streams
    LaunchedEffect(type, id, addons) {
        val streamAddons = addons.filter { it.isActive && (it.type == "stream" || it.type == "both") }.map { it.url }
        detailViewModel.loadDetails(type, id, streamAddons)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("detail_screen_root")
    ) {
        when (val state = detailState) {
            is DetailUiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AppleTvSpinner(size = 40.dp, color = AppleWhite)
                }
            }
            is DetailUiState.Error -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Greška: ${state.message}", color = AppleLightGray, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onBack) {
                            Text("Nazad")
                        }
                    }
                }
            }
            is DetailUiState.Success -> {
                val meta = state.meta
                val isInWatchlist = watchlist.any { it.id == meta.id }
                var selectedVideo by remember { mutableStateOf<StremioVideo?>(null) }

                var isTrailerPlaying by remember { mutableStateOf(false) }
                var isMuted by remember { mutableStateOf(true) }
                var showTrailerModal by remember { mutableStateOf(false) }
                val trailerYtId = remember(meta) { getTrailerYtId(meta) }
                val fallbackVideoUrl = remember(meta) { getTrailerVideoUrl(meta) }
                var resolvedTrailerSource by remember(meta.id) {
                    mutableStateOf<TrailerPlaybackSource?>(null)
                }

                LaunchedEffect(meta.id, trailerYtId, fallbackVideoUrl) {
                    val ytInput = when {
                        trailerYtId.isNotBlank() -> trailerYtId
                        !fallbackVideoUrl.isNullOrBlank() && (fallbackVideoUrl.contains("youtube") || fallbackVideoUrl.contains("youtu.be")) -> fallbackVideoUrl
                        else -> null
                    }

                    if (ytInput != null) {
                        val extracted = withContext(Dispatchers.IO) {
                            runCatching { InAppYouTubeExtractor().extractPlaybackSource(ytInput) }.getOrNull()
                        }
                        if (extracted != null && extracted.videoUrl.isNotBlank()) {
                            resolvedTrailerSource = extracted.copy(youtubeId = trailerYtId.ifBlank { null })
                        } else if (!fallbackVideoUrl.isNullOrBlank()) {
                            resolvedTrailerSource = TrailerPlaybackSource(
                                videoUrl = fallbackVideoUrl,
                                youtubeId = trailerYtId.ifBlank { null }
                            )
                        } else {
                            resolvedTrailerSource = TrailerPlaybackSource(
                                videoUrl = "",
                                youtubeId = trailerYtId.ifBlank { null }
                            )
                        }
                    } else if (!fallbackVideoUrl.isNullOrBlank()) {
                        resolvedTrailerSource = TrailerPlaybackSource(
                            videoUrl = fallbackVideoUrl,
                            youtubeId = null
                        )
                    } else {
                        resolvedTrailerSource = null
                    }
                }

                // Auto select last watched episode or first episode for TV series
                val continueItem by androidx.compose.runtime.produceState<com.example.data.model.ContinueWatchingItem?>(initialValue = null, meta.id) {
                    value = mainViewModel.continueWatchingRepository.getContinueWatchingItem(meta.id)
                }

                LaunchedEffect(state.filteredEpisodes, continueItem) {
                    if (type == "series" && state.filteredEpisodes.isNotEmpty()) {
                        val savedVideoId = continueItem?.lastPlayedVideoId
                        val savedSeason = continueItem?.season
                        val savedEpisode = continueItem?.episode
                        val matchingEp = state.filteredEpisodes.find { ep ->
                            (savedVideoId != null && ep.id == savedVideoId) ||
                            (savedSeason != null && savedEpisode != null && ep.season == savedSeason && ep.episode == savedEpisode)
                        }
                        if (matchingEp != null) {
                            selectedVideo = matchingEp
                        } else if (selectedVideo == null || !state.filteredEpisodes.contains(selectedVideo)) {
                            selectedVideo = state.filteredEpisodes.firstOrNull()
                        }
                    }
                }

                // Start trailer automatically after 5 seconds of staying on detail page
                LaunchedEffect(meta.id) {
                    delay(5000)
                    isTrailerPlaying = true
                }

                val activeStreams = if (type == "series") state.streamsForActiveVideo else state.streams
                val context = LocalContext.current
                val scope = rememberCoroutineScope()
                val streamAddonUrls = remember(addons) { addons.filter { it.isActive && (it.type == "stream" || it.type == "both") }.map { it.url } }
                var isAutoPlaying by remember { mutableStateOf(false) }

                val handleDirectPlay: (StremioVideo?) -> Unit = { video ->
                    if (!isAutoPlaying) {
                        isAutoPlaying = true
                        scope.launch {
                            try {
                                val isSeries = type == "series" || type == "tv" || type == "show" || meta.type == "series"
                                val targetQueryId = video?.id
                                    ?: (if (isSeries && state.filteredEpisodes.isNotEmpty()) state.filteredEpisodes.first().id else meta.id)
                                val targetType = if (isSeries) "series" else "movie"

                                // Directly fetch streams for the target episode query ID to guarantee stream accuracy
                                var streamsToUse = detailViewModel.fetchStreamsDirect(targetType, targetQueryId, streamAddonUrls)

                                if (streamsToUse.isEmpty() || streamsToUse.none { !it.url.isNullOrBlank() }) {
                                    streamsToUse = if (video != null) {
                                        state.streamsForActiveVideo
                                    } else if (isSeries) {
                                        state.streamsForActiveVideo.ifEmpty { state.streams }
                                    } else {
                                        state.streams
                                    }
                                }

                                val validStream = streamsToUse.firstOrNull { !it.url.isNullOrBlank() }
                                if (validStream != null && !validStream.url.isNullOrBlank()) {
                                    val playTitle = when {
                                        video != null -> "${meta.name} - ${video.title ?: "S${video.season}E${video.episode}"}"
                                        isSeries && state.filteredEpisodes.isNotEmpty() -> {
                                            val ep = state.filteredEpisodes.first()
                                            "${meta.name} - ${ep.title ?: "S${ep.season}E${ep.episode}"}"
                                        }
                                        else -> meta.name
                                    }

                                    val streamHeaders = validStream.behaviorHints?.headers ?: validStream.headers

                                    mainViewModel.playVideo(
                                        title = playTitle,
                                        url = validStream.url!!,
                                        mediaId = video?.id ?: meta.id,
                                        headers = streamHeaders,
                                        availableStreams = streamsToUse,
                                        metaName = meta.name,
                                        metaType = meta.type,
                                        poster = meta.poster,
                                        backdrop = meta.background,
                                        logoUrl = meta.logo,
                                        year = meta.year,
                                        rating = meta.imdbRating,
                                        season = video?.season ?: (if (isSeries) state.filteredEpisodes.firstOrNull()?.season else null),
                                        episode = video?.episode ?: (if (isSeries) state.filteredEpisodes.firstOrNull()?.episode else null),
                                        episodeId = video?.id ?: (if (isSeries) state.filteredEpisodes.firstOrNull()?.id else null)
                                    )
                                } else {
                                    showStreamPicker = true
                                }
                            } catch (e: Exception) {
                                showStreamPicker = true
                            } finally {
                                isAutoPlaying = false
                            }
                        }
                    }
                }
                val configuration = LocalConfiguration.current
                val screenHeight = configuration.screenHeightDp.dp
                val scrollState = rememberScrollState()

                val isValidLogo = remember(meta.logo) {
                    !meta.logo.isNullOrBlank() && meta.logo != "null" && meta.logo != "undefined" && meta.logo != "none"
                }
                var heroLogoFailed by remember(meta.logo) { mutableStateOf(false) }
                var stickyLogoFailed by remember(meta.logo) { mutableStateOf(false) }

                val scrollPx = scrollState.value.toFloat()
                val headerBgAlpha = (scrollPx / 250f).coerceIn(0f, 0.92f)
                val stickyLogoAlpha = ((scrollPx - 100f) / 180f).coerceIn(0f, 1f)

                val initialHeroImage = remember(meta.background, meta.poster) {
                    val bg = meta.background?.trim()
                    if (!bg.isNullOrBlank() && bg != "null" && bg != "undefined" && bg != "none") {
                        bg
                    } else {
                        meta.poster
                    }
                }
                var heroImageModel by remember(initialHeroImage) { mutableStateOf(initialHeroImage) }
                val heroContext = LocalContext.current

                Box(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                    ) {
                        // 1. HERO BANNER (100% SCREEN HEIGHT)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(screenHeight)
                                .background(AppleBlack)
                        ) {
                            // Single smooth Hero Image with Crossfade transition (no double layers or zoom glitches)
                            if (!heroImageModel.isNullOrBlank()) {
                                AsyncImage(
                                    model = ImageRequest.Builder(heroContext)
                                        .data(heroImageModel)
                                        .crossfade(250)
                                        .build(),
                                    contentDescription = meta.name,
                                    contentScale = ContentScale.Crop,
                                    onError = {
                                        if (heroImageModel != meta.poster && !meta.poster.isNullOrBlank()) {
                                            heroImageModel = meta.poster
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            // VIDEO TRAILER OVERLAY (fades in gracefully over backdrop when first frame is rendered)
                            if (isTrailerPlaying && resolvedTrailerSource != null) {
                                TrailerVideoPlayer(
                                    playbackSource = resolvedTrailerSource!!,
                                    isMuted = isMuted,
                                    onError = {
                                        if (resolvedTrailerSource?.videoUrl != fallbackVideoUrl) {
                                            resolvedTrailerSource = TrailerPlaybackSource(videoUrl = fallbackVideoUrl)
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            // Multi-stage Gradient Overlay to ensure crisp contrast
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Black.copy(alpha = 0.45f),
                                                Color.Black.copy(alpha = 0.15f),
                                                Color.Black.copy(alpha = 0.55f),
                                                Color.Black.copy(alpha = 0.92f),
                                                Color.Black
                                            ),
                                            startY = 0f
                                        )
                                    )
                            )

                            // MAIN CENTER-BOTTOM CONTENT
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // A. Dynamic Badge Overlay (e.g. "2025 Oscar® Winner" or IMDb rating highlight)
                                val dynamicBadgeText = remember(meta) {
                                    val year = meta.releaseInfo ?: "2025"
                                    val rating = meta.imdbRating?.toFloatOrNull() ?: 0f
                                    val genre = meta.genres?.firstOrNull() ?: if (meta.type == "series") "Drama" else "Action"
                                    when {
                                        rating >= 8.2f -> "IMDb Top Rated ★ $rating"
                                        rating >= 7.5f -> "Trending Worldwide • $genre"
                                        year.contains("2026") || year.contains("2025") -> "$year Oscar® Winner"
                                        else -> "Featured Selection • $genre"
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                                        .border(1.2.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                                        .padding(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = dynamicBadgeText,
                                        color = AppleWhite,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                }

                                // B. ClearLogo from TMDB/Stremio or Apple TV+ styled title text
                                if (isValidLogo && !heroLogoFailed) {
                                    AsyncImage(
                                        model = meta.logo,
                                        contentDescription = meta.name,
                                        contentScale = ContentScale.Fit,
                                        onError = { heroLogoFailed = true },
                                        modifier = Modifier
                                            .height(76.dp)
                                            .fillMaxWidth(0.85f)
                                            .padding(vertical = 4.dp)
                                    )
                                } else {
                                    AppleTvTitleStyle(
                                        title = meta.name,
                                        fontSize = 32.sp,
                                        maxLines = 2
                                    )
                                }

                            // C. Movie Info Line (Removed Apple TV+ badge)
                            val mediaTypeLabel = if (meta.type == "series") "TV Series" else "Movie"
                            val genresText = meta.genres?.take(2)?.joinToString(" · ") ?: "Action · Drama"
                            val pgRating = meta.getEffectiveCertification()

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "$mediaTypeLabel · $genresText",
                                    color = AppleWhite.copy(alpha = 0.85f),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Box(
                                    modifier = Modifier
                                        .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = pgRating,
                                        color = AppleWhite.copy(alpha = 0.85f),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // D. Action Buttons Row (PLAY, TREJLER & WATCHLIST "+")
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp)
                            ) {
                                Button(
                                    onClick = { handleDirectPlay(selectedVideo) },
                                    shape = CircleShape,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AppleWhite,
                                        contentColor = Color.Black
                                    ),
                                    contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp),
                                    modifier = Modifier
                                        .height(52.dp)
                                        .testTag("detail_play_button")
                                ) {
                                    if (isAutoPlaying) {
                                        AppleTvSpinner(
                                            size = 20.dp,
                                            color = Color.Black
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Pusti",
                                            tint = Color.Black,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text(
                                        text = if (isAutoPlaying) "Provera..." else "Play",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Button(
                                    onClick = {
                                        isTrailerPlaying = true
                                        isMuted = false
                                        showTrailerModal = true
                                    },
                                    shape = CircleShape,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White.copy(alpha = 0.22f),
                                        contentColor = AppleWhite
                                    ),
                                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
                                    modifier = Modifier
                                        .height(52.dp)
                                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                                        .testTag("detail_trailer_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Trejler",
                                        tint = AppleWhite,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Trejler",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.18f))
                                        .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                                        .clickable {
                                            showStreamPicker = true
                                        }
                                        .testTag("detail_sources_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tv,
                                        contentDescription = "Izvori",
                                        tint = AppleWhite,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.18f))
                                        .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                                        .clickable {
                                            mainViewModel.toggleWatchlist(
                                                WatchlistItem(
                                                    id = meta.id,
                                                    title = meta.name,
                                                    type = meta.type,
                                                    poster = meta.poster,
                                                    backdrop = meta.background,
                                                    year = meta.releaseInfo,
                                                    rating = meta.imdbRating
                                                ),
                                                isInWatchlist
                                            )
                                        }
                                        .testTag("save_to_watchlist_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isInWatchlist) Icons.Default.Check else Icons.Default.Add,
                                        contentDescription = "U listu",
                                        tint = AppleWhite,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            // E. Short Description + MORE ("VIŠE") Button
                            val overviewText = meta.description ?: "Izuzetan film sa fantastičnom produkcijom, uzbudljivom pričom i vrhunskom glumačkom postavom."
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = overviewText,
                                    color = AppleWhite.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.25f))
                                        .clickable { showExtendedOverview = true }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "MORE",
                                        color = AppleWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // F. Bottom Meta Info Row (Release Date, Runtime, IMDb Rating)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                meta.releaseInfo?.let { release ->
                                    Text(
                                        text = release,
                                        color = AppleWhite.copy(alpha = 0.8f),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(text = "·", color = AppleWhite.copy(alpha = 0.4f), fontSize = 13.sp)
                                }
                                meta.runtime?.let { duration ->
                                    Text(
                                        text = duration,
                                        color = AppleWhite.copy(alpha = 0.8f),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(text = "·", color = AppleWhite.copy(alpha = 0.4f), fontSize = 13.sp)
                                }
                                meta.imdbRating?.let { rating ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "IMDb Ocena",
                                            tint = Color(0xFFFFD700),
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = rating,
                                            color = AppleWhite,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } // End Main Bottom Content Column
                    } // End Hero Banner Box

                    // 2. BELOW HERO BANNER CONTENT (Glumci, Režija, Detalji i Epizode)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AppleBlack)
                            .padding(horizontal = 20.dp, vertical = 20.dp)
                    ) {
                        CastAndCrewSection(
                            meta = meta,
                            onPersonClick = { name, tmdbId, profilePic ->
                                mainViewModel.showPersonModal(name, tmdbId, profilePic)
                            }
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Movie / Series Details & Information
                        MovieDetailsInfoSection(
                            meta = meta,
                            type = type,
                            onPersonClick = { name, tmdbId, profilePic ->
                                mainViewModel.showPersonModal(name, tmdbId, profilePic)
                            }
                        )

                        // Sequels / Collection Catalog
                        val collectionItems = meta.collectionItems.orEmpty()
                        if (type == "movie" && collectionItems.size > 1) {
                            Spacer(modifier = Modifier.height(28.dp))
                            RelatedSection(
                                title = meta.collectionName ?: "Nastavci",
                                relatedItems = collectionItems,
                                onItemClick = { itemType, itemId ->
                                    mainViewModel.showDetailModal(itemType, itemId)
                                }
                            )
                        }

                        // TV Series Season & Episode guide
                        val isSeriesType = type == "series" || type == "tv" || meta.type == "series"
                        if (isSeriesType || state.seasons.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(28.dp))
                            SeriesEpisodesSection(
                                seasons = state.seasons,
                                selectedSeason = state.selectedSeason,
                                episodes = state.filteredEpisodes,
                                meta = meta,
                                onSeasonSelected = { season ->
                                    detailViewModel.selectSeason(season)
                                },
                                onEpisodeSelected = { video ->
                                    selectedVideo = video
                                    detailViewModel.loadStreamsForEpisode(video, streamAddonUrls)
                                    handleDirectPlay(video)
                                }
                            )
                        }

                        // Related / Recommended Movies & Series
                        if (state.relatedItems.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(28.dp))
                            RelatedSection(
                                relatedItems = state.relatedItems,
                                onItemClick = { itemType, itemId ->
                                    mainViewModel.showDetailModal(itemType, itemId)
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(40.dp))
                    }
                } // End Column verticalScroll

                // 2. FLOATING STICKY TOP HEADER BAR
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = headerBgAlpha))
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    // Back button
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { onBack() }
                            .align(Alignment.CenterStart)
                            .testTag("detail_back_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Nazad",
                            tint = AppleWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Center ClearLogo or Apple TV+ Title docked at top edge when scrolling
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 52.dp)
                            .graphicsLayer { alpha = stickyLogoAlpha },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isValidLogo && !stickyLogoFailed) {
                            AsyncImage(
                                model = meta.logo,
                                contentDescription = meta.name,
                                contentScale = ContentScale.Fit,
                                onError = { stickyLogoFailed = true },
                                modifier = Modifier
                                    .height(32.dp)
                                    .fillMaxWidth(0.65f)
                            )
                        } else {
                            AppleTvTitleStyle(
                                title = meta.name,
                                fontSize = 15.sp,
                                maxLines = 1
                            )
                        }
                    }

                    // Mute / Unmute Button
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable {
                                if (!isTrailerPlaying) {
                                    isTrailerPlaying = true
                                }
                                isMuted = !isMuted
                            }
                            .align(Alignment.CenterEnd)
                            .testTag("trailer_mute_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = if (isMuted) "Uključi zvuk" else "Isključi zvuk",
                            tint = AppleWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            } // End Box layout

                // 4. STREAM PICKER MODAL SHEET (Triggered by Play button)
                if (showStreamPicker) {
                    StreamPickerModal(
                        meta = meta,
                        type = type,
                        selectedVideo = selectedVideo,
                        activeStreams = activeStreams,
                        isFetching = state.isFetchingStreams,
                        onDismiss = { showStreamPicker = false },
                        onSelectStream = { streamUrl, title, headers ->
                            showStreamPicker = false
                            mainViewModel.playVideo(
                                title = title,
                                url = streamUrl,
                                mediaId = selectedVideo?.id ?: meta.id,
                                headers = headers,
                                availableStreams = activeStreams,
                                metaName = meta.name,
                                metaType = type,
                                poster = meta.poster,
                                backdrop = meta.background,
                                logoUrl = meta.logo,
                                episodeThumbnail = selectedVideo?.thumbnail,
                                year = meta.releaseInfo,
                                rating = meta.imdbRating,
                                season = selectedVideo?.season,
                                episode = selectedVideo?.episode,
                                episodeId = selectedVideo?.id
                            )
                        }
                    )
                }

                // 5. EXTENDED OVERVIEW MODAL (Triggered by MORE button)
                if (showExtendedOverview) {
                    ExtendedOverviewModal(
                        meta = meta,
                        onDismiss = { showExtendedOverview = false }
                    )
                }

                // 6. FULLSCREEN TRAILER MODAL (Triggered by Trejler button)
                if (showTrailerModal) {
                    TrailerModal(
                        meta = meta,
                        youtubeId = trailerYtId,
                        fallbackUrl = fallbackVideoUrl,
                        onDismiss = { showTrailerModal = false }
                    )
                }
            } // End Success
        }
    }
}

/**
 * STREAM PICKER MODAL POPUP
 * Opens when clicking "PLAY" to select stream quality & source
 */
@Composable
fun StreamPickerModal(
    meta: StremioMetaDetail,
    type: String,
    selectedVideo: StremioVideo?,
    activeStreams: List<StremioStream>,
    isFetching: Boolean,
    onDismiss: () -> Unit,
    onSelectStream: (url: String, title: String, headers: Map<String, String>?) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxSize(0.72f)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(AppleBlack)
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {} // Prevent closing when tapping inside
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "IZABERITE STRIM IZVOR",
                                color = AppleLightGray.copy(alpha = 0.6f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                            val displayTitle = if (type == "series" && selectedVideo != null) {
                                "${meta.name} - S${selectedVideo.season}E${selectedVideo.episode}"
                            } else meta.name

                            Text(
                                text = displayTitle,
                                color = AppleWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.1f))
                                .clickable { onDismiss() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Zatvori", tint = AppleWhite, modifier = Modifier.size(18.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isFetching) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AppleTvSpinner(color = AppleWhite, size = 26.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(text = "Pretraživanje Stremio izvora...", color = AppleLightGray, fontSize = 13.sp)
                            }
                        }
                    } else if (activeStreams.isEmpty()) {
                        // Fallback Demo Streams
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Text(
                                    text = "Nema aktivnih Stremio izvora. Izaberite besplatni test izvor za reprodukciju:",
                                    color = AppleLightGray,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                            }
                            item {
                                DemoStreamCard(
                                    name = "Sintel (Full HD 1080p MP4)",
                                    quality = "1080p",
                                    info = "Besplatan Open-Cinema Demo Strim",
                                    onClick = {
                                        val streamTitle = if (type == "series" && selectedVideo != null) "${meta.name} - S${selectedVideo.season}E${selectedVideo.episode}: ${selectedVideo.title}" else meta.name
                                        onSelectStream("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", streamTitle, null)
                                    }
                                )
                            }
                            item {
                                DemoStreamCard(
                                    name = "Big Buck Bunny (HD 720p MP4)",
                                    quality = "720p",
                                    info = "Besplatan Open-Cinema Demo Strim",
                                    onClick = {
                                        val streamTitle = if (type == "series" && selectedVideo != null) "${meta.name} - S${selectedVideo.season}E${selectedVideo.episode}: ${selectedVideo.title}" else meta.name
                                        onSelectStream("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", streamTitle, null)
                                    }
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(activeStreams) { stream ->
                                StreamSourceCard(
                                    stream = stream,
                                    onClick = {
                                        val streamUrl = stream.url ?: stream.externalUrl ?: ""
                                        val streamTitle = if (type == "series" && selectedVideo != null) "${meta.name} - S${selectedVideo.season}E${selectedVideo.episode}" else meta.name
                                        val streamHeaders = stream.behaviorHints?.headers ?: stream.headers
                                        onSelectStream(streamUrl, streamTitle, streamHeaders)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * EXTENDED OVERVIEW DIALOG
 * Opens when clicking "MORE" to view the full extended overview/synopsis in a clean dark card.
 */
@Composable
fun ExtendedOverviewModal(
    meta: StremioMetaDetail,
    onDismiss: () -> Unit
) {
    val overviewText = meta.description ?: "Izuzetan film sa fantastičnom produkcijom, uzbudljivom pričom i vrhunskom glumačkom postavom."

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.75f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF242424))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(20.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {} // Prevent closing when tapping inside card
                    )
                    .padding(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    // Top Left Close 'X' Button
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Zatvori",
                        tint = AppleWhite,
                        modifier = Modifier
                            .size(24.dp)
                            .clickable { onDismiss() }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Extended Full Description Text
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = overviewText,
                            color = AppleWhite.copy(alpha = 0.95f),
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

/**
 * FULLSCREEN TRAILER MODAL
 * Plays the trailer in full screen with audio when the user clicks the "Trejler" button
 */
@Composable
fun TrailerModal(
    meta: StremioMetaDetail,
    youtubeId: String,
    fallbackUrl: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var playbackSource by remember(meta.id, youtubeId, fallbackUrl) {
        mutableStateOf<TrailerPlaybackSource?>(null)
    }
    var isLoading by remember(meta.id, youtubeId, fallbackUrl) { mutableStateOf(true) }

    LaunchedEffect(meta.id, youtubeId, fallbackUrl) {
        isLoading = true
        val ytInput = when {
            youtubeId.isNotBlank() -> youtubeId
            !fallbackUrl.isNullOrBlank() && (fallbackUrl.contains("youtube") || fallbackUrl.contains("youtu.be")) -> fallbackUrl
            else -> null
        }

        if (ytInput != null) {
            val extracted = withContext(Dispatchers.IO) {
                runCatching { InAppYouTubeExtractor().extractPlaybackSource(ytInput) }.getOrNull()
            }
            if (extracted != null && extracted.videoUrl.isNotBlank()) {
                playbackSource = extracted.copy(youtubeId = youtubeId.ifBlank { null })
            } else {
                playbackSource = TrailerPlaybackSource(
                    videoUrl = fallbackUrl,
                    youtubeId = youtubeId.ifBlank { null }
                )
            }
        } else {
            playbackSource = TrailerPlaybackSource(
                videoUrl = fallbackUrl,
                youtubeId = null
            )
        }
        isLoading = false
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    AppleTvSpinner(size = 40.dp, color = AppleWhite)
                }
            } else if (playbackSource != null) {
                TrailerVideoPlayer(
                    playbackSource = playbackSource!!,
                    isMuted = false,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Top Header & Close Button Overlay
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "${meta.name} · Trejler",
                        color = AppleWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (youtubeId.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.Red.copy(alpha = 0.85f))
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                                .clickable {
                                    val intent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse("https://www.youtube.com/watch?v=$youtubeId")
                                    )
                                    context.startActivity(intent)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "YouTube ↗",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.7f))
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Zatvori",
                            tint = AppleWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EpisodeCard(
    video: StremioVideo,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .width(150.dp)
            .appleTvScaleEffect(interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16 / 9f)
                .clip(RoundedCornerShape(14.dp))
                .background(AppleCharcoal)
                .border(
                    width = 2.dp,
                    color = if (isSelected) AppleWhite else Color.White.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(14.dp)
                )
        ) {
            if (video.thumbnail != null) {
                AsyncImage(
                    model = video.thumbnail,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = AppleWhite, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "E${video.episode}: ${video.title}",
            color = if (isSelected) AppleWhite else AppleWhite.copy(alpha = 0.7f),
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "Sezona ${video.season}",
            color = AppleLightGray,
            fontSize = 10.sp
        )
    }
}

@Composable
fun StreamSourceCard(
    stream: StremioStream,
    onClick: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .appleTvScaleEffect(interactionSource)
            .clip(RoundedCornerShape(16.dp))
            .background(AppleCharcoal)
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = AppleWhite,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stream.name ?: "Stremio Stream",
                    color = AppleWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stream.title ?: "Pusti video fajl",
                    color = AppleLightGray,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(AppleAccentBlue)
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Pusti u aplikaciji",
                tint = AppleWhite,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun DemoStreamCard(
    name: String,
    quality: String,
    info: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .appleTvScaleEffect(interactionSource)
            .clip(RoundedCornerShape(16.dp))
            .background(AppleCharcoal)
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AppleWhite)
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(text = quality, color = AppleBlack, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = name, color = AppleWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = info, color = AppleLightGray, fontSize = 11.sp)
            }
        }
        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = AppleWhite, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun ActorCard(name: String) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(75.dp)
            .appleTvScaleEffect(interactionSource)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            val initials = name.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString("").uppercase()
            Text(
                text = initials,
                color = AppleWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = name,
            color = AppleWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            textAlign = TextAlign.Center,
            lineHeight = 13.sp
        )
    }
}

/**
 * TRAILER PLAYER
 * Uses native Media3 ExoPlayer video player for background and modal trailers,
 * avoiding WebView Chromium renderer crashes on virtualized Mesa/GPU environments.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun TrailerVideoPlayer(
    playbackSource: TrailerPlaybackSource,
    isMuted: Boolean,
    onError: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoUrl = playbackSource.videoUrl
    val audioUrl = playbackSource.audioUrl

    if (!videoUrl.isNullOrBlank()) {
        val exoPlayer = remember(videoUrl, audioUrl) {
            androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
                repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                volume = if (isMuted) 0f else 1f
                playWhenReady = true

                try {
                    val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                        .setAllowCrossProtocolRedirects(true)
                        .setConnectTimeoutMs(8000)
                        .setReadTimeoutMs(8000)

                    val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(context)
                        .setDataSourceFactory(httpDataSourceFactory)

                    val videoMediaItem = androidx.media3.common.MediaItem.fromUri(android.net.Uri.parse(videoUrl))
                    val videoSource = mediaSourceFactory.createMediaSource(videoMediaItem)

                    val finalMediaSource = if (!audioUrl.isNullOrBlank() && audioUrl != videoUrl) {
                        val audioMediaItem = androidx.media3.common.MediaItem.fromUri(android.net.Uri.parse(audioUrl))
                        val audioSource = mediaSourceFactory.createMediaSource(audioMediaItem)
                        androidx.media3.exoplayer.source.MergingMediaSource(videoSource, audioSource)
                    } else {
                        videoSource
                    }

                    setMediaSource(finalMediaSource)
                    prepare()
                } catch (e: Exception) {
                    android.util.Log.e("TrailerVideoPlayer", "Failed to build media source", e)
                    onError?.invoke()
                }

                addListener(object : androidx.media3.common.Player.Listener {
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        android.util.Log.e("TrailerVideoPlayer", "Trailer playback error: ${error.message}", error)
                        onError?.invoke()
                    }
                })
            }
        }

        DisposableEffect(exoPlayer) {
            onDispose {
                exoPlayer.release()
            }
        }

        LaunchedEffect(isMuted) {
            exoPlayer.volume = if (isMuted) 0f else 1f
        }

        AndroidView(
            factory = { ctx ->
                androidx.media3.ui.PlayerView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    useController = false
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    player = exoPlayer
                }
            },
            update = { playerView ->
                if (playerView.player != exoPlayer) {
                    playerView.player = exoPlayer
                }
            },
            modifier = modifier.fillMaxSize()
        )
    } else {
        LaunchedEffect(Unit) {
            onError?.invoke()
        }
    }
}


fun getTrailerYtId(meta: StremioMetaDetail): String {
    if (!meta.trailer_yt_id.isNullOrBlank()) return meta.trailer_yt_id
    meta.trailers?.mapNotNull { it.getEffectiveYtId() }?.firstOrNull { it.isNotBlank() }?.let { return it }
    meta.trailerStreams?.mapNotNull { it.getEffectiveYtId() }?.firstOrNull { it.isNotBlank() }?.let { return it }

    val name = meta.name.lowercase()
    val id = meta.id.lowercase()
    return when {
        name.contains("f1") || id.contains("tt1517268") -> "0K3m2f1q00M"
        name.contains("instigators") || id.contains("tt16111108") -> "eQ_M_2L3OQA"
        name.contains("dune") -> "Way9Dexny3w"
        name.contains("oppenheimer") -> "uYPbbksJxIg"
        name.contains("batman") -> "mqqft2x_Aa4"
        name.contains("avatar") -> "d9MyW72ELq0"
        name.contains("spider") -> "JfVOs4VSwA3"
        name.contains("interstellar") -> "zSWdZVtXT7E"
        name.contains("breaking bad") -> "HhesaQXLuRY"
        else -> "0K3m2f1q00M"
    }
}

fun getTrailerVideoUrl(meta: StremioMetaDetail): String {
    val directStream = meta.trailers?.firstOrNull { !it.url.isNullOrBlank() && it.url.startsWith("http") }?.url
        ?: meta.trailerStreams?.firstOrNull { !it.url.isNullOrBlank() && it.url.startsWith("http") }?.url
    if (!directStream.isNullOrBlank()) {
        return directStream
    }

    val name = meta.name.lowercase()
    val id = meta.id.lowercase()
    return when {
        name.contains("f1") || id.contains("tt1517268") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
        name.contains("instigators") || id.contains("tt16111108") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
        name.contains("dune") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
        name.contains("oppenheimer") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
        name.contains("batman") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"
        name.contains("avatar") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutback2012.mp4"
        name.contains("spider") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4"
        name.contains("interstellar") -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4"
        else -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"
    }
}

@Composable
fun CastAndCrewSection(
    meta: StremioMetaDetail,
    onPersonClick: (name: String, tmdbId: Int?, profilePic: String?) -> Unit
) {
    val members = remember(meta) { meta.getEffectiveCastMembers() }
    if (members.isEmpty()) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Text(
                text = "Glumci i Režija",
                color = AppleWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = AppleWhite.copy(alpha = 0.6f),
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(members) { member ->
                CastMemberAvatarCard(
                    member = member,
                    onClick = { onPersonClick(member.name, member.tmdbPersonId, member.profilePic) }
                )
            }
        }
    }
}

@Composable
fun CastMemberAvatarCard(
    member: CastMember,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(80.dp)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f))
                .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!member.profilePic.isNullOrEmpty()) {
                AsyncImage(
                    model = member.profilePic,
                    contentDescription = member.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(
                    text = member.name.take(1).uppercase(),
                    color = AppleWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = member.name,
            color = AppleWhite,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        val subtitle = when {
            member.role == "Director" || member.character == "Reditelj" -> "Reditelj"
            !member.character.isNullOrBlank() && member.character != "Glumac" && member.character != "Actor" -> member.character
            else -> null
        }

        if (!subtitle.isNullOrEmpty()) {
            Text(
                text = subtitle,
                color = AppleLightGray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

private fun formatRuntimeHelper(runtime: String?): String {
    if (runtime.isNullOrBlank()) return "2 hr 15 min"
    val digits = runtime.filter { it.isDigit() }
    val totalMins = digits.toIntOrNull()
    if (totalMins != null && totalMins > 0) {
        val hrs = totalMins / 60
        val mins = totalMins % 60
        return if (hrs > 0) {
            if (mins > 0) "$hrs hr $mins min" else "$hrs hr"
        } else {
            "$mins min"
        }
    }
    return runtime
}

@Composable
fun MovieDetailsInfoSection(
    meta: StremioMetaDetail,
    type: String,
    onPersonClick: (name: String, tmdbId: Int?, profilePic: String?) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp)
    ) {
        // Section 1: Information
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Information",
                color = AppleWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            // Released
            val releasedVal = meta.releaseInfo?.takeIf { it.isNotBlank() }
                ?: meta.year?.takeIf { it.isNotBlank() }
                ?: "2025"
            InfoBlockItem(label = "Released", value = releasedVal)

            // Run Time
            val runtimeVal = formatRuntimeHelper(meta.runtime)
            InfoBlockItem(label = "Run Time", value = runtimeVal)

            // Rated
            val certVal = meta.getEffectiveCertification()
            val ratedVal = if (!meta.imdbRating.isNullOrBlank()) {
                "$certVal (IMDb ⭐ ${meta.imdbRating})"
            } else {
                certVal
            }
            InfoBlockItem(label = "Rated", value = ratedVal)

            // Regions of Origin
            val countryFromLinks = meta.links?.filter { it.category == "country" }?.map { it.name }?.joinToString(", ")
            val regionsVal = meta.country?.takeIf { it.isNotBlank() }
                ?: countryFromLinks?.takeIf { it.isNotBlank() }
                ?: "United States, United Kingdom"
            InfoBlockItem(label = "Regions of Origin", value = regionsVal)
        }

        // Section 2: Languages
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Languages",
                color = AppleWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            val langFromLinks = meta.links?.filter { it.category == "language" }?.firstOrNull()?.name
            val rawLang = meta.language?.takeIf { it.isNotBlank() }
                ?: langFromLinks?.takeIf { it.isNotBlank() }
            val audioVal = getLanguageDisplayName(rawLang) ?: "English"
            InfoBlockItem(label = "Original Audio", value = audioVal)
        }
    }
}

@Composable
fun InfoBlockItem(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            color = AppleWhite.copy(alpha = 0.65f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Normal
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            color = AppleWhite.copy(alpha = 0.95f),
            fontSize = 15.sp,
            fontWeight = FontWeight.Normal,
            lineHeight = 20.sp
        )
    }
}

@Composable
fun SeriesEpisodesSection(
    seasons: List<Int>,
    selectedSeason: Int,
    episodes: List<StremioVideo>,
    meta: StremioMetaDetail,
    onSeasonSelected: (Int) -> Unit,
    onEpisodeSelected: (StremioVideo) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Tv,
                contentDescription = null,
                tint = AppleWhite,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Sezone i Epizode",
                color = AppleWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (seasons.isNotEmpty()) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 2.dp),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                items(seasons) { season ->
                    val isSelected = season == selectedSeason
                    val seasonPoster = meta.seasonPosters?.get(season)?.takeIf { it.isNotBlank() }
                        ?: meta.poster
                    var currentPosterUrl by remember(season, seasonPoster) { mutableStateOf(seasonPoster) }

                    Box(
                        modifier = Modifier
                            .width(100.dp)
                            .height(150.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .border(
                                width = if (isSelected) 2.5.dp else 1.dp,
                                color = if (isSelected) AppleWhite else Color.White.copy(alpha = 0.22f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSeasonSelected(season) }
                    ) {
                        if (!currentPosterUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = currentPosterUrl,
                                contentDescription = "Poster za Sezonu $season",
                                contentScale = ContentScale.Crop,
                                onError = {
                                    if (currentPosterUrl != meta.poster && !meta.poster.isNullOrBlank()) {
                                        currentPosterUrl = meta.poster
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.DarkGray),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "S$season",
                                    color = AppleWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                    )
                                )
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SEZONA $season",
                                color = if (isSelected) AppleWhite else Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (episodes.isEmpty()) {
                Text(
                    text = "Nema dostupnih epizoda za ovu sezonu.",
                    color = AppleLightGray,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            } else {
                episodes.forEach { video ->
                    val titleText = if (!video.title.isNullOrBlank()) video.title else "Epizoda ${video.episode}"
                    val formattedDate = remember(video.released) { formatReleaseDate(video.released) }
                    val rating = video.getEffectiveRating()

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                            .clickable { onEpisodeSelected(video) }
                            .padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(78.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = video.thumbnail ?: meta.background ?: meta.poster,
                                    contentDescription = video.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Text(
                                    text = "S${video.season}E${video.episode}",
                                    color = AppleWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    style = androidx.compose.ui.text.TextStyle(
                                        shadow = androidx.compose.ui.graphics.Shadow(
                                            color = Color.Black,
                                            blurRadius = 8f
                                        )
                                    ),
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(6.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = titleText,
                                    color = AppleWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                if (!formattedDate.isNullOrBlank() || !rating.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        if (!formattedDate.isNullOrBlank()) {
                                            Text(
                                                text = formattedDate,
                                                color = AppleLightGray,
                                                fontSize = 12.sp
                                            )
                                        }
                                        if (!rating.isNullOrBlank()) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(3.dp))
                                                        .background(Color(0xFFF5C518))
                                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(
                                                        text = "IMDb",
                                                        color = Color.Black,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.ExtraBold
                                                    )
                                                }
                                                Text(
                                                    text = rating,
                                                    color = Color(0xFFF5C518),
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }

                                if (!video.overview.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = video.overview,
                                        color = Color.White.copy(alpha = 0.65f),
                                        fontSize = 12.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RelatedSection(
    title: String = "Related",
    relatedItems: List<StremioMetaSummary>,
    onItemClick: (type: String, id: String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Text(
                text = title,
                color = AppleWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = AppleWhite,
                modifier = Modifier.size(22.dp)
            )
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(relatedItems) { item ->
                val genreText = item.primaryGenre ?: item.genres?.firstOrNull() ?: if (item.type == "series") "Drama" else "Akcija"
                val rating = item.imdbRating?.takeIf { it.isNotBlank() } ?: "7.8"

                Box(
                    modifier = Modifier
                        .width(150.dp)
                        .height(225.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(AppleCharcoal)
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                        .clickable { onItemClick(item.type, item.id) }
                ) {
                    AsyncImage(
                        model = item.poster ?: item.background,
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Smooth dark gradient overlay at bottom
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.2f),
                                        Color.Black.copy(alpha = 0.85f)
                                    ),
                                    startY = 120f
                                )
                            )
                    )

                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = genreText,
                            color = AppleWhite.copy(alpha = 0.95f),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = " • ",
                            color = AppleWhite.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "IMDb Ocena",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.5.dp))
                        Text(
                            text = rating,
                            color = AppleWhite.copy(alpha = 0.95f),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppleTvTitleStyle(
    title: String,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 32.sp,
    maxLines: Int = 2
) {
    Text(
        text = title.uppercase(),
        color = AppleWhite,
        fontSize = fontSize,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
        letterSpacing = if (fontSize.value < 20) 1.2.sp else 2.5.sp,
        textAlign = TextAlign.Center,
        lineHeight = if (fontSize.value > 20) (fontSize.value * 1.15f).sp else (fontSize.value * 1.25f).sp,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        style = androidx.compose.ui.text.TextStyle(
            shadow = androidx.compose.ui.graphics.Shadow(
                color = Color.Black.copy(alpha = 0.95f),
                offset = androidx.compose.ui.geometry.Offset(0f, 3f),
                blurRadius = 12f
            )
        ),
        modifier = modifier.padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

fun getLanguageDisplayName(code: String?): String? {
    if (code.isNullOrBlank()) return null
    val clean = code.trim()
    if (clean.length == 2 || clean.length == 3) {
        val display = java.util.Locale(clean.lowercase()).getDisplayLanguage(java.util.Locale.ENGLISH)
        if (display.isNotBlank() && !display.equals(clean, ignoreCase = true)) {
            return display.replaceFirstChar { it.uppercase() }
        }
    }
    return when (clean.lowercase()) {
        "en" -> "English"
        "ja" -> "Japanese"
        "fr" -> "French"
        "es" -> "Spanish"
        "de" -> "German"
        "it" -> "Italian"
        "ko" -> "Korean"
        "zh", "cn" -> "Chinese"
        "ru" -> "Russian"
        "hi" -> "Hindi"
        "pt" -> "Portuguese"
        "sr" -> "Serbian"
        "hr" -> "Croatian"
        "bs" -> "Bosnian"
        "sv" -> "Swedish"
        "da" -> "Danish"
        "no" -> "Norwegian"
        "fi" -> "Finnish"
        "pl" -> "Polish"
        "tr" -> "Turkish"
        "nl" -> "Dutch"
        "ar" -> "Arabic"
        "el" -> "Greek"
        "he" -> "Hebrew"
        "cs" -> "Czech"
        "hu" -> "Hungarian"
        "ro" -> "Romanian"
        "th" -> "Thai"
        "id" -> "Indonesian"
        "vi" -> "Vietnamese"
        else -> clean.replaceFirstChar { it.uppercase() }
    }
}

fun formatReleaseDate(released: String?): String? {
    if (released.isNullOrBlank()) return null
    return try {
        val datePart = released.substringBefore("T").trim()
        val parts = datePart.split("-")
        if (parts.size == 3 && parts[0].length == 4) {
            val year = parts[0]
            val monthNum = parts[1].toIntOrNull() ?: 1
            val day = parts[2].toIntOrNull() ?: 1
            val monthNames = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
            val monthName = if (monthNum in 1..12) monthNames[monthNum - 1] else ""
            if (monthName.isNotBlank()) "$year $monthName $day" else datePart
        } else {
            released
        }
    } catch (e: Exception) {
        released
    }
}
