package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.interaction.MutableInteractionSource
import com.example.ui.theme.appleTvScaleEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.filled.Tv
import com.example.data.model.WatchlistItem
import com.example.data.network.model.StremioMetaSummary
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleCharcoal
import com.example.ui.theme.AppleLightGray
import com.example.ui.theme.AppleWhite
import com.example.ui.components.shimmer
import com.example.viewmodel.HomeUiState
import com.example.viewmodel.HomeViewModel
import com.example.viewmodel.MainViewModel

@Composable
fun HomeTopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0D0D0D).copy(alpha = 0.95f),
                        Color(0xFF0D0D0D).copy(alpha = 0.0f)
                    )
                )
            )
            .padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 28.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(AppleWhite),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "tv",
                    color = Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }
            Text(
                text = "Stremio TV+",
                color = AppleWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp
            )
        }

        // Profile Avatar placeholder in the style of Apple TV+
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        colors = listOf(
                            Color(0xFF6366F1),
                            Color(0xFFA855F7),
                            Color(0xFFEC4899),
                            Color(0xFF6366F1)
                        )
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
        )
    }
}

@Composable
fun HomeScreen(
    mainViewModel: MainViewModel,
    homeViewModel: HomeViewModel,
    onNavigateToDetail: (String, String) -> Unit
) {
    val homeState by homeViewModel.uiState.collectAsState()
    val watchlist by mainViewModel.watchlist.collectAsState()
    val addons by mainViewModel.addons.collectAsState()
    val continueWatchingList by mainViewModel.continueWatchingList.collectAsState()

    val currentLang by mainViewModel.currentLanguage.collectAsState()

    var selectedFilter by remember { mutableStateOf("all") }
    var selectedGenre by remember { mutableStateOf("Akcija") }
    var selectedSort by remember { mutableStateOf("popularity") }

    // Refresh content if addons or language changes
    LaunchedEffect(addons, currentLang) {
        val activeCatalog = addons.firstOrNull { it.isActive && (it.type == "catalog" || it.type == "both") }
        homeViewModel.loadContent(activeCatalog?.url)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppleBlack)
    ) {
        when (val state = homeState) {
            is HomeUiState.Loading -> {
                HomeShimmerSkeleton()
            }
            is HomeUiState.Success -> {
                val featuredList = state.featuredItems

                val trendingList = remember(state.popularMovies, state.popularSeries, selectedSort) {
                    val list = mutableListOf<StremioMetaSummary>()
                    val size = maxOf(state.popularMovies.size, state.popularSeries.size)
                    for (i in 0 until size) {
                        if (i < state.popularMovies.size) list.add(state.popularMovies[i])
                        if (i < state.popularSeries.size) list.add(state.popularSeries[i])
                    }
                    val distinct = list.distinctBy { it.id }
                    sortCatalogList(distinct, selectedSort)
                }

                val newReleasesList = remember(state.popularMovies, state.popularSeries, selectedSort) {
                    val list = (state.popularMovies + state.popularSeries).distinctBy { it.id }
                    val sorted = list.sortedWith(compareByDescending<StremioMetaSummary> { 
                        it.releaseInfo?.filter { c -> c.isDigit() }?.toIntOrNull() ?: 0
                    }.thenByDescending { it.imdbRating?.toFloatOrNull() ?: 0f })
                    sortCatalogList(sorted, selectedSort)
                }

                val recommendedList = remember(state.popularMovies, state.popularSeries, selectedSort) {
                    val list = (state.popularMovies + state.popularSeries).distinctBy { it.id }
                    val sorted = list.sortedByDescending { it.imdbRating?.toFloatOrNull() ?: 0f }
                    sortCatalogList(sorted, selectedSort)
                }

                val filteredTrending = remember(trendingList, selectedFilter, selectedGenre) {
                    filterList(trendingList, selectedFilter, selectedGenre)
                }

                val filteredNewReleases = remember(newReleasesList, selectedFilter, selectedGenre) {
                    filterList(newReleasesList, selectedFilter, selectedGenre)
                }

                val filteredRecommended = remember(recommendedList, selectedFilter, selectedGenre) {
                    filterList(recommendedList, selectedFilter, selectedGenre)
                }

                val filteredMovies = remember(state.popularMovies, selectedFilter, selectedGenre, selectedSort) {
                    val sorted = sortCatalogList(state.popularMovies, selectedSort)
                    filterList(sorted, selectedFilter, selectedGenre)
                }

                val filteredSeries = remember(state.popularSeries, selectedFilter, selectedGenre, selectedSort) {
                    val sorted = sortCatalogList(state.popularSeries, selectedSort)
                    filterList(sorted, selectedFilter, selectedGenre)
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    // 1. Featured Hero Banner Carousel
                    if (featuredList.isNotEmpty()) {
                        item {
                            HeroCarouselBanner(
                                items = featuredList,
                                watchlist = watchlist,
                                onPlayClick = { featuredMovie ->
                                    onNavigateToDetail(featuredMovie.type, featuredMovie.id)
                                },
                                onWatchlistToggle = { featuredMovie ->
                                    val isInList = watchlist.any { it.id == featuredMovie.id }
                                    mainViewModel.toggleWatchlist(
                                        WatchlistItem(
                                            id = featuredMovie.id,
                                            title = featuredMovie.name,
                                            type = featuredMovie.type,
                                            poster = featuredMovie.poster,
                                            backdrop = featuredMovie.background,
                                            year = featuredMovie.releaseInfo,
                                            rating = featuredMovie.imdbRating
                                        ),
                                        isInList
                                    )
                                },
                                onClick = { featuredMovie ->
                                    onNavigateToDetail(featuredMovie.type, featuredMovie.id)
                                }
                            )
                        }
                    }

                    // 1.5. Continue Watching Row - replaces the old CategoryBar below the Hero Carousel
                    if (continueWatchingList.isNotEmpty()) {
                        item {
                            ContinueWatchingRow(
                                list = continueWatchingList,
                                onNavigateToDetail = onNavigateToDetail,
                                onRemoveItem = { id ->
                                    mainViewModel.removeFromContinueWatching(id)
                                }
                            )
                        }
                    }



                    // 2. Up Next row (Watchlist) - Standard Apple TV+ signature row, only visible if watchlist is not empty
                    if (watchlist.isNotEmpty()) {
                        item {
                            WatchlistRow(
                                list = watchlist,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 3. Trending Now Content Rail (Filtered)
                    if (filteredTrending.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Trending Now",
                                items = filteredTrending,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 4. New Releases Content Rail (Filtered)
                    if (filteredNewReleases.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "New Releases",
                                items = filteredNewReleases,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 5. Recommended Content Rail (Filtered)
                    if (filteredRecommended.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Recommended for You",
                                items = filteredRecommended,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 6. Popular Movies Catalog Row (Filtered)
                    if (filteredMovies.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Popular Movies",
                                items = filteredMovies,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 7. Popular Series Catalog Row (Filtered)
                    if (filteredSeries.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Popular Series",
                                items = filteredSeries,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 8. Empty State when all filtered rails are empty
                    if (filteredTrending.isEmpty() &&
                        filteredNewReleases.isEmpty() &&
                        filteredRecommended.isEmpty() &&
                        filteredMovies.isEmpty() &&
                        filteredSeries.isEmpty()
                    ) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp, horizontal = 24.dp)
                                    .testTag("filtered_empty_state"),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tv,
                                    contentDescription = "Nema sadržaja",
                                    tint = AppleLightGray.copy(alpha = 0.4f),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "Nema pronađenih naslova",
                                    color = AppleWhite,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Pokušajte da izaberete drugu kategoriju ili žanr.",
                                    color = AppleLightGray,
                                    fontSize = 13.sp
                                )
                             }
                        }
                    }
                }
            }
            is HomeUiState.Error -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Greška pri učitavanju: ${state.message}", color = AppleLightGray)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { homeViewModel.loadContent() },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleWhite, contentColor = AppleBlack)
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Osveži")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Pokušaj ponovo")
                        }
                    }
                }
            }
        }


    }
}

@Composable
fun HeroCarouselBanner(
    items: List<StremioMetaSummary>,
    watchlist: List<WatchlistItem>,
    onPlayClick: (StremioMetaSummary) -> Unit,
    onWatchlistToggle: (StremioMetaSummary) -> Unit,
    onClick: (StremioMetaSummary) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { items.size })
    val configuration = LocalConfiguration.current
    val bannerHeight = (configuration.screenHeightDp * 0.75f).dp

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(bannerHeight)
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = items[page]
            val isInWatchlist = remember(watchlist, item.id) { watchlist.any { it.id == item.id } }

            // Smooth parallax and cinematic transitions matching Apple TV+ layout
            val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        // Gentle scaling down as pages slide away
                        val scale = 1f - (kotlin.math.abs(pageOffset) * 0.12f).coerceIn(0f, 0.12f)
                        // Fading out the slide-out page to create a stunning crossfade
                        val alpha = 1f - (kotlin.math.abs(pageOffset) * 0.7f).coerceIn(0f, 0.7f)
                        // Cinematic horizontal parallax movement
                        translationX = pageOffset * size.width * 0.3f
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .clickable { onClick(item) }
            ) {
                // High quality background artwork
                AsyncImage(
                    model = item.background ?: item.poster,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Elegant Dark heavy vertical gradient overlay - perfectly blends with #0D0D0D
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.4f),
                                    Color.Black.copy(alpha = 0.1f),
                                    AppleBlack.copy(alpha = 0.5f),
                                    AppleBlack.copy(alpha = 0.95f),
                                    AppleBlack
                                )
                            )
                        )
                )

                // Hero information details and actionable buttons (Centered vertically in lower section)
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 24.dp, vertical = 32.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1. Top status pill
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "DANAS U TRENDU",
                            color = AppleWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    // 2. Clear Logo from TMDB (when available) or fallback to bold centered display title
                    if (!item.logo.isNullOrEmpty()) {
                        AsyncImage(
                            model = item.logo,
                            contentDescription = item.name,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .height(68.dp)
                                .fillMaxWidth(0.75f)
                                .padding(horizontal = 16.dp)
                        )
                    } else {
                        Text(
                            text = item.name.uppercase(),
                            color = AppleWhite,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-1).sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }

                    // 3. Apple style metadata Row (Centered) - Removed tv+ logo completely
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val categoryText = if (item.type == "series") "TV Show" else "Film"
                        val primaryGenre = item.primaryGenre ?: if (item.type == "series") "Drama" else "Akcija"
                        val localizedGenre = when (primaryGenre.lowercase()) {
                            "action", "action & adventure" -> "Action"
                            "comedy" -> "Comedy"
                            "drama" -> "Drama"
                            "sci-fi", "sci-fi & fantasy" -> "Sci-Fi"
                            "thriller" -> "Thriller"
                            else -> primaryGenre
                        }

                        Text(
                            text = "$categoryText  •  $localizedGenre",
                            color = AppleWhite.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "·",
                            color = AppleWhite.copy(alpha = 0.4f),
                            fontSize = 11.sp
                        )

                        // PG rating badge
                        Box(
                            modifier = Modifier
                                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (item.type == "series") "TV-MA" else "PG-13",
                                color = AppleWhite.copy(alpha = 0.7f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // 4. IMDb Rating Badge Row (Centered, Styled beautifully and more compactly)
                    if (item.imdbRating != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(vertical = 1.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFFF5C518))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "IMDb",
                                    color = Color.Black,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = (-0.1).sp
                                )
                            }
                            Text(
                                text = item.imdbRating,
                                color = Color(0xFFF5C518),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // 5. Short descriptive summary centered (fetched or customized fallback)
                    val descriptionText = if (!item.overview.isNullOrBlank()) {
                        item.overview
                    } else {
                        val genreLabel = (item.primaryGenre ?: "Drama").lowercase()
                        if (item.type == "series") {
                            "Uzbudljiva i hvaljena $genreLabel serija puna intriga, preokreta i izuzetne glumačke postave koja osvaja gledaoce širom sveta."
                        } else {
                            "Izuzetan $genreLabel film sa vrhunskom produkcijom, dubokom pričom i fantastičnim vizuelnim efektima koji ostavljaju bez daha."
                        }
                    }

                    Text(
                        text = descriptionText,
                        color = AppleWhite.copy(alpha = 0.75f),
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // 6. Action buttons (Play to Detail, Add to watchlist) centered
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { onClick(item) }, // Play leads to movie detail screen
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AppleWhite,
                                contentColor = Color.Black
                            ),
                            shape = CircleShape,
                            contentPadding = PaddingValues(horizontal = 36.dp, vertical = 12.dp),
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("hero_play_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Play",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.12f))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                                .clickable { onWatchlistToggle(item) }
                                .testTag("hero_watchlist_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isInWatchlist) Icons.Default.Check else Icons.Default.Add,
                                contentDescription = "Watchlist",
                                tint = AppleWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Beautiful indicator dots at the bottom
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(items.size) { index ->
                val isSelected = pagerState.currentPage == index
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .height(6.dp)
                        .width(if (isSelected) 18.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) AppleWhite else Color.White.copy(alpha = 0.3f))
                )
            }
        }
    }
}

@Composable
fun WatchlistRow(
    list: List<WatchlistItem>,
    onNavigateToDetail: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Text(
            text = "Moja lista (My List)",
            color = AppleWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(list) { item ->
                WatchlistCard(item = item, onClick = { onNavigateToDetail(item.type, item.id) })
            }
        }
    }
}

@Composable
fun WatchlistCard(
    item: WatchlistItem,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .width(190.dp)
            .appleTvScaleEffect(interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        // Wide aspect ratio backdrop for Up Next cards (just like Apple TV+!)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16 / 9f)
                .clip(RoundedCornerShape(16.dp)) // Elegant Dark rounded-2xl
                .background(AppleCharcoal)
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)) // Elegant Dark soft white/10 border
        ) {
            AsyncImage(
                model = item.backdrop ?: item.poster,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Soft overlay with play icon indication on hover/card
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.15f)),
                contentAlignment = Alignment.BottomStart
            ) {
                Box(
                    modifier = Modifier
                        .padding(10.dp)
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Pusti",
                        tint = AppleWhite,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = item.title,
            color = AppleWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = if (item.type == "series") "TV Serija" else "Film",
            color = AppleWhite.copy(alpha = 0.5f), // white/50 secondary
            fontSize = 11.sp
        )
    }
}

@Composable
fun CatalogRow(
    title: String,
    items: List<StremioMetaSummary>,
    onNavigateToDetail: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Text(
            text = title,
            color = AppleWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(items) { item ->
                MovieCard(
                    item = item,
                    onClick = { onNavigateToDetail(item.type, item.id) }
                )
            }
        }
    }
}

@Composable
fun MovieCard(
    item: StremioMetaSummary,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .width(150.dp)
            .appleTvScaleEffect(interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        // Portrait aspect ratio movie posters with rounded 16.dp corners
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2 / 3f)
                .clip(RoundedCornerShape(16.dp))
                .background(AppleCharcoal)
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
        ) {
            AsyncImage(
                model = item.poster,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Smooth Apple TV+ style dark gradient at the bottom of the poster
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.2f),
                                Color.Black.copy(alpha = 0.85f)
                            ),
                            startY = 120f
                        )
                    )
            )

            // Genre + IMDb Rating overlay at the bottom center
            val genre = item.primaryGenre 
                ?: item.genres?.firstOrNull() 
                ?: if (item.type == "series") "Drama" else "Akcija"
            val rating = item.imdbRating?.takeIf { it.isNotBlank() } ?: "7.8"

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = genre,
                    color = AppleWhite.copy(alpha = 0.95f),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = " • ",
                    color = AppleWhite.copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "IMDb Ocena",
                    tint = Color(0xFFFFD700), // Gold Star
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(2.5.dp))
                Text(
                    text = rating,
                    color = AppleWhite.copy(alpha = 0.95f),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(7.dp))
        Text(
            text = item.name,
            color = AppleWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun CategoryBar(
    selectedFilter: String,
    onFilterSelected: (String) -> Unit,
    selectedGenre: String,
    onGenreSelected: (String) -> Unit
) {
    val filters = listOf(
        "all" to "Sve",
        "movie" to "Filmovi",
        "series" to "Serije",
        "genre" to "Žanrovi"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        // Main categories Row with a clean glassmorphic design
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            filters.forEach { (key, label) ->
                val isSelected = selectedFilter == key
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color.White.copy(alpha = 0.12f) else Color.Transparent)
                        .clickable { onFilterSelected(key) }
                        .padding(vertical = 10.dp)
                        .testTag("category_filter_$key"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) AppleWhite else AppleLightGray,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        // Sub-genres Row shown when "genre" is selected
        AnimatedVisibility(
            visible = selectedFilter == "genre",
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            val genres = listOf("Akcija", "Komedija", "Drama", "Sci-Fi", "Triler")
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(genres) { genre ->
                    val isGenreSelected = selectedGenre == genre
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isGenreSelected) Color.White.copy(alpha = 0.16f)
                                else Color.White.copy(alpha = 0.04f)
                            )
                            .border(
                                1.dp,
                                if (isGenreSelected) Color.White.copy(alpha = 0.25f)
                                else Color.White.copy(alpha = 0.08f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onGenreSelected(genre) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("genre_filter_$genre"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = genre,
                            color = if (isGenreSelected) AppleWhite else AppleLightGray,
                            fontSize = 12.sp,
                            fontWeight = if (isGenreSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

fun sortCatalogList(list: List<StremioMetaSummary>, sortOption: String): List<StremioMetaSummary> {
    return when (sortOption) {
        "rating" -> list.sortedByDescending { it.imdbRating?.toFloatOrNull() ?: 0f }
        "year" -> list.sortedByDescending { 
            it.releaseInfo?.filter { c -> c.isDigit() }?.toIntOrNull() ?: 0 
        }
        "alphabetical" -> list.sortedBy { it.name }
        else -> list // "popularity" - default order
    }
}

fun filterList(
    list: List<StremioMetaSummary>,
    filter: String,
    genre: String
): List<StremioMetaSummary> {
    return list.filter { item ->
        when (filter) {
            "movie" -> item.type == "movie"
            "series" -> item.type == "series"
            "genre" -> getGenresForMeta(item).contains(genre)
            else -> true
        }
    }
}

fun getGenresForMeta(item: StremioMetaSummary): List<String> {
    val result = mutableListOf<String>()
    
    val allGenresToMap = mutableListOf<String>()
    item.primaryGenre?.let { allGenresToMap.add(it) }
    item.genres?.let { allGenresToMap.addAll(it) }

    for (g in allGenresToMap) {
        when (g.lowercase().trim()) {
            "action", "action & adventure", "akcija", "акција" -> result.add("Akcija")
            "comedy", "komedija", "комедија", "музички", "muzicki" -> result.add("Komedija")
            "drama", "драма", "историјски", "istorijski" -> result.add("Drama")
            "sci-fi", "sci-fi & fantasy", "fantasy", "naučna fantastika", "science fiction", "научна фантастика", "фантазија" -> result.add("Sci-Fi")
            "thriller", "crime", "mystery", "triler", "kriminal", "трилери", "криминалци", "криминал" -> result.add("Triler")
            "horror", "horor", "хорор" -> result.add("Horor")
            "adventure", "avantura", "авантура" -> result.add("Avantura")
            "animation", "animated", "animacija", "crtani", "cartoons", "cartoon", "anime", "анимација", "цртани" -> {
                result.add("Animacija")
                result.add("Crtani")
            }
            "family", "kids", "porodični", "porodicni", "dečiji", "deciji", "породични", "дечији" -> {
                result.add("Porodični")
                result.add("Porodicni")
            }
            "documentary", "dokumentarni", "документарци" -> result.add("Dokumentarni")
            "ratni", "ratni filmovi", "ратни", "ратни филмови" -> {
                result.add("Akcija")
                result.add("Drama")
            }
            else -> if (g.isNotBlank()) result.add(g)
        }
    }

    if (result.isNotEmpty()) {
        return result.distinct()
    }

    val nameLower = item.name.lowercase()
    val genres = mutableListOf<String>()
    
    // Intelligent keyword mapping
    if (nameLower.contains("war") || nameLower.contains("action") || nameLower.contains("deadpool") || nameLower.contains("avengers") || nameLower.contains("batman") || nameLower.contains("spider") || nameLower.contains("fight") || nameLower.contains("gun") || nameLower.contains("kill") || nameLower.contains("f1") || nameLower.contains("instigators") || nameLower.contains("twisters")) {
        genres.add("Akcija")
    }
    if (nameLower.contains("comedy") || nameLower.contains("funny") || nameLower.contains("love") || nameLower.contains("sheldon") || nameLower.contains("big bang") || nameLower.contains("friend") || nameLower.contains("ted lasso")) {
        genres.add("Komedija")
    }
    if (nameLower.contains("drama") || nameLower.contains("life") || nameLower.contains("crown") || nameLower.contains("breaking bad") || nameLower.contains("better call") || nameLower.contains("story") || nameLower.contains("shogun") || nameLower.contains("bear") || nameLower.contains("presumed")) {
        genres.add("Drama")
    }
    if (nameLower.contains("sci-fi") || nameLower.contains("star") || nameLower.contains("space") || nameLower.contains("stranger") || nameLower.contains("dark") || nameLower.contains("alien") || nameLower.contains("future") || nameLower.contains("robo") || nameLower.contains("dune") || nameLower.contains("silo") || nameLower.contains("acolyte") || nameLower.contains("fallout")) {
        genres.add("Sci-Fi")
    }
    if (nameLower.contains("thriller") || nameLower.contains("murder") || nameLower.contains("detective") || nameLower.contains("sherlock") || nameLower.contains("mystery") || nameLower.contains("secret") || nameLower.contains("agent")) {
        genres.add("Triler")
    }
    if (nameLower.contains("horror") || nameLower.contains("quiet place") || nameLower.contains("evil") || nameLower.contains("conjuring") || nameLower.contains("ghost") || nameLower.contains("smile") || nameLower.contains("scream")) {
        genres.add("Horor")
    }
    if (nameLower.contains("inside out") || nameLower.contains("despicable") || nameLower.contains("minion") || nameLower.contains("shrek") || nameLower.contains("nemo") || nameLower.contains("panda") || nameLower.contains("lion king") || nameLower.contains("frozen") || nameLower.contains("encanto") || nameLower.contains("moana") || nameLower.contains("toy story") || nameLower.contains("arcane")) {
        genres.add("Animacija")
        genres.add("Crtani")
    }
    if (nameLower.contains("family") || nameLower.contains("wonka") || nameLower.contains("paddington") || nameLower.contains("harry potter") || nameLower.contains("little house") || nameLower.contains("sonic") || nameLower.contains("jumanji")) {
        genres.add("Porodični")
    }
    
    // Fallback: assign single deterministic genre
    if (genres.isEmpty()) {
        val hash = kotlin.math.abs(item.id.hashCode())
        val list = listOf("Akcija", "Komedija", "Drama", "Sci-Fi", "Triler")
        genres.add(list[hash % list.size])
    }
    return genres.distinct()
}

@Composable
fun HomeShimmerSkeleton() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppleBlack)
    ) {
        // 1. Hero Banner Skeleton (matching HeroCarouselBanner height)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp)
                .shimmer()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                AppleBlack.copy(alpha = 0.5f),
                                AppleBlack
                            )
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Category bar chips skeleton
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            repeat(4) {
                Box(
                    modifier = Modifier
                        .size(width = 80.dp, height = 32.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .shimmer()
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. Content rail 1 (Title + Row of cards)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            // Rail Title Skeleton
            Box(
                modifier = Modifier
                    .padding(horizontal = 24.dp, vertical = 6.dp)
                    .size(width = 140.dp, height = 18.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .shimmer()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Cards list skeleton
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(4) {
                    Box(
                        modifier = Modifier
                            .width(150.dp)
                            .aspectRatio(2 / 3f)
                            .clip(RoundedCornerShape(16.dp))
                            .shimmer()
                    )
                }
            }
        }

        // 4. Content rail 2
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Rail Title Skeleton
            Box(
                modifier = Modifier
                    .padding(horizontal = 24.dp, vertical = 6.dp)
                    .size(width = 110.dp, height = 18.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .shimmer()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Cards list skeleton
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(4) {
                    Box(
                        modifier = Modifier
                            .width(150.dp)
                            .aspectRatio(2 / 3f)
                            .clip(RoundedCornerShape(16.dp))
                            .shimmer()
                    )
                }
            }
        }
    }
}

@Composable
fun ContinueWatchingRow(
    list: List<com.example.data.model.ContinueWatchingItem>,
    onNavigateToDetail: (String, String) -> Unit,
    onRemoveItem: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Text(
            text = "Nastavi sa gledanjem (Continue Watching)",
            color = AppleWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(list) { item ->
                ContinueWatchingCard(
                    item = item,
                    onClick = { onNavigateToDetail(item.type, item.id) },
                    onRemove = { onRemoveItem(item.id) }
                )
            }
        }
    }
}

@Composable
fun ContinueWatchingCard(
    item: com.example.data.model.ContinueWatchingItem,
    onClick: () -> Unit,
    onRemove: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    // Artwork resolution logic according to rules:
    // For series: 1) episode thumbnail, 2) series backdrop/fanart, 3) series poster
    // For movie: 1) movie backdrop/fanart, 2) movie poster
    val imageToDisplay = if (item.type == "series") {
        item.episodeThumbnail?.takeIf { it.isNotBlank() }
            ?: item.backdrop?.takeIf { it.isNotBlank() }
            ?: item.poster
    } else {
        item.backdrop?.takeIf { it.isNotBlank() }
            ?: item.poster
    }

    val isLandscape = imageToDisplay == item.episodeThumbnail || imageToDisplay == item.backdrop
    val cardWidth = if (isLandscape) 240.dp else 150.dp
    val aspectRatio = if (isLandscape) (16 / 9f) else (2 / 3f)

    Column(
        modifier = Modifier
            .width(cardWidth)
            .appleTvScaleEffect(interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspectRatio)
                .clip(RoundedCornerShape(16.dp))
                .background(AppleCharcoal)
                .border(1.2.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
        ) {
            // Background Artwork
            AsyncImage(
                model = imageToDisplay,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Clear Logo overlay on backdrop if available
            if (!item.logoUrl.isNullOrBlank() && isLandscape) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = item.logoUrl,
                        contentDescription = item.title,
                        modifier = Modifier
                            .height(36.dp)
                            .fillMaxWidth(0.7f),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            // Dark bottom gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.2f),
                                Color.Black.copy(alpha = 0.85f)
                            ),
                            startY = 40f
                        )
                    )
            )

            // Close/Remove button in top right corner
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                contentAlignment = Alignment.TopEnd
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .clickable { onRemove() }
                        .border(0.8.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "×",
                        color = AppleWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.graphicsLayer { translationY = -1.5f }
                    )
                }
            }

            // Bottom overlay bar matching user's screenshot:
            // Layout: [Play Icon] [Progress Bar Pill] [S1, E2 • 35m]
            val displayProgress = if (item.progress > 0f) item.progress.coerceIn(0.05f, 1f) else 0.15f

            // Calculate remaining time
            val remainingMs = (item.duration - item.lastWatchedPosition).coerceAtLeast(0L)
            val totalRemainingMin = (remainingMs / 1000 / 60).toInt()
            val timeRemainingStr = when {
                totalRemainingMin >= 60 -> {
                    val h = totalRemainingMin / 60
                    val m = totalRemainingMin % 60
                    if (m > 0) "${h}h ${m}m" else "${h}h"
                }
                totalRemainingMin > 0 -> "${totalRemainingMin}m"
                else -> ""
            }

            val statusText = if (item.type == "series") {
                if (item.season != null && item.episode != null) {
                    if (timeRemainingStr.isNotEmpty()) "S${item.season}, E${item.episode} • $timeRemainingStr"
                    else "S${item.season}, E${item.episode}"
                } else {
                    if (timeRemainingStr.isNotEmpty()) "TV Serija • $timeRemainingStr" else "TV Serija"
                }
            } else {
                if (timeRemainingStr.isNotEmpty()) timeRemainingStr else "Film"
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Play Triangle Icon
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = AppleWhite,
                    modifier = Modifier.size(13.dp)
                )

                // Small Horizontal Progress Bar Pill
                Box(
                    modifier = Modifier
                        .width(26.dp)
                        .height(3.5.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.35f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(displayProgress)
                            .clip(CircleShape)
                            .background(AppleWhite)
                    )
                }

                // Status text (e.g., "S1, E2 • 35m")
                Text(
                    text = statusText,
                    color = AppleWhite.copy(alpha = 0.95f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = item.title,
            color = AppleWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (!item.lastPlayedTitle.isNullOrBlank() && item.lastPlayedTitle != item.title) {
            Text(
                text = item.lastPlayedTitle,
                color = AppleLightGray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}




