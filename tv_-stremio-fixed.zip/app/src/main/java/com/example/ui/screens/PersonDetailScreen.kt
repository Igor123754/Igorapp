package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import com.example.ui.components.AppleTvSpinner
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.example.data.repository.PersonCreditItem
import com.example.data.repository.PersonDetailData
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleCharcoal
import com.example.ui.theme.AppleLightGray
import com.example.ui.theme.AppleWhite
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.PersonUiState
import com.example.viewmodel.PersonViewModel
import kotlinx.coroutines.launch

@Composable
fun PersonDetailScreen(
    personName: String,
    tmdbPersonId: Int? = null,
    initialProfilePic: String? = null,
    mainViewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToDetail: (type: String, id: String) -> Unit,
    personViewModel: PersonViewModel = viewModel()
) {
    val uiState by personViewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(personName, tmdbPersonId, initialProfilePic) {
        personViewModel.loadPersonDetails(personName, tmdbPersonId, initialProfilePic)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppleBlack)
    ) {
        when (val state = uiState) {
            is PersonUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AppleTvSpinner(size = 40.dp, color = AppleWhite)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Učitavanje podataka za $personName...",
                            color = AppleLightGray,
                            fontSize = 14.sp
                        )
                    }
                }
            }
            is PersonUiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = state.message,
                            color = AppleWhite,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(AppleCharcoal)
                                .clickable { onBack() }
                                .padding(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Text("Zatvori", color = AppleWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            is PersonUiState.Success -> {
                val detail = state.personDetail
                val scrollState = rememberScrollState()

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(bottom = 40.dp)
                ) {
                    // Top Space for Back Button
                    Spacer(modifier = Modifier.height(60.dp))

                    // Person Profile Header
                    PersonProfileHeader(detail = detail)

                    Spacer(modifier = Modifier.height(20.dp))

                    // Biography Section
                    if (!detail.biography.isNullOrBlank()) {
                        PersonBiographySection(biography = detail.biography)
                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    // Filmography Rows (POSTER SIZE CARDS)
                    if (detail.moviesCast.isNotEmpty()) {
                        FilmographyRowSection(
                            title = "Filmovi",
                            items = detail.moviesCast,
                            onItemClick = { credit ->
                                scope.launch {
                                    val imdbId = credit.imdbId ?: personViewModel.resolveImdbId("movie", credit.tmdbId) ?: "tmdb:${credit.tmdbId}"
                                    onNavigateToDetail("movie", imdbId)
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    if (detail.tvCast.isNotEmpty()) {
                        FilmographyRowSection(
                            title = "Serije",
                            items = detail.tvCast,
                            onItemClick = { credit ->
                                scope.launch {
                                    val imdbId = credit.imdbId ?: personViewModel.resolveImdbId("series", credit.tmdbId) ?: "tmdb:${credit.tmdbId}"
                                    onNavigateToDetail("series", imdbId)
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    if (detail.directorCredits.isNotEmpty()) {
                        FilmographyRowSection(
                            title = "Režija",
                            items = detail.directorCredits,
                            onItemClick = { credit ->
                                scope.launch {
                                    val imdbId = credit.imdbId ?: personViewModel.resolveImdbId(credit.mediaType, credit.tmdbId) ?: "tmdb:${credit.tmdbId}"
                                    onNavigateToDetail(credit.mediaType, imdbId)
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    if (detail.producerCredits.isNotEmpty()) {
                        FilmographyRowSection(
                            title = "Producent",
                            items = detail.producerCredits,
                            onItemClick = { credit ->
                                scope.launch {
                                    val imdbId = credit.imdbId ?: personViewModel.resolveImdbId(credit.mediaType, credit.tmdbId) ?: "tmdb:${credit.tmdbId}"
                                    onNavigateToDetail(credit.mediaType, imdbId)
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    if (detail.writerCredits.isNotEmpty()) {
                        FilmographyRowSection(
                            title = "Pisanje",
                            items = detail.writerCredits,
                            onItemClick = { credit ->
                                scope.launch {
                                    val imdbId = credit.imdbId ?: personViewModel.resolveImdbId(credit.mediaType, credit.tmdbId) ?: "tmdb:${credit.tmdbId}"
                                    onNavigateToDetail(credit.mediaType, imdbId)
                                }
                            }
                        )
                    }
                }
            }
        }

        // Top Floating Back Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    .clickable { onBack() }
                    .testTag("person_back_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Nazad",
                    tint = AppleWhite,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun PersonProfileHeader(detail: PersonDetailData) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Large Profile Image
        Box(
            modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .background(AppleCharcoal)
                .border(2.dp, Color.White.copy(alpha = 0.3f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!detail.profilePic.isNullOrEmpty()) {
                SubcomposeAsyncImage(
                    model = detail.profilePic,
                    contentDescription = detail.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    loading = {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            AppleTvSpinner(
                                size = 24.dp,
                                color = AppleWhite
                            )
                        }
                    },
                    error = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = detail.name,
                            tint = AppleWhite.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                    }
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = detail.name,
                    tint = AppleWhite.copy(alpha = 0.5f),
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Full Name
        Text(
            text = detail.name,
            color = AppleWhite,
            fontSize = 26.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Subtitle / Info Line
        val departmentText = when (detail.knownForDepartment) {
            "Acting" -> "Glumac"
            "Directing" -> "Reditelj"
            "Production" -> "Producent"
            "Writing" -> "Pisac"
            else -> detail.knownForDepartment ?: "Filmski radnik"
        }

        val infoParts = mutableListOf<String>()
        infoParts.add(departmentText)
        detail.birthday?.let { bday ->
            infoParts.add("Rođen/a $bday")
        }
        detail.placeOfBirth?.let { place ->
            infoParts.add(place)
        }

        Text(
            text = infoParts.joinToString(" · "),
            color = AppleLightGray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

@Composable
fun PersonBiographySection(biography: String) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ) {
        Text(
            text = "BIOGRAFIJA",
            color = AppleWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = biography,
            color = AppleWhite.copy(alpha = 0.85f),
            fontSize = 13.sp,
            lineHeight = 19.sp,
            maxLines = if (expanded) Int.MAX_VALUE else 4,
            overflow = TextOverflow.Ellipsis
        )

        if (biography.length > 200) {
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (expanded) "MANJE" else "VIŠE",
                    color = AppleWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun FilmographyRowSection(
    title: String,
    items: List<PersonCreditItem>,
    onItemClick: (PersonCreditItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        ) {
            Text(
                text = title,
                color = AppleWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = AppleWhite.copy(alpha = 0.6f),
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(horizontal = 20.dp)
        ) {
            items(items) { credit ->
                FilmographyPosterCard(
                    credit = credit,
                    onClick = { onItemClick(credit) }
                )
            }
        }
    }
}

@Composable
fun FilmographyPosterCard(
    credit: PersonCreditItem,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    Column(
        modifier = Modifier
            .width(125.dp)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        // Vertical Poster Image (Aspect ratio 2:3)
        Box(
            modifier = Modifier
                .width(125.dp)
                .height(188.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AppleCharcoal)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
        ) {
            if (!credit.posterUrl.isNullOrEmpty()) {
                AsyncImage(
                    model = credit.posterUrl,
                    contentDescription = credit.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = credit.title,
                        color = AppleWhite.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Rating Pill Badge Top Right
            credit.rating?.let { ratingVal ->
                if (ratingVal != "0.0") {
                    Box(
                        modifier = Modifier
                            .padding(6.dp)
                            .align(Alignment.TopEnd)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.75f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = ratingVal,
                                color = AppleWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Title
        Text(
            text = credit.title,
            color = AppleWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        // Year & Role
        val subtitleParts = mutableListOf<String>()
        credit.year?.let { subtitleParts.add(it) }
        credit.role?.takeIf { it.isNotBlank() }?.let { subtitleParts.add(it) }

        if (subtitleParts.isNotEmpty()) {
            Text(
                text = subtitleParts.joinToString(" · "),
                color = AppleLightGray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
