package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WatchlistItem
import com.example.data.network.model.StremioMetaSummary
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleWhite
import com.example.viewmodel.HomeUiState
import com.example.viewmodel.HomeViewModel
import com.example.viewmodel.MainViewModel

private data class SeriesCatalogRows(
    val popular: List<StremioMetaSummary>,
    val animation: List<StremioMetaSummary>,
    val family: List<StremioMetaSummary>,
    val action: List<StremioMetaSummary>,
    val sciFi: List<StremioMetaSummary>,
    val drama: List<StremioMetaSummary>,
    val thriller: List<StremioMetaSummary>,
    val comedy: List<StremioMetaSummary>,
    val horror: List<StremioMetaSummary>,
    val doc: List<StremioMetaSummary>
)

@Composable
fun SeriesScreen(
    mainViewModel: MainViewModel,
    homeViewModel: HomeViewModel,
    onNavigateToDetail: (String, String) -> Unit
) {
    val homeState by homeViewModel.uiState.collectAsState()
    val watchlist by mainViewModel.watchlist.collectAsState()
    val addons by mainViewModel.addons.collectAsState()
    val continueWatchingList by mainViewModel.continueWatchingList.collectAsState()
    val currentLang by mainViewModel.currentLanguage.collectAsState()

    LaunchedEffect(addons, currentLang) {
        val activeCatalog = addons.firstOrNull { it.isActive && (it.type == "catalog" || it.type == "both") }
        homeViewModel.loadContent(activeCatalog?.url)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppleBlack)
    ) {
        when (val state = homeState) {
            is HomeUiState.Loading -> {
                HomeShimmerSkeleton()
            }
            is HomeUiState.Error -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    androidx.compose.material3.Text(
                        text = "Greška pri učitavanju serija",
                        color = AppleWhite,
                        fontSize = 16.sp
                    )
                }
            }
            is HomeUiState.Success -> {
                // Combine all series from various lists
                val allSeries = remember(state.popularSeries, state.tmdbTop10Tv, state.featuredItems) {
                    (state.popularSeries + state.tmdbTop10Tv + state.featuredItems.filter { it.type == "series" })
                        .distinctBy { it.id }
                        .filter { it.type == "series" }
                }

                // Featured series for Hero Carousel
                val seriesFeatured = remember(allSeries, state.featuredItems) {
                    val fromFeatured = state.featuredItems.filter { it.type == "series" }
                    if (fromFeatured.isNotEmpty()) fromFeatured else allSeries.take(5)
                }

                val seriesWatchlist = remember(watchlist) {
                    watchlist.filter { it.type == "series" }
                }

                val seriesContinueWatching = remember(continueWatchingList) {
                    continueWatchingList.filter { it.type == "series" }
                }

                // Strictly deduplicated catalog rows across categories
                val catalogRows = remember(allSeries) {
                    val usedIds = mutableSetOf<String>()

                    fun getGenreItems(genreKeys: List<String>, limit: Int = 25): List<StremioMetaSummary> {
                        var items = allSeries.filter { item ->
                            item.id !in usedIds && genreKeys.any { g -> getGenresForMeta(item).contains(g) }
                        }.take(limit)

                        // Fallback if strict deduplication left fewer than 3 items: allow matching items even if used, but prioritizing unused
                        if (items.size < 3) {
                            val extra = allSeries.filter { item ->
                                genreKeys.any { g -> getGenresForMeta(item).contains(g) }
                            }.distinctBy { it.id }
                            items = (items + extra).distinctBy { it.id }.take(limit)
                        }

                        items.forEach { usedIds.add(it.id) }
                        return items
                    }

                    val pop = allSeries.take(10)
                    pop.forEach { usedIds.add(it.id) }

                    val anim = getGenreItems(listOf("Animacija", "Crtani"))
                    val fam = getGenreItems(listOf("Porodični", "Porodicni"))
                    val act = getGenreItems(listOf("Akcija", "Avantura"))
                    val sci = getGenreItems(listOf("Sci-Fi"))
                    val dra = getGenreItems(listOf("Drama"))
                    val thr = getGenreItems(listOf("Triler", "Kriminal"))
                    val com = getGenreItems(listOf("Komedija"))
                    val hor = getGenreItems(listOf("Horor"))
                    val doc = getGenreItems(listOf("Dokumentarni"))

                    SeriesCatalogRows(
                        popular = pop,
                        animation = anim,
                        family = fam,
                        action = act,
                        sciFi = sci,
                        drama = dra,
                        thriller = thr,
                        comedy = com,
                        horror = hor,
                        doc = doc
                    )
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    // 1. Featured Hero Banner Carousel for Series
                    if (seriesFeatured.isNotEmpty()) {
                        item {
                            HeroCarouselBanner(
                                items = seriesFeatured,
                                watchlist = watchlist,
                                onPlayClick = { featuredItem ->
                                    onNavigateToDetail(featuredItem.type, featuredItem.id)
                                },
                                onWatchlistToggle = { featuredItem ->
                                    val isInList = watchlist.any { it.id == featuredItem.id }
                                    mainViewModel.toggleWatchlist(
                                        WatchlistItem(
                                            id = featuredItem.id,
                                            title = featuredItem.name,
                                            type = featuredItem.type,
                                            poster = featuredItem.poster,
                                            backdrop = featuredItem.background,
                                            year = featuredItem.releaseInfo,
                                            rating = featuredItem.imdbRating
                                        ),
                                        isInList
                                    )
                                },
                                onClick = { featuredItem ->
                                    onNavigateToDetail(featuredItem.type, featuredItem.id)
                                }
                            )
                        }
                    }

                    // 2. Continue Watching (Series)
                    if (seriesContinueWatching.isNotEmpty()) {
                        item {
                            ContinueWatchingRow(
                                list = seriesContinueWatching,
                                onNavigateToDetail = onNavigateToDetail,
                                onRemoveItem = { id -> mainViewModel.removeFromContinueWatching(id) }
                            )
                        }
                    }

                    // 3. Watchlist (Series)
                    if (seriesWatchlist.isNotEmpty()) {
                        item {
                            WatchlistRow(
                                list = seriesWatchlist,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // Domaci Serije
                    if (state.domaciSeries.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Домаћи Серије",
                                items = state.domaciSeries,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 4. Popular Series
                    if (catalogRows.popular.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Najpopularnije Serije",
                                items = catalogRows.popular,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 5. Crtani & Animirane Serije
                    if (catalogRows.animation.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Crtani & Animirane Serije",
                                items = catalogRows.animation,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 6. Porodične Serije
                    if (catalogRows.family.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Porodične Serije",
                                items = catalogRows.family,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 7. Akcione & Avanturističke Serije
                    if (catalogRows.action.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Akcione & Avanturističke Serije",
                                items = catalogRows.action,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 8. Sci-Fi & Fantazija
                    if (catalogRows.sciFi.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Sci-Fi & Fantazija",
                                items = catalogRows.sciFi,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 9. TV Drame
                    if (catalogRows.drama.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "TV Drame",
                                items = catalogRows.drama,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 10. Kriminalističke & Trileri
                    if (catalogRows.thriller.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Kriminalističke & Trileri",
                                items = catalogRows.thriller,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 11. Humorističke Serije
                    if (catalogRows.comedy.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Humorističke Serije",
                                items = catalogRows.comedy,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 12. Horor Serije
                    if (catalogRows.horror.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Horor Serije",
                                items = catalogRows.horror,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }

                    // 13. Dokumentarne Serije
                    if (catalogRows.doc.isNotEmpty()) {
                        item {
                            CatalogRow(
                                title = "Dokumentarne Serije",
                                items = catalogRows.doc,
                                onNavigateToDetail = onNavigateToDetail
                            )
                        }
                    }
                }
            }
        }
    }
}
