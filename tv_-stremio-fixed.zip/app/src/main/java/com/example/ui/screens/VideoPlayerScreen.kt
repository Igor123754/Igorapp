package com.example.ui.screens

import okhttp3.OkHttpClient
import androidx.media3.datasource.okhttp.OkHttpDataSource
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.util.Log
import android.util.TypedValue
import com.example.data.network.model.StremioStream
import com.example.data.repository.MovieRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.ui.components.AppleTvSpinner
import com.example.ui.theme.AppleAccentBlue
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleWhite
import kotlinx.coroutines.delay
import java.util.Locale

data class AudioTrackItem(
    val id: String,
    val name: String,
    val language: String,
    val trackGroup: Tracks.Group,
    val trackIndex: Int,
    val isSelected: Boolean
)

data class SubtitleTrackItem(
    val id: String,
    val name: String,
    val language: String,
    val trackGroup: Tracks.Group,
    val trackIndex: Int,
    val isSelected: Boolean
)

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    title: String,
    url: String,
    headers: Map<String, String>? = null,
    availableStreams: List<StremioStream> = emptyList(),
    metaName: String? = null,
    metaType: String? = null,
    logoUrl: String? = null,
    season: Int? = null,
    episode: Int? = null,
    mediaId: String? = null,
    startPosition: Long = 0L,
    onProgressUpdate: (Long, Long) -> Unit = { _, _ -> },
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    DisposableEffect(activity) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    val cleanUrl = remember(url) {
        url.trim().replace(" ", "%20")
    }

    BackHandler {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        onBack()
    }

    // Single Unified MPV / 4K High-Performance Video Player Engine
    val exoPlayer = remember(context, cleanUrl) {
            configureGlobalSslTrust()
            val customHeaders = headers ?: emptyMap()
            val defaultUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"
            val userAgent = customHeaders["User-Agent"]
                ?: customHeaders["user-agent"]
                ?: defaultUserAgent

            val requestProperties = mutableMapOf<String, String>()
            requestProperties["Accept"] = "*/*"
            requestProperties["Accept-Language"] = "en-US,en;q=0.9"
            requestProperties.putAll(customHeaders)
            requestProperties["User-Agent"] = userAgent

            val cleanUrlLower = cleanUrl.lowercase()
            if (cleanUrlLower.contains("file-upload")) {
                if (!requestProperties.keys.any { it.equals("Referer", ignoreCase = true) }) {
                    requestProperties["Referer"] = "https://file-upload.org/"
                }
                if (!requestProperties.keys.any { it.equals("Origin", ignoreCase = true) }) {
                    requestProperties["Origin"] = "https://file-upload.org"
                }
            } else if (cleanUrlLower.contains("bilosta")) {
                if (!requestProperties.keys.any { it.equals("Referer", ignoreCase = true) }) {
                    requestProperties["Referer"] = "https://storage.bilosta.org/"
                }
            } else if (cleanUrlLower.contains("domaci") || cleanUrlLower.contains("vercel")) {
                if (!requestProperties.keys.any { it.equals("Referer", ignoreCase = true) }) {
                    requestProperties["Referer"] = "https://domaci-filmovi-addon.vercel.app/"
                }
            } else if (!requestProperties.keys.any { it.equals("Referer", ignoreCase = true) }) {
                try {
                    val parsedUri = Uri.parse(cleanUrl)
                    if (parsedUri.host != null) {
                        requestProperties["Referer"] = "${parsedUri.scheme ?: "https"}://${parsedUri.host}/"
                    }
                } catch (e: Exception) {}
            }

            val okHttpClient = OkHttpClient.Builder()
                .followRedirects(true)
                .followSslRedirects(true)
                .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .addInterceptor { chain ->
                    val original = chain.request()
                    val builder = original.newBuilder()
                    requestProperties.forEach { (k, v) ->
                        builder.header(k, v)
                    }
                    val response = chain.proceed(builder.build())
                    val contentType = response.body?.contentType()?.toString()?.lowercase() ?: ""
                    if (response.isSuccessful && (contentType.contains("text/html") || contentType.contains("text/plain") || contentType.contains("application/json"))) {
                        val source = response.body?.source()
                        source?.request(150)
                        val buffer = source?.buffer?.clone()
                        val preview = buffer?.readUtf8(minOf(150L, buffer.size))?.lowercase() ?: ""
                        if (preview.contains("<!doctype") || preview.contains("<html") || preview.contains("<head") || preview.contains("access denied")) {
                            throw java.io.IOException("Izvor je vratio web stranicu umesto video strima.")
                        }
                    }
                    response
                }
                .build()

            val httpDataSourceFactory = OkHttpDataSource.Factory(okHttpClient)
                .setUserAgent(userAgent)

            val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
            val extractorsFactory = DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
            val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)

            val trackSelector = DefaultTrackSelector(context).apply {
                setParameters(
                    buildUponParameters()
                        .setPreferredAudioLanguages("sr", "srp", "hr", "bs", "en", "eng")
                        .setPreferredTextLanguages("sr", "srp", "srb", "hr", "hbs", "bs", "cnr", "en", "eng")
                        .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                )
            }

            // High-performance 4K REMUX buffer allocation (30s min, 300s max)
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                    30000,  // 30 seconds min buffer for high bitrate streams
                    300000, // 5 minutes max buffer
                    2500,   // bufferForPlaybackMs
                    5000    // bufferForPlaybackAfterRebufferMs
                )
                .setPrioritizeTimeOverSizeThresholds(true)
                .setBackBuffer(60000, true)
                .build()

            val renderersFactory = DefaultRenderersFactory(context).apply {
                setEnableDecoderFallback(true)
                setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                setMediaCodecSelector { mimeType, requiresSecureDecoder, requiresTunneling ->
                    val decoders = MediaCodecSelector.DEFAULT.getDecoderInfos(mimeType, requiresSecureDecoder, requiresTunneling)
                    // Prioritize standard Android software decoders or hardware decoders and allow fallback
                    decoders.sortedWith { d1, d2 ->
                        fun score(info: androidx.media3.exoplayer.mediacodec.MediaCodecInfo): Int {
                            val name = info.name.lowercase()
                            return when {
                                name.startsWith("c2.android.") || name.startsWith("omx.google.") -> 10
                                info.hardwareAccelerated -> 8
                                name.contains("goldfish") -> 2
                                else -> 5
                            }
                        }
                        score(d2).compareTo(score(d1))
                    }
                }
            }

            ExoPlayer.Builder(context)
                .setRenderersFactory(renderersFactory)
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .setMediaSourceFactory(mediaSourceFactory)
                .setSeekForwardIncrementMs(10000)
                .setSeekBackIncrementMs(10000)
                .build().apply {
                    playWhenReady = true
                    repeatMode = Player.REPEAT_MODE_OFF
                    videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                    volume = 1.0f
                }
        }

        var isPlaying by remember { mutableStateOf(true) }
        var currentPosition by remember { mutableLongStateOf(startPosition) }
        var duration by remember { mutableLongStateOf(0L) }
        var isBuffering by remember { mutableStateOf(true) }
        var showControls by remember { mutableStateOf(true) }

        var currentStreamUrl by remember(url) { mutableStateOf(url) }
        var currentStreamTitle by remember(title) { mutableStateOf(title) }
        var currentHeaders by remember(headers) { mutableStateOf(headers) }
        var currentStreamIndex by remember { mutableIntStateOf(0) }

        var volume by remember { mutableFloatStateOf(1.0f) }
        var showVolumeSlider by remember { mutableStateOf(false) }
        var showMoreMenu by remember { mutableStateOf(false) }
        var activeSubMenu by remember { mutableStateOf<MoreSubMenu?>(null) }

        var audioTracks by remember { mutableStateOf<List<AudioTrackItem>>(emptyList()) }
        var selectedAudioTrackId by remember { mutableStateOf<String?>(null) }

        var subtitleTracks by remember { mutableStateOf<List<SubtitleTrackItem>>(emptyList()) }
        var selectedSubtitleTrackId by remember { mutableStateOf<String?>(null) }

        var playerError by remember { mutableStateOf<String?>(null) }
        var hasAttemptedAutoFallback by remember { mutableStateOf(false) }

        val movieRepository = remember { MovieRepository() }

        fun switchStream(newStream: StremioStream, index: Int = -1) {
            val targetUrl = newStream.url?.trim()?.replace(" ", "%20") ?: return
            currentStreamUrl = targetUrl
            currentStreamTitle = newStream.title ?: newStream.name ?: "Izvor ${if (index >= 0) index + 1 else ""}"
            currentHeaders = newStream.behaviorHints?.headers ?: newStream.headers
            if (index >= 0) currentStreamIndex = index
            playerError = null
            hasAttemptedAutoFallback = false
        }

        // Start playing the URL with robust format auto-sniffing
        LaunchedEffect(currentStreamUrl) {
            playerError = null
            hasAttemptedAutoFallback = false
            try {
                val cleanUrl = currentStreamUrl.trim().replace(" ", "%20")
                val lower = cleanUrl.lowercase()
                val mediaItem = if (lower.endsWith(".m3u8") || lower.contains(".m3u8?")) {
                    MediaItem.Builder()
                        .setUri(cleanUrl)
                        .setMimeType(MimeTypes.APPLICATION_M3U8)
                        .build()
                } else if (lower.endsWith(".mpd") || lower.contains(".mpd?")) {
                    MediaItem.Builder()
                        .setUri(cleanUrl)
                        .setMimeType(MimeTypes.APPLICATION_MPD)
                        .build()
                } else {
                    MediaItem.fromUri(cleanUrl)
                }
                exoPlayer.setMediaItem(mediaItem)
                if (currentPosition > 0L) {
                    exoPlayer.seekTo(currentPosition)
                } else if (startPosition > 0L) {
                    exoPlayer.seekTo(startPosition)
                }
                exoPlayer.prepare()
                exoPlayer.play()
            } catch (e: Exception) {
                playerError = e.localizedMessage ?: "Greška pri inicijalizaciji strima."
            }
        }

        var subtitleSyncOffsetMs by remember { mutableLongStateOf(0L) }
        var originalCues by remember { mutableStateOf<List<com.example.util.SubtitleCue>>(emptyList()) }

        // Fetch OpenSubtitles / Stremio Subtitles asynchronously in background & process with Gemini AI
        LaunchedEffect(mediaId, metaType, season, episode, currentStreamUrl, subtitleSyncOffsetMs) {
            val isDomaci = isDomaciContent(mediaId, currentStreamUrl, metaName, metaType)
            if (!mediaId.isNullOrBlank()) {
                try {
                    val fetchedSubtitles = withContext(Dispatchers.IO) {
                        movieRepository.fetchSubtitles(
                            type = metaType ?: "movie",
                            id = mediaId,
                            season = season,
                            episode = episode
                        )
                    }

                    // Keep both Serbian and English subtitles
                    val availableSubtitles = fetchedSubtitles.filter { sub ->
                        isSerbianLanguage(sub.lang, sub.language) || isEnglishLanguage(sub.lang, sub.language)
                    }

                    val subtitleConfigs = mutableListOf<MediaItem.SubtitleConfiguration>()

                    if (availableSubtitles.isNotEmpty()) {
                        // Priority 1: Check for English or Serbian subtitle to enhance with Gemini AI
                        val primarySub = availableSubtitles.firstOrNull { isEnglishLanguage(it.lang, it.language) }
                            ?: availableSubtitles.firstOrNull { isSerbianLanguage(it.lang, it.language) }
                            ?: availableSubtitles.first()

                        val primaryUrl = primarySub.url?.trim()?.replace(" ", "%20")
                        if (primaryUrl != null) {
                            val geminiVttFile = withContext(Dispatchers.IO) {
                                com.example.util.GeminiSubtitleEngine.prepareAndEnhanceSubtitle(
                                    context = context,
                                    subtitleUrl = primaryUrl,
                                    sourceLang = primarySub.lang ?: "en",
                                    offsetMs = subtitleSyncOffsetMs
                                )
                            }

                            if (geminiVttFile != null && geminiVttFile.exists()) {
                                val geminiConfig = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(geminiVttFile))
                                    .setMimeType(MimeTypes.TEXT_VTT)
                                    .setLanguage("srp")
                                    .setLabel("Srpski")
                                    .setSelectionFlags(if (!isDomaci) C.SELECTION_FLAG_DEFAULT else 0)
                                    .build()
                                subtitleConfigs.add(geminiConfig)
                            }
                        }

                        // Also add original fetched Serbian subtitle tracks
                        availableSubtitles.filter { isSerbianLanguage(it.lang, it.language) }.forEach { sub ->
                            val subUrl = sub.url?.trim()?.replace(" ", "%20") ?: return@forEach
                            val mimeType = when {
                                subUrl.endsWith(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
                                subUrl.endsWith(".srt", ignoreCase = true) -> MimeTypes.APPLICATION_SUBRIP
                                else -> MimeTypes.APPLICATION_SUBRIP
                            }

                            val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.parse(subUrl))
                                .setMimeType(mimeType)
                                .setLanguage("srp")
                                .setLabel("Srpski")
                                .build()
                            subtitleConfigs.add(cfg)
                        }

                        if (subtitleConfigs.isNotEmpty()) {
                            val currentItem = exoPlayer.currentMediaItem
                            if (currentItem != null) {
                                val currentPos = exoPlayer.currentPosition
                                val isPlay = exoPlayer.isPlaying
                                val newItem = currentItem.buildUpon()
                                    .setSubtitleConfigurations(subtitleConfigs)
                                    .build()
                                exoPlayer.setMediaItem(newItem, currentPos)
                                exoPlayer.prepare()
                                if (isPlay) exoPlayer.play()
                            }
                        }
                    }

                    // Auto-enable subtitles for foreign content, disable for domestic content
                    val paramsBuilder = exoPlayer.trackSelectionParameters.buildUpon()
                    if (!isDomaci && subtitleConfigs.isNotEmpty()) {
                        paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setPreferredTextLanguage("srp")
                    } else {
                        paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    }
                    exoPlayer.trackSelectionParameters = paramsBuilder.build()
                } catch (e: Exception) {
                    Log.e("VideoPlayerScreen", "Error loading external subtitles", e)
                }
            } else {
                val paramsBuilder = exoPlayer.trackSelectionParameters.buildUpon()
                if (!isDomaci) {
                    paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setPreferredTextLanguage("srp")
                } else {
                    paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                }
                exoPlayer.trackSelectionParameters = paramsBuilder.build()
            }
        }

        // Listen for player events & track changes
        DisposableEffect(exoPlayer) {
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == Player.STATE_BUFFERING
                    if (exoPlayer.duration > 0L) {
                        duration = exoPlayer.duration
                    }
                }

                override fun onIsPlayingChanged(playing: Boolean) {
                    isPlaying = playing
                }

                override fun onTracksChanged(tracks: Tracks) {
                    val items = mutableListOf<AudioTrackItem>()
                    var selectedId: String? = null

                    val subItems = mutableListOf<SubtitleTrackItem>()
                    var selectedSubId: String? = null

                    for (group in tracks.groups) {
                        if (group.type == C.TRACK_TYPE_AUDIO) {
                            val mediaTrackGroup = group.mediaTrackGroup
                            for (i in 0 until group.length) {
                                val format = group.getTrackFormat(i)
                                val isSelected = group.isTrackSelected(i)
                                val lang = format.language ?: "und"

                                val langName = when (lang.lowercase(Locale.ROOT)) {
                                    "en", "eng" -> "Engleski"
                                    "sr", "srp", "srb", "hr", "hbs", "bs", "cnr" -> "Srpski / Ex-YU"
                                    "de", "ger" -> "Nemački"
                                    "fr", "fre" -> "Francuski"
                                    "es", "spa" -> "Španski"
                                    "it", "ita" -> "Italijanski"
                                    "ru", "rus" -> "Ruski"
                                    "ja", "jpn" -> "Japanski"
                                    "zh", "zho", "chi" -> "Kineski"
                                    "und" -> "Audio Zvuk #${items.size + 1}"
                                    else -> lang.uppercase(Locale.ROOT)
                                }

                                val trackLabel = format.label?.takeIf { it.isNotBlank() } ?: langName
                                val codecInfo = format.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT) ?: ""
                                val channelsInfo = when (format.channelCount) {
                                    6 -> "5.1"
                                    8 -> "7.1"
                                    2 -> "Stereo"
                                    1 -> "Mono"
                                    else -> ""
                                }

                                val details = listOfNotNull(
                                    codecInfo.takeIf { it.isNotBlank() },
                                    channelsInfo.takeIf { it.isNotBlank() }
                                ).joinToString(" ")

                                val fullDisplayName = if (details.isNotBlank()) "$trackLabel ($details)" else trackLabel
                                val trackId = "${mediaTrackGroup.id}_$i"

                                val item = AudioTrackItem(
                                    id = trackId,
                                    name = fullDisplayName,
                                    language = lang,
                                    trackGroup = group,
                                    trackIndex = i,
                                    isSelected = isSelected
                                )
                                items.add(item)
                                if (isSelected) {
                                    selectedId = trackId
                                }
                            }
                        } else if (group.type == C.TRACK_TYPE_TEXT) {
                            val mediaTrackGroup = group.mediaTrackGroup
                            for (i in 0 until group.length) {
                                val format = group.getTrackFormat(i)
                                val isSelected = group.isTrackSelected(i)
                                val lang = format.language ?: "und"
                                val label = format.label ?: ""

                                // Display ONLY Serbian subtitle tracks to the user
                                if (isSerbianLanguage(lang, label) || lang == "srp") {
                                    val trackLabel = "Srpski"
                                    val trackId = "${mediaTrackGroup.id}_$i"

                                    val item = SubtitleTrackItem(
                                        id = trackId,
                                        name = trackLabel,
                                        language = "srp",
                                        trackGroup = group,
                                        trackIndex = i,
                                        isSelected = isSelected
                                    )
                                    // Avoid duplicate "Srpski" entries in UI if already present
                                    if (subItems.none { it.name == "Srpski" } || isSelected) {
                                        if (isSelected) {
                                            subItems.removeAll { it.name == "Srpski" }
                                        }
                                        subItems.add(item)
                                    }
                                    if (isSelected) {
                                        selectedSubId = trackId
                                    }
                                }
                            }
                        }
                    }
                    audioTracks = items
                    selectedAudioTrackId = selectedId

                    subtitleTracks = subItems
                    val isDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
                    selectedSubtitleTrackId = if (isDisabled) "OFF" else selectedSubId
                }

                override fun onPlayerError(error: PlaybackException) {
                    isBuffering = false
                    val cause = error.cause?.message ?: error.message ?: "Nepodržan format ili greška na serveru."
                    
                    if (!hasAttemptedAutoFallback) {
                        hasAttemptedAutoFallback = true
                        try {
                            val cleanUrl = url.trim().replace(" ", "%20")
                            val fallbackItem = if (cause.contains("EXTM3U", ignoreCase = true) || cause.contains("contentIsMalformed", ignoreCase = true)) {
                                MediaItem.Builder()
                                    .setUri(cleanUrl)
                                    .setMimeType(MimeTypes.VIDEO_MP4)
                                    .build()
                            } else {
                                MediaItem.fromUri(cleanUrl)
                            }
                            exoPlayer.setMediaItem(fallbackItem)
                            exoPlayer.prepare()
                            exoPlayer.play()
                            return
                        } catch (e: Exception) {
                            // Proceed to error overlay
                        }
                    }

                    playerError = when {
                        cause.contains("decoder", ignoreCase = true) || cause.contains("goldfish", ignoreCase = true) || cause.contains("codec", ignoreCase = true) ->
                            "Uređaj nema podršku za ovaj video dekoder (HEVC / 4K). Izaberite 1080p ili 720p izvor sa spiska."
                        cause.contains("EXTM3U", ignoreCase = true) || cause.contains("contentIsMalformed", ignoreCase = true) || cause.contains("strima", ignoreCase = true) ->
                            "Izabrani izvor je trenutno nedostupan ili nevažeći. Izaberite drugi izvor sa spiska."
                        else ->
                            "Greška pri učitavanju strima. Izaberite drugi izvor sa spiska ($cause)."
                    }
                }
            }
            exoPlayer.addListener(listener)
            onDispose {
                onProgressUpdate(exoPlayer.currentPosition.coerceAtLeast(0L), exoPlayer.duration.coerceAtLeast(0L))
                exoPlayer.removeListener(listener)
                exoPlayer.release()
            }
        }

        // Keep track of current playback position locally (throttled database updates to prevent lag)
        LaunchedEffect(isPlaying) {
            var lastSavedPos = currentPosition
            while (isPlaying) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration.coerceAtLeast(0L)
                currentPosition = pos
                if (dur > 0L) {
                    duration = dur
                }
                // Save progress to database every 10 seconds to avoid continuous Room DB writes & recomposition thrashes
                if (Math.abs(pos - lastSavedPos) >= 10000L) {
                    lastSavedPos = pos
                    onProgressUpdate(pos, dur)
                }
                delay(1000L)
            }
        }

        // Auto-hide controls after 5 seconds of inactivity
        LaunchedEffect(showControls, showMoreMenu, showVolumeSlider) {
            if (showControls && !showMoreMenu && !showVolumeSlider) {
                delay(5000L)
                showControls = false
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(AppleBlack)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (showMoreMenu || showVolumeSlider) {
                        showMoreMenu = false
                        showVolumeSlider = false
                        activeSubMenu = null
                    } else {
                        showControls = !showControls
                    }
                }
        ) {
            // Real Player view with official high-contrast Serbian subtitles styling
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        subtitleView?.apply {
                            setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                            setStyle(
                                CaptionStyleCompat(
                                    android.graphics.Color.WHITE,
                                    android.graphics.Color.argb(180, 0, 0, 0),
                                    android.graphics.Color.TRANSPARENT,
                                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                                    android.graphics.Color.BLACK,
                                    null
                                )
                            )
                        }
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            if (isBuffering) {
                AppleTvSpinner(
                    modifier = Modifier.align(Alignment.Center),
                    size = 56.dp,
                    color = AppleWhite
                )
            }

            // Custom elegant Apple TV+ controls overlay
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // TOP BAR: Left ('X' + Logo) & Right (Expanded Volume Slider Bar)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopStart),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left: 'X' button & Clear Logo
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                    onBack()
                                },
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = Color.White.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Zatvori",
                                    tint = AppleWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            if (!logoUrl.isNullOrBlank()) {
                                Spacer(modifier = Modifier.width(16.dp))
                                AsyncImage(
                                    model = logoUrl,
                                    contentDescription = metaName ?: title,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .height(44.dp)
                                        .widthIn(max = 200.dp)
                                )
                            }
                        }

                        // Right: Speaker Icon & Precise Expanded Volume Slider Bar (220.dp width)
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (showVolumeSlider) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .padding(end = 12.dp)
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(Color.Black.copy(alpha = 0.75f))
                                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
                                        .padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeMute,
                                        contentDescription = null,
                                        tint = AppleWhite.copy(alpha = 0.6f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Slider(
                                        value = volume,
                                        onValueChange = { newVol ->
                                            volume = newVol
                                            exoPlayer.volume = newVol
                                        },
                                        colors = SliderDefaults.colors(
                                            thumbColor = AppleWhite,
                                            activeTrackColor = AppleWhite,
                                            inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                        ),
                                        modifier = Modifier.width(220.dp) // Expanded width for precise volume tuning
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = null,
                                        tint = AppleWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    showVolumeSlider = !showVolumeSlider
                                    showMoreMenu = false
                                },
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = if (showVolumeSlider) AppleWhite.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = if (volume <= 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Zvuk",
                                    tint = AppleWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            IconButton(
                                onClick = {
                                    playerError = null
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                },
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = Color.White.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Osveži strim",
                                    tint = AppleWhite,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }

                    // CENTER PLAYBACK CONTROLS (Clean Apple TV style without white circular container background)
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = {
                                val target = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                                currentPosition = target
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.Transparent
                            ),
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Replay10,
                                contentDescription = "Premotaj nazad",
                                tint = AppleWhite,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(44.dp))
                        IconButton(
                            onClick = {
                                // Instant responsive toggle
                                if (isPlaying) {
                                    exoPlayer.pause()
                                    isPlaying = false
                                } else {
                                    exoPlayer.play()
                                    isPlaying = true
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.Transparent
                            ),
                            modifier = Modifier.size(72.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Pusti/pauziraj",
                                tint = AppleWhite,
                                modifier = Modifier.size(54.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(44.dp))
                        IconButton(
                            onClick = {
                                val target = (exoPlayer.currentPosition + 10000L).coerceAtMost(duration)
                                exoPlayer.seekTo(target)
                                currentPosition = target
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.Transparent
                            ),
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Forward10,
                                contentDescription = "Premotaj napred",
                                tint = AppleWhite,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    // BOTTOM CONTROLS CONTAINER
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val isSeries = metaType == "series" || season != null || episode != null
                            Column(modifier = Modifier.weight(1f)) {
                                if (isSeries) {
                                    val cleanEpTitle = if (!metaName.isNullOrBlank() && title.contains(metaName, ignoreCase = true)) {
                                        title.replace(metaName, "", ignoreCase = true)
                                            .removePrefix(" - ")
                                            .removePrefix(": ")
                                            .trim()
                                            .ifBlank { title }
                                    } else {
                                        title
                                    }

                                    val seasonEpCode = if (season != null && episode != null) "S$season:E$episode" else null
                                    val episodeDisplay = listOfNotNull(cleanEpTitle.takeIf { it.isNotBlank() }, seasonEpCode).joinToString(" • ")

                                    Text(
                                        text = episodeDisplay,
                                        color = AppleWhite.copy(alpha = 0.9f),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Normal,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = metaName ?: title,
                                        color = AppleWhite,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                } else {
                                    Text(
                                        text = metaName ?: title,
                                        color = AppleWhite,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            // 3-Dots Button (...)
                            Box {
                                IconButton(
                                    onClick = {
                                        showMoreMenu = !showMoreMenu
                                        showVolumeSlider = false
                                        activeSubMenu = null
                                    },
                                    colors = IconButtonDefaults.iconButtonColors(
                                        containerColor = if (showMoreMenu) AppleWhite.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MoreHoriz,
                                        contentDescription = "Opcije",
                                        tint = AppleWhite,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                if (showMoreMenu) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(bottom = 54.dp)
                                    ) {
                                        PlayerMoreOptionsMenu(
                                            audioTracks = audioTracks,
                                            selectedAudioTrackId = selectedAudioTrackId,
                                            subtitleTracks = subtitleTracks,
                                            selectedSubtitleTrackId = selectedSubtitleTrackId,
                                            availableStreams = availableStreams,
                                            currentStreamUrl = currentStreamUrl,
                                            activeSubMenu = activeSubMenu,
                                            onSelectSubMenu = { activeSubMenu = it },
                                            onSelectAudioTrack = { item ->
                                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                                    .buildUpon()
                                                    .setOverrideForType(
                                                        TrackSelectionOverride(
                                                            item.trackGroup.mediaTrackGroup,
                                                            listOf(item.trackIndex)
                                                        )
                                                    )
                                                    .build()
                                                selectedAudioTrackId = item.id
                                                activeSubMenu = null
                                                showMoreMenu = false
                                            },
                                            onSelectSubtitleTrack = { item ->
                                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                                    .buildUpon()
                                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                    .setOverrideForType(
                                                        TrackSelectionOverride(
                                                            item.trackGroup.mediaTrackGroup,
                                                            listOf(item.trackIndex)
                                                        )
                                                    )
                                                    .build()
                                                selectedSubtitleTrackId = item.id
                                                activeSubMenu = null
                                                showMoreMenu = false
                                            },
                                            onSelectStream = { stream, idx ->
                                                switchStream(stream, idx)
                                                activeSubMenu = null
                                                showMoreMenu = false
                                            },
                                            onDisableSubtitles = {
                                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                                    .buildUpon()
                                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                                    .build()
                                                selectedSubtitleTrackId = "OFF"
                                                activeSubMenu = null
                                                showMoreMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Seekbar
                        Slider(
                            value = if (duration > 0) (currentPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                            onValueChange = { percent ->
                                if (duration > 0) {
                                    val newPos = (percent * duration).toLong()
                                    currentPosition = newPos
                                    exoPlayer.seekTo(newPos)
                                }
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = AppleWhite,
                                activeTrackColor = AppleWhite,
                                inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatTime(currentPosition),
                                color = AppleWhite.copy(alpha = 0.9f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            val remainingMs = (duration - currentPosition).coerceAtLeast(0L)
                            Text(
                                text = "-${formatTime(remainingMs)}",
                                color = AppleWhite.copy(alpha = 0.7f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Error Overlay if stream playback fails
            if (playerError != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.94f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.widthIn(max = 480.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = Color(0xFFFFCC00),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Problem sa reprodukcijom strima",
                            color = AppleWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = playerError ?: "Server nije odgovorio ili format videa nije podržan.",
                            color = AppleWhite.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        if (availableStreams.size > 1) {
                            Button(
                                onClick = {
                                    val nextIndex = (currentStreamIndex + 1) % availableStreams.size
                                    val nextStream = availableStreams[nextIndex]
                                    switchStream(nextStream, nextIndex)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = AppleAccentBlue)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Pokušaj sledeći izvor (${(currentStreamIndex + 1) % availableStreams.size + 1}/${availableStreams.size})", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        Button(
                            onClick = {
                                playerError = null
                                try {
                                    val cleanUrl = currentStreamUrl.trim().replace(" ", "%20")
                                    val lower = cleanUrl.lowercase()
                                    val retryItem = if (lower.contains(".m3u8") || lower.contains("m3u8") || lower.contains("/hls/")) {
                                        MediaItem.Builder()
                                            .setUri(cleanUrl)
                                            .setMimeType(MimeTypes.APPLICATION_M3U8)
                                            .build()
                                    } else {
                                        MediaItem.fromUri(cleanUrl)
                                    }
                                    exoPlayer.setMediaItem(retryItem)
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                } catch (e: Exception) {
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f))
                        ) {
                            Text("Pokušaj ponovo trenutni strim", color = AppleWhite, fontWeight = FontWeight.SemiBold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = { onBack() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AppleWhite.copy(alpha = 0.7f)),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                        ) {
                            Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Izaberi drugi film ili epizodu")
                        }
                    }
                }
            }
        }
    }

enum class MoreSubMenu {
    SOURCES, AUDIO, SUBTITLES
}

@Composable
fun PlayerMoreOptionsMenu(
    audioTracks: List<AudioTrackItem>,
    selectedAudioTrackId: String?,
    subtitleTracks: List<SubtitleTrackItem>,
    selectedSubtitleTrackId: String?,
    availableStreams: List<StremioStream>,
    currentStreamUrl: String,
    activeSubMenu: MoreSubMenu?,
    onSelectSubMenu: (MoreSubMenu?) -> Unit,
    onSelectAudioTrack: (AudioTrackItem) -> Unit,
    onSelectSubtitleTrack: (SubtitleTrackItem) -> Unit,
    onSelectStream: (StremioStream, Int) -> Unit,
    onDisableSubtitles: () -> Unit
) {
    val activeAudioName = audioTracks.find { it.id == selectedAudioTrackId || it.isSelected }?.name
        ?: if (audioTracks.isNotEmpty()) audioTracks.first().name else "Zadani"

    val activeSubName = if (selectedSubtitleTrackId == "OFF") {
        "Isključeno"
    } else {
        subtitleTracks.find { it.id == selectedSubtitleTrackId || it.isSelected }?.name ?: "Isključeno"
    }

    Column(
        modifier = Modifier
            .width(300.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF1E1E24).copy(alpha = 0.95f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
            .padding(vertical = 8.dp)
    ) {
        if (activeSubMenu == null) {
            if (availableStreams.isNotEmpty()) {
                MoreOptionRow(
                    title = "Izvori strima",
                    subtitle = "${availableStreams.size} dostupnih izvora",
                    icon = Icons.Default.List,
                    onClick = { onSelectSubMenu(MoreSubMenu.SOURCES) }
                )
            }
            MoreOptionRow(
                title = "Zvuk",
                subtitle = activeAudioName,
                icon = Icons.Default.GraphicEq,
                onClick = { onSelectSubMenu(MoreSubMenu.AUDIO) }
            )
            MoreOptionRow(
                title = "Titlovi",
                subtitle = activeSubName,
                icon = Icons.Default.Subtitles,
                onClick = { onSelectSubMenu(MoreSubMenu.SUBTITLES) }
            )
        } else if (activeSubMenu == MoreSubMenu.SOURCES) {
            Text(
                text = "Izbor Izvora (${availableStreams.size})",
                color = AppleWhite.copy(alpha = 0.6f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            availableStreams.forEachIndexed { index, stream ->
                val streamUrl = stream.url?.trim()?.replace(" ", "%20") ?: ""
                val isCurrent = streamUrl.isNotBlank() && (streamUrl == currentStreamUrl || stream.url == currentStreamUrl)
                val label = stream.title ?: stream.name ?: "Izvor ${index + 1}"
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectStream(stream, index) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = label,
                            color = if (isCurrent) AppleAccentBlue else AppleWhite,
                            fontSize = 13.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (isCurrent) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = AppleAccentBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        } else if (activeSubMenu == MoreSubMenu.AUDIO) {
            Text(
                text = "Izbor Zvuka (${audioTracks.size})",
                color = AppleWhite.copy(alpha = 0.6f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            if (audioTracks.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectSubMenu(null) }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Zadani Audio Zvuk",
                        color = AppleAccentBlue,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = AppleAccentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }
            } else {
                audioTracks.forEach { trackItem ->
                    val isCurrent = trackItem.id == selectedAudioTrackId || (selectedAudioTrackId == null && trackItem.isSelected)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectAudioTrack(trackItem) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = trackItem.name,
                                color = if (isCurrent) AppleAccentBlue else AppleWhite,
                                fontSize = 14.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                        if (isCurrent) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = AppleAccentBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        } else if (activeSubMenu == MoreSubMenu.SUBTITLES) {
            Text(
                text = "Izbor Titlova (${subtitleTracks.size})",
                color = AppleWhite.copy(alpha = 0.6f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // Option 1: Off (Isključeno)
            val isOff = selectedSubtitleTrackId == "OFF" || (selectedSubtitleTrackId == null && subtitleTracks.none { it.isSelected })
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDisableSubtitles() }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Isključeno",
                    color = if (isOff) AppleAccentBlue else AppleWhite,
                    fontSize = 14.sp,
                    fontWeight = if (isOff) FontWeight.Bold else FontWeight.Medium
                )
                if (isOff) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = AppleAccentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Option 2...N: Extracted Subtitle Tracks (Only Srpski presented to user)
            subtitleTracks.forEach { subItem ->
                val isCurrent = !isOff && (subItem.id == selectedSubtitleTrackId || (selectedSubtitleTrackId == null && subItem.isSelected))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectSubtitleTrack(subItem) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = subItem.name,
                        color = if (isCurrent) AppleAccentBlue else AppleWhite,
                        fontSize = 14.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                    )
                    if (isCurrent) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = AppleAccentBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MoreOptionRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = AppleWhite.copy(alpha = 0.6f),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    color = AppleWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                if (subtitle.isNotBlank()) {
                    Text(
                        text = subtitle,
                        color = AppleWhite.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal
                    )
                }
            }
        }
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AppleWhite.copy(alpha = 0.8f),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun MockPlayerScreen(
    title: String,
    url: String,
    metaName: String? = null,
    metaType: String? = null,
    logoUrl: String? = null,
    season: Int? = null,
    episode: Int? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    val duration = 124 * 60 * 1000L
    var showControls by remember { mutableStateOf(true) }
    var volume by remember { mutableFloatStateOf(1.0f) }
    var showVolumeSlider by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var activeSubMenu by remember { mutableStateOf<MoreSubMenu?>(null) }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(1000L)
            currentPosition = (currentPosition + 1000L).coerceAtMost(duration)
        }
    }

    LaunchedEffect(showControls, showMoreMenu, showVolumeSlider) {
        if (showControls && !showMoreMenu && !showVolumeSlider) {
            delay(5000L)
            showControls = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppleBlack)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                if (showMoreMenu || showVolumeSlider) {
                    showMoreMenu = false
                    showVolumeSlider = false
                    activeSubMenu = null
                } else {
                    showControls = !showControls
                }
            }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1C1C2E),
                            AppleBlack
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(32.dp)
            ) {
                AppleTvSpinner(color = AppleWhite, size = 42.dp)
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Streaming sa Stremio Torrent Izvora",
                    color = AppleWhite.copy(alpha = 0.6f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Aplikacija koristi ugrađeni 4K plejer za reprodukciju ovog video fajla.",
                    color = AppleWhite.copy(alpha = 0.5f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            isPlaying = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleAccentBlue)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pusti u Aplikaciji", color = Color.White)
                    }
                    OutlinedButton(
                        onClick = {
                            try {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                val clip = android.content.ClipData.newPlainText("Torrent Magnet", url)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Magnet link je kopiran!", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Greška pri kopiranju", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AppleWhite),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Kopiraj Link")
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 24.dp, vertical = 16.dp)
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopStart),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onBack() },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Zatvori",
                                tint = AppleWhite,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        if (!logoUrl.isNullOrBlank()) {
                            Spacer(modifier = Modifier.width(16.dp))
                            AsyncImage(
                                model = logoUrl,
                                contentDescription = metaName ?: title,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .height(44.dp)
                                    .widthIn(max = 200.dp)
                            )
                        }
                    }

                    // Volume Control
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (showVolumeSlider) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .padding(end = 12.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(Color.Black.copy(alpha = 0.75f))
                                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeMute,
                                    contentDescription = null,
                                    tint = AppleWhite.copy(alpha = 0.6f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Slider(
                                    value = volume,
                                    onValueChange = { volume = it },
                                    colors = SliderDefaults.colors(
                                        thumbColor = AppleWhite,
                                        activeTrackColor = AppleWhite,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                    ),
                                    modifier = Modifier.width(220.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = AppleWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = { showVolumeSlider = !showVolumeSlider },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (showVolumeSlider) AppleWhite.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = if (volume <= 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = "Zvuk",
                                tint = AppleWhite,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                // CENTER PLAYBACK CONTROLS
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(
                        onClick = { currentPosition = (currentPosition - 10000L).coerceAtLeast(0) },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = Color.White.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.size(56.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Premotaj nazad",
                            tint = AppleWhite,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(36.dp))
                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = AppleWhite
                        ),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Pusti/pauziraj",
                            tint = AppleBlack,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(36.dp))
                    IconButton(
                        onClick = { currentPosition = (currentPosition + 10000L).coerceAtMost(duration) },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = Color.White.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.size(56.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward10,
                            contentDescription = "Premotaj napred",
                            tint = AppleWhite,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                // BOTTOM CONTROLS
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val isSeries = metaType == "series" || season != null || episode != null
                        Column(modifier = Modifier.weight(1f)) {
                            if (isSeries) {
                                val cleanEpTitle = if (!metaName.isNullOrBlank() && title.contains(metaName, ignoreCase = true)) {
                                    title.replace(metaName, "", ignoreCase = true)
                                        .removePrefix(" - ")
                                        .removePrefix(": ")
                                        .trim()
                                        .ifBlank { title }
                                } else {
                                    title
                                }

                                val seasonEpCode = if (season != null && episode != null) "S$season:E$episode" else null
                                val episodeDisplay = listOfNotNull(cleanEpTitle.takeIf { it.isNotBlank() }, seasonEpCode).joinToString(" • ")

                                Text(
                                    text = episodeDisplay,
                                    color = AppleWhite.copy(alpha = 0.9f),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Normal,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = metaName ?: title,
                                    color = AppleWhite,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            } else {
                                Text(
                                    text = metaName ?: title,
                                    color = AppleWhite,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Slider(
                        value = if (duration > 0) currentPosition.toFloat() / duration else 0f,
                        onValueChange = { percent ->
                            currentPosition = (percent * duration).toLong()
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = AppleWhite,
                            activeTrackColor = AppleWhite,
                            inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatTime(currentPosition),
                            color = AppleWhite.copy(alpha = 0.9f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        val remainingMs = (duration - currentPosition).coerceAtLeast(0L)
                        Text(
                            text = "-${formatTime(remainingMs)}",
                            color = AppleWhite.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0L)
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600

    return if (hours > 0) {
        String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
    }
}

private fun configureGlobalSslTrust() {
    try {
        val trustAllCerts = arrayOf<TrustManager>(
            object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
        )
        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, trustAllCerts, java.security.SecureRandom())
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.socketFactory)
        HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun isDomaciContent(mediaId: String?, url: String?, metaName: String?, metaType: String?): Boolean {
    val mId = mediaId?.lowercase(Locale.ROOT) ?: ""
    val u = url?.lowercase(Locale.ROOT) ?: ""
    val name = metaName?.lowercase(Locale.ROOT) ?: ""

    if (mId.contains("domaci") || u.contains("domaci") || mId.startsWith("domaci_") || mId.startsWith("domaci:")) return true
    if (name.contains("domaći") || name.contains("domaci")) return true
    return false
}

private fun isSerbianLanguage(langCode: String?, langName: String?): Boolean {
    val code = langCode?.lowercase(Locale.ROOT) ?: ""
    val name = langName?.lowercase(Locale.ROOT) ?: ""
    return code in listOf("srp", "sr", "srb") ||
            name.contains("serbian") ||
            name.contains("srpski") ||
            code.startsWith("sr")
}

private fun isEnglishLanguage(langCode: String?, langName: String?): Boolean {
    val code = langCode?.lowercase(Locale.ROOT) ?: ""
    val name = langName?.lowercase(Locale.ROOT) ?: ""
    return code in listOf("eng", "en") ||
            name.contains("english") ||
            name.contains("engleski") ||
            code.startsWith("en")
}

fun launchExternalVideoPlayer(context: Context, url: String, title: String?) {
    try {
        val streamUri = Uri.parse(url)
        val mpvIntent = Intent(Intent.ACTION_VIEW).apply {
            setPackage("net.mplayer.mpv")
            setDataAndType(streamUri, "video/*")
            putExtra("title", title ?: "Video Strim")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        
        val packageManager = context.packageManager
        if (mpvIntent.resolveActivity(packageManager) != null) {
            context.startActivity(mpvIntent)
            return
        }

        val genericIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(streamUri, "video/*")
            putExtra("title", title ?: "Video Strim")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(genericIntent, "Izaberite Eksterni Plejer (mpv Android, VLC, MX Player)")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(context, "Nije pronađen mpv ili drugi eksterni plejer na uređaju", Toast.LENGTH_SHORT).show()
    }
}
