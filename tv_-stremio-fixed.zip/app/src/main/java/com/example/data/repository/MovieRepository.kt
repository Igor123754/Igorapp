package com.example.data.repository

import android.util.Log
import com.example.data.network.StremioApiService
import com.example.data.network.TmdbApiService
import com.example.data.network.model.*
import com.example.trailer.CinemetaDebugUtility
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

import com.example.data.network.model.CastMember

data class PersonDetailData(
    val id: Int,
    val name: String,
    val biography: String? = null,
    val birthday: String? = null,
    val placeOfBirth: String? = null,
    val profilePic: String? = null,
    val knownForDepartment: String? = null,
    val imdbId: String? = null,
    val moviesCast: List<PersonCreditItem> = emptyList(),
    val tvCast: List<PersonCreditItem> = emptyList(),
    val directorCredits: List<PersonCreditItem> = emptyList(),
    val producerCredits: List<PersonCreditItem> = emptyList(),
    val writerCredits: List<PersonCreditItem> = emptyList()
)

data class PersonCreditItem(
    val tmdbId: Int,
    val imdbId: String? = null,
    val title: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val mediaType: String,
    val year: String?,
    val rating: String?,
    val role: String?
)

class MovieRepository(
    private val apiService: StremioApiService = StremioApiService.instance,
    private val tmdbApiService: TmdbApiService = TmdbApiService.instance
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .connectionPool(okhttp3.ConnectionPool(32, 5, TimeUnit.MINUTES))
        .build()
    private val fallbackCatalogUrl = "https://v3-cinemeta.strem.io"
    private val tmdbApiKeys = listOf(
        "8476a7ab80ad76f0936744df0430e67c",
        "a7018317e6cb9fc61a6b0c22fa45e31c",
        "c1f20a9df00438cf3845ff60088df673",
        "edc5f590b14644da605f6b216f469950"
    )

    private val tmdbGenresMap = mapOf(
        28 to "Action",
        12 to "Adventure",
        16 to "Animation",
        35 to "Comedy",
        80 to "Crime",
        99 to "Documentary",
        18 to "Drama",
        10751 to "Family",
        14 to "Fantasy",
        36 to "History",
        27 to "Horror",
        10402 to "Music",
        9648 to "Mystery",
        10749 to "Romance",
        878 to "Sci-Fi",
        10770 to "TV Movie",
        53 to "Thriller",
        10752 to "War",
        37 to "Western",
        10759 to "Action & Adventure",
        10762 to "Kids",
        10763 to "News",
        10764 to "Reality",
        10765 to "Sci-Fi & Fantasy",
        10766 to "Soap",
        10767 to "Talk",
        10768 to "War & Politics"
    )

    private val summaryListCache = java.util.concurrent.ConcurrentHashMap<String, List<StremioMetaSummary>>()
    private val memoryCache = java.util.concurrent.ConcurrentHashMap<String, Any>()
    private val metaDetailCache = java.util.concurrent.ConcurrentHashMap<String, StremioMetaDetail>()

    fun clearCache() {
        summaryListCache.clear()
        memoryCache.clear()
        metaDetailCache.clear()
    }

    private suspend fun enrichSummaryList(metas: List<StremioMetaSummary>): List<StremioMetaSummary> = kotlinx.coroutines.coroutineScope {
        val prefLang = getPreferredTmdbLang()
        val semaphore = kotlinx.coroutines.sync.Semaphore(6)

        metas.mapIndexed { index, meta ->
            async {
                if (!meta.id.startsWith("tt")) return@async meta

                val itemCacheKey = "item_${prefLang}_${meta.id}"
                summaryListCache[itemCacheKey]?.let { return@async it.first() }

                val fallbackGenre = meta.genres?.firstOrNull() ?: if (meta.type == "series") "Drama" else "Action"

                // Fast path: If the item already has a poster (or index >= 5), return immediately with fallback genre
                // so catalog sections (especially domestic movies/series) load instantly without sending hundreds of blocking TMDB calls.
                if (index >= 5 || !meta.poster.isNullOrBlank()) {
                    val fastItem = meta.copy(primaryGenre = meta.primaryGenre ?: fallbackGenre)
                    summaryListCache[itemCacheKey] = listOf(fastItem)
                    return@async fastItem
                }

                semaphore.acquire()
                try {
                    for (apiKey in tmdbApiKeys) {
                        try {
                            val findResponse = tmdbApiService.findByImdbId(meta.id, apiKey, language = prefLang)
                            val movieResult = findResponse.movieResults?.firstOrNull()
                            val tvResult = findResponse.tvResults?.firstOrNull()

                            val result = movieResult ?: tvResult
                            if (result != null) {
                                val localizedTitle = (result.title ?: result.name)?.takeIf { it.isNotBlank() } ?: meta.name
                                val localizedOverview = result.overview?.takeIf { it.isNotBlank() } ?: meta.overview
                                val posterUrl = result.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: meta.poster
                                val backdropUrl = result.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" } ?: meta.background

                                val ratingString = if (!meta.imdbRating.isNullOrBlank()) {
                                    meta.imdbRating
                                } else {
                                    result.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }
                                }

                                val firstGenreId = result.genreIds?.firstOrNull()
                                val genreName = firstGenreId?.let { tmdbGenresMap[it] }
                                    ?: meta.genres?.firstOrNull()
                                    ?: if (meta.type == "series") "Drama" else "Action"

                                val enriched = meta.copy(
                                    name = localizedTitle,
                                    poster = posterUrl,
                                    background = backdropUrl,
                                    imdbRating = ratingString,
                                    primaryGenre = genreName,
                                    overview = localizedOverview
                                )

                                summaryListCache[itemCacheKey] = listOf(enriched)
                                return@async enriched
                            }
                        } catch (e: Exception) {
                            // ignore and try next key
                        }
                    }
                } finally {
                    semaphore.release()
                }

                val fallbackItem = meta.copy(primaryGenre = fallbackGenre)
                summaryListCache[itemCacheKey] = listOf(fallbackItem)
                fallbackItem
            }
        }.awaitAll()
    }

    private fun getPreferredTmdbLang(): String {
        return if (com.example.data.local.AppPreferences.getLanguage() == com.example.data.local.AppPreferences.LANG_SR) "sr-RS" else "en-US"
    }

    private suspend fun enrichWithTmdb(meta: StremioMetaDetail): StremioMetaDetail {
        val prefLang = getPreferredTmdbLang()
        val imgLang = if (prefLang.startsWith("sr")) "sr,en,null" else "en,null"

        for (apiKey in tmdbApiKeys) {
            try {
                var movieId: Int? = null
                var tvId: Int? = null

                // 1. Try to find by IMDb ID if meta.id starts with "tt"
                if (meta.id.startsWith("tt")) {
                    val findResponse = tmdbApiService.findByImdbId(meta.id, apiKey, language = prefLang)
                    movieId = findResponse.movieResults?.firstOrNull()?.id
                    tvId = findResponse.tvResults?.firstOrNull()?.id
                }

                // 2. Try parsing tmdb ID directly if meta.id starts with "tmdb:" or is numeric
                if (movieId == null && tvId == null) {
                    val rawId = meta.id.removePrefix("tmdb:")
                    val parsedId = rawId.toIntOrNull()
                    if (parsedId != null) {
                        if (meta.type == "movie") {
                            movieId = parsedId
                        } else {
                            tvId = parsedId
                        }
                    }
                }

                // 3. Search TMDB by title/name if still null
                if (movieId == null && tvId == null) {
                    val year = meta.releaseInfo?.take(4)
                    if (meta.type == "series") {
                        val searchTv = tmdbApiService.searchTv(meta.name, apiKey, year, language = prefLang)
                        tvId = searchTv.tvResults?.firstOrNull()?.id
                    } else {
                        val searchMovie = tmdbApiService.searchMovie(meta.name, apiKey, year, language = prefLang)
                        movieId = searchMovie.movieResults?.firstOrNull()?.id
                    }
                }

                if (movieId != null) {
                    var details = tmdbApiService.getMovieDetails(movieId, apiKey, language = prefLang, includeImageLanguage = imgLang)

                    if (details.overview.isNullOrBlank() && prefLang != "en-US") {
                        try {
                            val enDetails = tmdbApiService.getMovieDetails(movieId, apiKey, language = "en-US", includeImageLanguage = "en,null")
                            if (!enDetails.overview.isNullOrBlank()) {
                                details = details.copy(overview = enDetails.overview)
                            }
                        } catch (e: Exception) {
                            // ignore fallback exception
                        }
                    }

                    val budgetFormatted = details.budget?.let { b ->
                        if (b > 0) {
                            java.text.NumberFormat.getCurrencyInstance(java.util.Locale.US).apply {
                                maximumFractionDigits = 0
                            }.format(b)
                        } else null
                    }

                    val logoUrl = (details.images?.logos?.find { it.iso == "sr" }
                        ?: details.images?.logos?.find { it.iso == "en" }
                        ?: details.images?.logos?.firstOrNull())?.filePath?.let { path ->
                        "https://image.tmdb.org/t/p/original$path"
                    }
                    val resolvedLang = resolveLanguageFromTmdb(details.originalLanguage, details.spokenLanguages)
                    val prodCountries = details.productionCountries?.mapNotNull { it.name }?.filter { it.isNotBlank() }?.joinToString(", ")

                    val directors = details.credits?.crew?.filter { it.job == "Director" || it.department == "Directing" }?.mapNotNull { it.name }?.distinct()
                    val castList = details.credits?.cast?.take(20)?.mapNotNull { it.name }

                    val castMemberList = mutableListOf<CastMember>()
                    // Add Directors first
                    details.credits?.crew?.filter { it.job == "Director" || it.department == "Directing" }?.distinctBy { it.name }?.forEach { crew ->
                        castMemberList.add(
                            CastMember(
                                name = crew.name ?: "Reditelj",
                                role = "Director",
                                character = "Reditelj",
                                profilePic = crew.profilePath?.let { "https://image.tmdb.org/t/p/w185$it" },
                                tmdbPersonId = crew.id
                            )
                        )
                    }
                    // Add Cast members
                    details.credits?.cast?.take(25)?.forEach { cast ->
                        if (!cast.name.isNullOrBlank()) {
                            castMemberList.add(
                                CastMember(
                                    name = cast.name,
                                    role = "Actor",
                                    character = cast.character?.takeIf { it.isNotBlank() },
                                    profilePic = cast.profilePath?.let { "https://image.tmdb.org/t/p/w185$it" },
                                    tmdbPersonId = cast.id
                                )
                            )
                        }
                    }

                    val enrichedCastMembers = enrichCastMembersWithFallback(meta.name, castMemberList)

                    val movieCert = details.releaseDates?.results?.find { it.iso == "US" }?.releaseDates?.mapNotNull { it.certification }?.firstOrNull { it.isNotBlank() }
                        ?: details.releaseDates?.results?.flatMap { it.releaseDates.orEmpty() }?.mapNotNull { it.certification }?.firstOrNull { it.isNotBlank() }

                    var collectionNameResult: String? = null
                    var collectionItemsList: List<StremioMetaSummary>? = null
                    val collectionId = details.belongsToCollection?.id
                    if (collectionId != null && collectionId != 0) {
                        val (colName, colItems) = fetchCollectionForMovie(collectionId, apiKey)
                        collectionNameResult = colName
                        collectionItemsList = colItems
                    }

                    return meta.copy(
                        description = if (!details.overview.isNullOrBlank()) details.overview else meta.description,
                        poster = details.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: meta.poster,
                        background = details.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" } ?: meta.background,
                        logo = logoUrl ?: meta.logo,
                        language = resolvedLang ?: meta.language,
                        country = prodCountries?.takeIf { it.isNotBlank() } ?: meta.country,
                        director = if (!directors.isNullOrEmpty()) directors else meta.director,
                        cast = if (!castList.isNullOrEmpty()) castList else meta.cast,
                        budget = budgetFormatted,
                        castMembers = enrichedCastMembers,
                        certification = movieCert ?: meta.certification,
                        collectionItems = collectionItemsList,
                        collectionName = collectionNameResult
                    )
                } else if (tvId != null) {
                    var details = tmdbApiService.getTvDetails(tvId, apiKey, language = prefLang, includeImageLanguage = imgLang)

                    if (details.overview.isNullOrBlank() && prefLang != "en-US") {
                        try {
                            val enDetails = tmdbApiService.getTvDetails(tvId, apiKey, language = "en-US", includeImageLanguage = "en,null")
                            if (!enDetails.overview.isNullOrBlank()) {
                                details = details.copy(overview = enDetails.overview)
                            }
                        } catch (e: Exception) {
                            // ignore fallback exception
                        }
                    }

                    val logoUrl = (details.images?.logos?.find { it.iso == "sr" }
                        ?: details.images?.logos?.find { it.iso == "en" }
                        ?: details.images?.logos?.firstOrNull())?.filePath?.let { path ->
                        "https://image.tmdb.org/t/p/original$path"
                    }
                    val resolvedLang = resolveLanguageFromTmdb(details.originalLanguage, details.spokenLanguages)
                    val prodCountries = details.productionCountries?.mapNotNull { it.name }?.filter { it.isNotBlank() }?.joinToString(", ")

                    val creators = details.credits?.crew?.filter {
                        it.job == "Executive Producer" || it.job == "Director" || it.department == "Writing" || it.department == "Directing"
                    }?.mapNotNull { it.name }?.distinct()?.take(3)

                    val castList = details.credits?.cast?.take(20)?.mapNotNull { it.name }

                    val castMemberList = mutableListOf<CastMember>()
                    // Add Directors / Creators first
                    details.credits?.crew?.filter { it.job == "Director" || it.job == "Executive Producer" || it.department == "Directing" }?.distinctBy { it.name }?.forEach { crew ->
                        castMemberList.add(
                            CastMember(
                                name = crew.name ?: "Kreator",
                                role = "Director",
                                character = if (crew.job == "Director" || crew.department == "Directing") "Reditelj" else "Kreator",
                                profilePic = crew.profilePath?.let { "https://image.tmdb.org/t/p/w185$it" },
                                tmdbPersonId = crew.id
                            )
                        )
                    }
                    // Add Cast members
                    details.credits?.cast?.take(25)?.forEach { cast ->
                        if (!cast.name.isNullOrBlank()) {
                            castMemberList.add(
                                CastMember(
                                    name = cast.name,
                                    role = "Actor",
                                    character = cast.character?.takeIf { it.isNotBlank() },
                                    profilePic = cast.profilePath?.let { "https://image.tmdb.org/t/p/w185$it" },
                                    tmdbPersonId = cast.id
                                )
                            )
                        }
                    }

                    val enrichedCastMembers = enrichCastMembersWithFallback(meta.name, castMemberList)

                    val tvRating = details.contentRatings?.results?.find { it.iso == "US" }?.rating?.takeIf { it.isNotBlank() }
                        ?: details.contentRatings?.results?.mapNotNull { it.rating }?.firstOrNull { it.isNotBlank() }

                    val firstYear = details.firstAirDate?.take(4)
                    val releaseInfoText = if (firstYear != null) {
                        val lastYear = if (details.inProduction == true) "Present" else details.lastAirDate?.take(4)
                        if (lastYear != null && lastYear != firstYear) "$firstYear - $lastYear" else firstYear
                    } else meta.releaseInfo

                    val runtimeText = details.episodeRunTime?.firstOrNull()?.let { "$it min" } ?: meta.runtime

                    val finalVideos = fetchAndEnrichTvEpisodes(
                        tvId = tvId,
                        apiKey = apiKey,
                        metaVideos = meta.videos,
                        seasons = details.seasons,
                        defaultImdbId = details.externalIds?.imdbId ?: meta.id,
                        backdropUrl = details.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                    ) ?: meta.videos

                    val seasonPostersMap = details.seasons?.mapNotNull { season ->
                        val sNum = season.seasonNumber
                        val pPath = season.posterPath
                        if (sNum != null && !pPath.isNullOrBlank()) {
                            sNum to "https://image.tmdb.org/t/p/w500$pPath"
                        } else null
                    }?.toMap()

                    return meta.copy(
                        description = if (!details.overview.isNullOrBlank()) details.overview else meta.description,
                        poster = details.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: meta.poster,
                        background = details.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" } ?: meta.background,
                        logo = logoUrl ?: meta.logo,
                        language = resolvedLang ?: meta.language,
                        country = prodCountries?.takeIf { it.isNotBlank() } ?: meta.country,
                        director = if (!creators.isNullOrEmpty()) creators else meta.director,
                        cast = if (!castList.isNullOrEmpty()) castList else meta.cast,
                        budget = null,
                        castMembers = enrichedCastMembers,
                        contentRating = tvRating ?: meta.contentRating,
                        releaseInfo = releaseInfoText,
                        runtime = runtimeText,
                        videos = finalVideos,
                        seasonPosters = seasonPostersMap ?: meta.seasonPosters
                    )
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error enriching with TMDB using key $apiKey", e)
            }
        }

        // Fallback: Enrich existing effective cast member names with profile pictures & character roles
        val fallbackMembers = meta.getEffectiveCastMembers()
        if (fallbackMembers.isNotEmpty()) {
            val enriched = enrichCastMembersWithFallback(meta.name, fallbackMembers)
            return meta.copy(castMembers = enriched)
        }

        return meta
    }

    suspend fun resolveImdbId(type: String, tmdbId: Int): String? = withContext(Dispatchers.IO) {
        if (tmdbId <= 0) return@withContext null
        for (apiKey in tmdbApiKeys) {
            try {
                if (type == "movie") {
                    val details = tmdbApiService.getMovieDetails(tmdbId, apiKey)
                    if (!details.imdbId.isNullOrEmpty()) return@withContext details.imdbId
                } else {
                    val details = tmdbApiService.getTvDetails(tmdbId, apiKey)
                    val imdbId = details.externalIds?.imdbId
                    if (!imdbId.isNullOrEmpty()) return@withContext imdbId
                }
            } catch (e: Exception) {
                break
            }
        }
        null
    }

    suspend fun getPersonDetails(personName: String, tmdbPersonId: Int? = null, initialProfilePic: String? = null): PersonDetailData? = withContext(Dispatchers.IO) {
        for (apiKey in tmdbApiKeys) {
            try {
                var targetPersonId = tmdbPersonId
                var details: TmdbPersonDetailsResponse? = null

                if (targetPersonId != null && targetPersonId > 0) {
                    try {
                        details = tmdbApiService.getPersonDetails(targetPersonId, apiKey)
                    } catch (e: Exception) {
                        Log.w("MovieRepository", "Failed to fetch person details for ID $targetPersonId, falling back to search", e)
                        targetPersonId = null
                    }
                }

                if (details == null) {
                    val searchResponse = tmdbApiService.searchPerson(personName, apiKey)
                    val topResult = searchResponse.results?.firstOrNull()
                    if (topResult != null && topResult.id > 0) {
                        targetPersonId = topResult.id
                        details = tmdbApiService.getPersonDetails(targetPersonId, apiKey)
                    }
                }

                if (details != null) {
                    val credits = details.combinedCredits

                    val moviesCast = mutableListOf<PersonCreditItem>()
                    val tvCast = mutableListOf<PersonCreditItem>()
                    val directorCredits = mutableListOf<PersonCreditItem>()
                    val producerCredits = mutableListOf<PersonCreditItem>()
                    val writerCredits = mutableListOf<PersonCreditItem>()

                    credits?.cast?.forEach { credit ->
                        val item = PersonCreditItem(
                            tmdbId = credit.id,
                            title = credit.title ?: credit.name ?: "Nepoznato",
                            posterUrl = credit.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" },
                            backdropUrl = credit.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" },
                            mediaType = credit.mediaType ?: if (credit.title != null) "movie" else "series",
                            year = credit.releaseDate?.take(4) ?: credit.firstAirDate?.take(4),
                            rating = credit.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) },
                            role = credit.character
                        )
                        if (item.mediaType == "movie") {
                            moviesCast.add(item)
                        } else {
                            tvCast.add(item)
                        }
                    }

                    credits?.crew?.forEach { credit ->
                        val item = PersonCreditItem(
                            tmdbId = credit.id,
                            title = credit.title ?: credit.name ?: "Nepoznato",
                            posterUrl = credit.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" },
                            backdropUrl = credit.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" },
                            mediaType = credit.mediaType ?: if (credit.title != null) "movie" else "series",
                            year = credit.releaseDate?.take(4) ?: credit.firstAirDate?.take(4),
                            rating = credit.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) },
                            role = credit.job ?: credit.department
                        )
                        val job = credit.job ?: ""
                        val dept = credit.department ?: ""
                        when {
                            job == "Director" || dept == "Directing" -> directorCredits.add(item)
                            job.contains("Producer") || dept == "Production" -> producerCredits.add(item)
                            dept == "Writing" || job.contains("Writer") || job == "Screenplay" -> writerCredits.add(item)
                        }
                    }

                    val profilePicUrl = details.profilePath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: initialProfilePic

                    return@withContext PersonDetailData(
                        id = details.id,
                        name = details.name ?: personName,
                        biography = details.biography,
                        birthday = details.birthday,
                        placeOfBirth = details.placeOfBirth,
                        profilePic = profilePicUrl,
                        knownForDepartment = details.knownForDepartment,
                        imdbId = details.externalIds?.imdbId,
                        moviesCast = moviesCast.distinctBy { it.tmdbId },
                        tvCast = tvCast.distinctBy { it.tmdbId },
                        directorCredits = directorCredits.distinctBy { it.tmdbId },
                        producerCredits = producerCredits.distinctBy { it.tmdbId },
                        writerCredits = writerCredits.distinctBy { it.tmdbId }
                    )
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error getting person details for $personName using key $apiKey", e)
            }
        }

        fetchPersonFallbackData(personName, tmdbPersonId, initialProfilePic)
    }

    private suspend fun fetchPersonFallbackData(personName: String, tmdbPersonId: Int?, initialProfilePic: String? = null): PersonDetailData = withContext(Dispatchers.IO) {
        var bio: String? = null
        var profilePic: String? = null
        var birthday: String? = null

        val encodedName = try { URLEncoder.encode(personName, "UTF-8") } catch (e: Exception) { personName }

        val client = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()

        // 1. Wikipedia Search for Biography & Image
        try {
            val wikiUrl = "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$encodedName&gsrlimit=1&prop=extracts|pageimages&exintro=1&explaintext=1&pithumbsize=600&format=json"
            val req = Request.Builder().url(wikiUrl).addHeader("User-Agent", "MovieApp/1.0").build()
            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrBlank()) {
                        val json = JSONObject(body)
                        val queryObj = json.optJSONObject("query")
                        val pagesObj = queryObj?.optJSONObject("pages")
                        if (pagesObj != null) {
                            val keys = pagesObj.keys()
                            if (keys.hasNext()) {
                                val page = pagesObj.getJSONObject(keys.next())
                                bio = page.optString("extract", "").ifBlank { null }
                                val thumb = page.optJSONObject("thumbnail")
                                if (thumb != null) {
                                    profilePic = thumb.optString("source", "").ifBlank { null }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("MovieRepository", "Wikipedia fetch failed for $personName", e)
        }

        // 2. TVMaze Search for Photo & Birthday
        try {
            val tvUrl = "https://api.tvmaze.com/search/people?q=$encodedName"
            val req = Request.Builder().url(tvUrl).addHeader("User-Agent", "MovieApp/1.0").build()
            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrBlank()) {
                        val arr = JSONArray(body)
                        if (arr.length() > 0) {
                            val personObj = arr.getJSONObject(0).optJSONObject("person")
                            if (personObj != null) {
                                if (birthday == null) {
                                    birthday = personObj.optString("birthday", "").ifBlank { null }
                                }
                                if (profilePic == null) {
                                    val imgObj = personObj.optJSONObject("image")
                                    if (imgObj != null) {
                                        profilePic = imgObj.optString("original", "").ifBlank { imgObj.optString("medium", "") }.ifBlank { null }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("MovieRepository", "TVMaze fetch failed for $personName", e)
        }

        // 3. Cinemeta Movie & TV Catalog Search
        val moviesCast = mutableListOf<PersonCreditItem>()
        val tvCast = mutableListOf<PersonCreditItem>()

        try {
            val cmUrl = "https://v3-cinemeta.strem.io/catalog/movie/top/search=$encodedName.json"
            val req = Request.Builder().url(cmUrl).build()
            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrBlank()) {
                        val json = JSONObject(body)
                        val metas = json.optJSONArray("metas")
                        if (metas != null) {
                            for (i in 0 until metas.length()) {
                                val item = metas.getJSONObject(i)
                                val id = item.optString("id", "")
                                val name = item.optString("name", "")
                                val poster = item.optString("poster", "").ifBlank { null }
                                val bg = item.optString("background", "").ifBlank { null }
                                val year = item.optString("year", "").take(4).ifBlank { null }
                                val rating = item.optString("imdbRating", "").ifBlank { null }

                                if (id.isNotBlank() && name.isNotBlank()) {
                                    val credit = PersonCreditItem(
                                        tmdbId = id.hashCode(),
                                        imdbId = id,
                                        title = name,
                                        posterUrl = poster,
                                        backdropUrl = bg,
                                        mediaType = "movie",
                                        year = year,
                                        rating = rating,
                                        role = null
                                    )
                                    moviesCast.add(credit)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("MovieRepository", "Cinemeta movie search failed for $personName", e)
        }

        try {
            val csUrl = "https://v3-cinemeta.strem.io/catalog/series/top/search=$encodedName.json"
            val req = Request.Builder().url(csUrl).build()
            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrBlank()) {
                        val json = JSONObject(body)
                        val metas = json.optJSONArray("metas")
                        if (metas != null) {
                            for (i in 0 until metas.length()) {
                                val item = metas.getJSONObject(i)
                                val id = item.optString("id", "")
                                val name = item.optString("name", "")
                                val poster = item.optString("poster", "").ifBlank { null }
                                val bg = item.optString("background", "").ifBlank { null }
                                val year = item.optString("year", "").take(4).ifBlank { null }
                                val rating = item.optString("imdbRating", "").ifBlank { null }

                                if (id.isNotBlank() && name.isNotBlank()) {
                                    val credit = PersonCreditItem(
                                        tmdbId = id.hashCode(),
                                        imdbId = id,
                                        title = name,
                                        posterUrl = poster,
                                        backdropUrl = bg,
                                        mediaType = "series",
                                        year = year,
                                        rating = rating,
                                        role = null
                                    )
                                    tvCast.add(credit)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("MovieRepository", "Cinemeta series search failed for $personName", e)
        }

        PersonDetailData(
            id = tmdbPersonId ?: personName.hashCode(),
            name = personName,
            biography = bio ?: "Podaci o biografiji za $personName trenutno nisu dostupni.",
            birthday = birthday,
            placeOfBirth = null,
            profilePic = profilePic ?: initialProfilePic,
            knownForDepartment = "Filmski radnik",
            imdbId = null,
            moviesCast = moviesCast.distinctBy { it.imdbId ?: it.title },
            tvCast = tvCast.distinctBy { it.imdbId ?: it.title },
            directorCredits = emptyList(),
            producerCredits = emptyList(),
            writerCredits = emptyList()
        )
    }

    private suspend fun enrichCastMembersWithFallback(title: String, members: List<CastMember>): List<CastMember> = withContext(Dispatchers.IO) {
        if (members.isEmpty()) return@withContext emptyList()

        val client = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()

        val encodedTitle = try { URLEncoder.encode(title, "UTF-8") } catch (e: Exception) { title }
        val tvMazeMap = mutableMapOf<String, Pair<String?, String?>>()

        try {
            val tvUrl = "https://api.tvmaze.com/singlesearch/shows?q=$encodedTitle&embed=cast"
            val req = Request.Builder().url(tvUrl).addHeader("User-Agent", "MovieApp/1.0").build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val body = resp.body?.string()
                    if (!body.isNullOrBlank()) {
                        val json = JSONObject(body)
                        val castArr = json.optJSONObject("_embedded")?.optJSONArray("cast")
                        if (castArr != null) {
                            for (i in 0 until castArr.length()) {
                                val item = castArr.getJSONObject(i)
                                val pObj = item.optJSONObject("person")
                                val cObj = item.optJSONObject("character")
                                val pName = pObj?.optString("name")
                                val cName = cObj?.optString("name")
                                val imgObj = pObj?.optJSONObject("image")
                                val img = imgObj?.optString("medium", "")?.ifBlank { imgObj.optString("original", "") }?.ifBlank { null }
                                if (!pName.isNullOrBlank()) {
                                    tvMazeMap[pName.lowercase()] = Pair(cName?.ifBlank { null }, img)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("MovieRepository", "TVMaze show cast fetch failed for $title", e)
        }

        members.take(15).map { member ->
            async {
                var charName = member.character
                var picUrl = member.profilePic

                val matched = tvMazeMap[member.name.lowercase()]
                if (matched != null) {
                    if ((charName.isNullOrBlank() || charName == "Glumac") && !matched.first.isNullOrBlank() && member.role != "Director") {
                        charName = matched.first
                    }
                    if (picUrl.isNullOrBlank() && !matched.second.isNullOrBlank()) {
                        picUrl = matched.second
                    }
                }

                if ((charName.isNullOrBlank() || charName == "Glumac") && member.role != "Director") {
                    try {
                        val encSearch = URLEncoder.encode("$title film", "UTF-8")
                        val searchUrl = "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encSearch&format=json"
                        val req = Request.Builder().url(searchUrl).addHeader("User-Agent", "MovieApp/1.0").build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) {
                                val body = resp.body?.string()
                                if (!body.isNullOrBlank()) {
                                    val searchJson = JSONObject(body)
                                    val results = searchJson.optJSONObject("query")?.optJSONArray("search")
                                    if (results != null && results.length() > 0) {
                                        val pageTitle = results.getJSONObject(0).optString("title")
                                        if (!pageTitle.isNullOrBlank()) {
                                            val encPageTitle = URLEncoder.encode(pageTitle, "UTF-8")
                                            val contentUrl = "https://en.wikipedia.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&titles=$encPageTitle&format=json"
                                            val req2 = Request.Builder().url(contentUrl).addHeader("User-Agent", "MovieApp/1.0").build()
                                            client.newCall(req2).execute().use { resp2 ->
                                                if (resp2.isSuccessful) {
                                                    val body2 = resp2.body?.string()
                                                    if (!body2.isNullOrBlank()) {
                                                        val json2 = JSONObject(body2)
                                                        val pages = json2.optJSONObject("query")?.optJSONObject("pages")
                                                        if (pages != null) {
                                                            val keys = pages.keys()
                                                            if (keys.hasNext()) {
                                                                val page = pages.getJSONObject(keys.next())
                                                                val wikitext = page.optJSONArray("revisions")?.optJSONObject(0)?.optJSONObject("slots")?.optJSONObject("main")?.optString("*") ?: ""
                                                                if (wikitext.isNotBlank()) {
                                                                    val cleaned = wikitext.replace(Regex("<ref.*?(/>|</ref>)", RegexOption.IGNORE_CASE), "")
                                                                    val actorEscaped = Regex.escape(member.name)
                                                                    val regex = Regex("\\*\\s*\\[\\[$actorEscaped(?:\\|[^\\]]+)?\\]\\]\\s*(?:as|–|-|:)\\s*([^\\n\\r<]+)", RegexOption.IGNORE_CASE)
                                                                    val match = regex.find(cleaned)
                                                                    if (match != null) {
                                                                        var rawChar = match.groupValues[1]
                                                                        rawChar = rawChar.replace(Regex("\\[\\[([^\\]|]+)(?:\\|[^\\]]+)?\\]\\]"), "$1")
                                                                        rawChar = rawChar.replace(Regex("\\(.*?\\)"), "")
                                                                        rawChar = rawChar.replace(Regex("\\{\\{.*?\\}\\}"), "")
                                                                        rawChar = rawChar.split(",")[0].trim()
                                                                        if (rawChar.isNotBlank() && rawChar.length < 40) {
                                                                            charName = rawChar
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // ignore
                    }
                }

                if (picUrl.isNullOrBlank()) {
                    try {
                        val encName = URLEncoder.encode(member.name, "UTF-8")
                        val url = "https://api.tvmaze.com/search/people?q=$encName"
                        val req = Request.Builder().url(url).addHeader("User-Agent", "MovieApp/1.0").build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) {
                                val body = resp.body?.string()
                                if (!body.isNullOrBlank()) {
                                    val arr = JSONArray(body)
                                    if (arr.length() > 0) {
                                        val imgObj = arr.getJSONObject(0).optJSONObject("person")?.optJSONObject("image")
                                        if (imgObj != null) {
                                            picUrl = imgObj.optString("medium", "").ifBlank { imgObj.optString("original", "") }?.ifBlank { null }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // ignore
                    }
                }

                if (picUrl.isNullOrBlank()) {
                    try {
                        val encName = URLEncoder.encode(member.name, "UTF-8")
                        val url = "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$encName&gsrlimit=1&prop=pageimages&pithumbsize=300&format=json"
                        val req = Request.Builder().url(url).addHeader("User-Agent", "MovieApp/1.0").build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) {
                                val body = resp.body?.string()
                                if (!body.isNullOrBlank()) {
                                    val json = JSONObject(body)
                                    val pages = json.optJSONObject("query")?.optJSONObject("pages")
                                    if (pages != null) {
                                        val keys = pages.keys()
                                        if (keys.hasNext()) {
                                            val page = pages.getJSONObject(keys.next())
                                            picUrl = page.optJSONObject("thumbnail")?.optString("source", "")?.ifBlank { null }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // ignore
                    }
                }

                member.copy(
                    character = if (member.role == "Director") "Reditelj" else (charName?.takeIf { it != "Glumac" && it.isNotBlank() }),
                    profilePic = picUrl
                )
            }
        }.awaitAll()
    }

    suspend fun getTrendingHeroBannerItems(): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val prefLang = getPreferredTmdbLang()
        val imgLang = if (prefLang.startsWith("sr")) "sr,en,null" else "en,null"
        val cacheKey = "trending_$prefLang"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        val list = mutableListOf<StremioMetaSummary>()
        for (apiKey in tmdbApiKeys) {
            try {
                val trendingMoviesResponse = tmdbApiService.getTrendingMovies(apiKey, language = prefLang)
                val trendingTvResponse = tmdbApiService.getTrendingTv(apiKey, language = prefLang)

                val movieResults = trendingMoviesResponse.results ?: emptyList()
                val tvResults = trendingTvResponse.results ?: emptyList()

                val topMovies = movieResults.take(3)
                val topTv = tvResults.take(3)

                val movieDecls = topMovies.map { item ->
                    async {
                        try {
                            val details = tmdbApiService.getMovieDetails(item.id, apiKey, language = prefLang, includeImageLanguage = imgLang)
                            val imdbId = details.imdbId
                            if (!imdbId.isNullOrEmpty()) {
                                val finalImdbId: String = imdbId
                                val srLogo = details.images?.logos?.firstOrNull { it.iso == "sr" }?.filePath
                                val enLogo = details.images?.logos?.firstOrNull { it.iso == "en" }?.filePath
                                val anyLogo = details.images?.logos?.firstOrNull()?.filePath
                                val logoPath = srLogo ?: enLogo ?: anyLogo
                                val logoUrl = logoPath?.let { "https://image.tmdb.org/t/p/original$it" }
                                
                                val primaryGenre = details.genres?.firstOrNull()?.name ?: "Action"
                                val finalName: String = details.title ?: item.title ?: ""
                                val finalPoster: String? = details.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: item.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                                val finalBackground: String? = details.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" } ?: item.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                                val voteAvg = details.voteAverage ?: item.voteAverage
                                val ratingStr: String? = voteAvg?.let { String.format(java.util.Locale.US, "%.1f", it) }
                                val genreList = details.genres?.mapNotNull { it.name }

                                StremioMetaSummary(
                                    id = finalImdbId,
                                    type = "movie",
                                    name = finalName,
                                    poster = finalPoster,
                                    background = finalBackground,
                                    logo = logoUrl,
                                    releaseInfo = null as String?,
                                    imdbRating = ratingStr,
                                    genres = genreList,
                                    primaryGenre = primaryGenre,
                                    overview = details.overview
                                )
                            } else null
                        } catch (e: Exception) {
                            Log.e("MovieRepository", "Error resolving trending movie details for ID ${item.id}", e)
                            null
                        }
                    }
                }

                val tvDecls = topTv.map { item ->
                    async {
                        try {
                            val details = tmdbApiService.getTvDetails(item.id, apiKey, language = prefLang, includeImageLanguage = imgLang)
                            val imdbId = details.externalIds?.imdbId
                            if (!imdbId.isNullOrEmpty()) {
                                val finalImdbId: String = imdbId
                                val srLogo = details.images?.logos?.firstOrNull { it.iso == "sr" }?.filePath
                                val enLogo = details.images?.logos?.firstOrNull { it.iso == "en" }?.filePath
                                val anyLogo = details.images?.logos?.firstOrNull()?.filePath
                                val logoPath = srLogo ?: enLogo ?: anyLogo
                                val logoUrl = logoPath?.let { "https://image.tmdb.org/t/p/original$it" }

                                val primaryGenre = details.genres?.firstOrNull()?.name ?: "Drama"
                                val finalName: String = details.name ?: item.name ?: ""
                                val finalPoster: String? = details.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: item.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                                val finalBackground: String? = details.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" } ?: item.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                                val voteAvg = details.voteAverage ?: item.voteAverage
                                val ratingStr: String? = voteAvg?.let { String.format(java.util.Locale.US, "%.1f", it) }
                                val genreList = details.genres?.mapNotNull { it.name }

                                StremioMetaSummary(
                                    id = finalImdbId,
                                    type = "series",
                                    name = finalName,
                                    poster = finalPoster,
                                    background = finalBackground,
                                    logo = logoUrl,
                                    releaseInfo = null as String?,
                                    imdbRating = ratingStr,
                                    genres = genreList,
                                    primaryGenre = primaryGenre,
                                    overview = details.overview
                                )
                            } else null
                        } catch (e: Exception) {
                            Log.e("MovieRepository", "Error resolving trending TV details for ID ${item.id}", e)
                            null
                        }
                    }
                }

                val resolvedMovies = movieDecls.awaitAll().filterNotNull()
                val resolvedTv = tvDecls.awaitAll().filterNotNull()

                list.addAll(resolvedMovies)
                list.addAll(resolvedTv)

                if (list.isNotEmpty()) {
                    memoryCache[cacheKey] = list
                    return@withContext list
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching trending Hero Banner items using key $apiKey", e)
            }
        }
        return@withContext emptyList()
    }

    suspend fun getTopMovies(addonUrl: String? = null): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val prefLang = getPreferredTmdbLang()
        val cacheKey = "top_movies_${prefLang}_${addonUrl ?: "default"}"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        try {
            val base = (addonUrl ?: fallbackCatalogUrl).removeSuffix("/")
            val cinemetaMovieEndpoints = listOf(
                "$base/catalog/movie/top.json",
                "$base/catalog/movie/top/genre=Action.json",
                "$base/catalog/movie/top/genre=Comedy.json",
                "$base/catalog/movie/top/genre=Animation.json",
                "$base/catalog/movie/top/genre=Drama.json"
            )

            val rawMetas = kotlinx.coroutines.coroutineScope {
                cinemetaMovieEndpoints.map { url ->
                    async {
                        kotlinx.coroutines.withTimeoutOrNull(2500L) {
                            try {
                                apiService.getCatalog(url).metas ?: emptyList()
                            } catch (e: Exception) {
                                emptyList()
                            }
                        } ?: emptyList()
                    }
                }.awaitAll().flatten().distinctBy { it.id }
            }

            val combined = (rawMetas + fallbackTop10Movies).distinctBy { it.id }
            val enriched = enrichSummaryList(combined)
            if (enriched.isNotEmpty()) {
                memoryCache[cacheKey] = enriched
            }
            enriched
        } catch (e: Exception) {
            Log.e("MovieRepository", "Error fetching top movies from $addonUrl", e)
            fallbackTop10Movies
        }
    }

    suspend fun getTopSeries(addonUrl: String? = null): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val prefLang = getPreferredTmdbLang()
        val cacheKey = "top_series_${prefLang}_${addonUrl ?: "default"}"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        try {
            val base = (addonUrl ?: fallbackCatalogUrl).removeSuffix("/")
            val cinemetaSeriesEndpoints = listOf(
                "$base/catalog/series/top.json",
                "$base/catalog/series/top/genre=Action.json",
                "$base/catalog/series/top/genre=Comedy.json",
                "$base/catalog/series/top/genre=Drama.json",
                "$base/catalog/series/top/genre=Animation.json"
            )

            val rawMetas = kotlinx.coroutines.coroutineScope {
                cinemetaSeriesEndpoints.map { url ->
                    async {
                        kotlinx.coroutines.withTimeoutOrNull(2500L) {
                            try {
                                apiService.getCatalog(url).metas ?: emptyList()
                            } catch (e: Exception) {
                                emptyList()
                            }
                        } ?: emptyList()
                    }
                }.awaitAll().flatten().distinctBy { it.id }
            }

            val combined = (rawMetas + fallbackTop10Tv).distinctBy { it.id }
            val enriched = enrichSummaryList(combined)
            if (enriched.isNotEmpty()) {
                memoryCache[cacheKey] = enriched
            }
            enriched
        } catch (e: Exception) {
            Log.e("MovieRepository", "Error fetching top series from $addonUrl", e)
            fallbackTop10Tv
        }
    }

    suspend fun getDomaciMovies(): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val cacheKey = "domaci_movies"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        try {
            val domaciAddonUrl = "https://domaci-filmovi-addon.vercel.app"
            val movieCatalogIds = listOf(
                "movie-drama", "movie-komedija", "movie-akcija", "movie-crtani"
            )
            val endpoints = movieCatalogIds.map { "$domaciAddonUrl/catalog/movie/$it.json" }

            val rawMetas = kotlinx.coroutines.coroutineScope {
                endpoints.map { url ->
                    async {
                        kotlinx.coroutines.withTimeoutOrNull(2500L) {
                            try {
                                apiService.getCatalog(url).metas ?: emptyList()
                            } catch (e: Exception) {
                                emptyList()
                            }
                        } ?: emptyList()
                    }
                }.awaitAll().flatten().distinctBy { it.id }
            }

            val enriched = enrichSummaryList(rawMetas)
            if (enriched.isNotEmpty()) {
                memoryCache[cacheKey] = enriched
            }
            enriched
        } catch (e: Exception) {
            Log.e("MovieRepository", "Error fetching domaci movies", e)
            emptyList()
        }
    }

    suspend fun getDomaciSeries(): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val cacheKey = "domaci_series"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        try {
            val domaciAddonUrl = "https://domaci-filmovi-addon.vercel.app"
            val seriesCatalogIds = listOf(
                "series-drama", "series-komedija", "series-akcija"
            )
            val endpoints = seriesCatalogIds.map { "$domaciAddonUrl/catalog/series/$it.json" }

            val rawMetas = kotlinx.coroutines.coroutineScope {
                endpoints.map { url ->
                    async {
                        kotlinx.coroutines.withTimeoutOrNull(2500L) {
                            try {
                                apiService.getCatalog(url).metas ?: emptyList()
                            } catch (e: Exception) {
                                emptyList()
                            }
                        } ?: emptyList()
                    }
                }.awaitAll().flatten().distinctBy { it.id }
            }

            val enriched = enrichSummaryList(rawMetas)
            if (enriched.isNotEmpty()) {
                memoryCache[cacheKey] = enriched
            }
            enriched
        } catch (e: Exception) {
            Log.e("MovieRepository", "Error fetching domaci series", e)
            emptyList()
        }
    }

    private suspend fun fetchCollectionForMovie(collectionId: Int, apiKey: String): Pair<String?, List<StremioMetaSummary>?> {
        return try {
            val collectionDetails = tmdbApiService.getCollectionDetails(collectionId, apiKey)
            val name = collectionDetails.name
            val parts = collectionDetails.parts.orEmpty()
            if (parts.size > 1) {
                val items = parts.mapNotNull { part ->
                    val partTitle = part.title ?: part.name ?: return@mapNotNull null
                    val posterUrl = part.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                    val backdropUrl = part.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                    val firstGenreId = part.genreIds?.firstOrNull()
                    val primaryGenre = firstGenreId?.let { tmdbGenresMap[it] } ?: "Film"
                    val releaseYear = part.releaseDate?.take(4) ?: part.firstAirDate?.take(4)
                    val ratingStr = part.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }

                    StremioMetaSummary(
                        id = "tmdb:${part.id}",
                        type = "movie",
                        name = partTitle,
                        poster = posterUrl,
                        background = backdropUrl,
                        logo = null,
                        releaseInfo = releaseYear,
                        imdbRating = ratingStr,
                        genres = part.genreIds?.mapNotNull { tmdbGenresMap[it] },
                        primaryGenre = primaryGenre,
                        overview = part.overview
                    )
                }.sortedBy { it.releaseInfo ?: "9999" }
                Pair(name, items)
            } else {
                Pair(name, null)
            }
        } catch (e: Exception) {
            Log.e("MovieRepository", "Error fetching collection $collectionId", e)
            Pair(null, null)
        }
    }

    private fun resolveLanguageFromTmdb(origLangCode: String?, spokenLangs: List<com.example.data.network.model.TmdbSpokenLanguage>?): String? {
        val spokenMatch = spokenLangs?.find { it.iso6391?.equals(origLangCode, ignoreCase = true) == true }
        return spokenMatch?.englishName?.takeIf { it.isNotBlank() }
            ?: spokenMatch?.name?.takeIf { it.isNotBlank() }
            ?: getLanguageDisplayName(origLangCode)
    }

    private fun getLanguageDisplayName(code: String?): String? {
        if (code.isNullOrBlank()) return null
        val clean = code.trim()
        if (clean.length == 2 || clean.length == 3) {
            val display = java.util.Locale(clean.lowercase()).getDisplayLanguage(java.util.Locale.ENGLISH)
            if (display.isNotBlank() && !display.equals(clean, ignoreCase = true)) {
                return display.replaceFirstChar { it.uppercase() }
            }
        }
        return when (clean.lowercase()) {
            "en" -> "English"
            "ja" -> "Japanese"
            "fr" -> "French"
            "es" -> "Spanish"
            "de" -> "German"
            "it" -> "Italian"
            "ko" -> "Korean"
            "zh", "cn" -> "Chinese"
            "ru" -> "Russian"
            "hi" -> "Hindi"
            "pt" -> "Portuguese"
            "sr" -> "Serbian"
            "hr" -> "Croatian"
            "bs" -> "Bosnian"
            "sv" -> "Swedish"
            "da" -> "Danish"
            "no" -> "Norwegian"
            "fi" -> "Finnish"
            "pl" -> "Polish"
            "tr" -> "Turkish"
            "nl" -> "Dutch"
            "ar" -> "Arabic"
            "el" -> "Greek"
            "he" -> "Hebrew"
            "cs" -> "Czech"
            "hu" -> "Hungarian"
            "ro" -> "Romanian"
            "th" -> "Thai"
            "id" -> "Indonesian"
            "vi" -> "Vietnamese"
            else -> clean.replaceFirstChar { it.uppercase() }
        }
    }

    private suspend fun convertTmdbMovieToMetaDetail(movie: com.example.data.network.model.TmdbMovieDetails, apiKey: String? = null): StremioMetaDetail {
        val posterUrl = movie.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
        val backdropUrl = movie.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
        val logoUrl = (movie.images?.logos?.find { it.iso == "en" } ?: movie.images?.logos?.firstOrNull())?.filePath?.let { "https://image.tmdb.org/t/p/original$it" }
        val resolvedLang = resolveLanguageFromTmdb(movie.originalLanguage, movie.spokenLanguages)
        val prodCountries = movie.productionCountries?.mapNotNull { it.name }?.filter { it.isNotBlank() }?.joinToString(", ")
        val imdbRating = movie.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }
        val castList = movie.credits?.cast?.take(10)?.mapNotNull { cast ->
            cast.name?.let {
                CastMember(
                    name = it,
                    character = cast.character,
                    profilePic = cast.profilePath?.let { path -> "https://image.tmdb.org/t/p/w185$path" },
                    tmdbPersonId = cast.id
                )
            }
        }
        val castNames = movie.credits?.cast?.take(10)?.mapNotNull { it.name }
        val directors = movie.credits?.crew?.filter { it.job == "Director" }?.mapNotNull { it.name }

        val movieCert = movie.releaseDates?.results?.find { it.iso == "US" }?.releaseDates?.mapNotNull { it.certification }?.firstOrNull { it.isNotBlank() }
            ?: movie.releaseDates?.results?.flatMap { it.releaseDates.orEmpty() }?.mapNotNull { it.certification }?.firstOrNull { it.isNotBlank() }

        var collectionNameResult: String? = null
        var collectionItemsList: List<StremioMetaSummary>? = null
        val collectionId = movie.belongsToCollection?.id
        if (apiKey != null && collectionId != null && collectionId != 0) {
            val (colName, colItems) = fetchCollectionForMovie(collectionId, apiKey)
            collectionNameResult = colName
            collectionItemsList = colItems
        }

        return StremioMetaDetail(
            id = movie.imdbId ?: "tmdb:${movie.id}",
            type = "movie",
            name = movie.title ?: "Unknown",
            poster = posterUrl,
            background = backdropUrl,
            logo = logoUrl,
            language = resolvedLang,
            country = prodCountries,
            description = movie.overview,
            releaseInfo = null,
            imdbRating = imdbRating,
            genres = movie.genres?.mapNotNull { it.name },
            cast = castNames,
            director = directors,
            runtime = null,
            videos = null,
            castMembers = castList,
            certification = movieCert,
            collectionItems = collectionItemsList,
            collectionName = collectionNameResult
        )
    }

    private data class OmdbEpisodeData(
        val episodeNumber: Int,
        val imdbRating: String?,
        val released: String?,
        val imdbId: String?
    )

    private suspend fun fetchOmdbSeasonEpisodes(
        imdbId: String,
        seasonNumber: Int
    ): Map<Int, OmdbEpisodeData> = withContext(Dispatchers.IO) {
        if (!imdbId.startsWith("tt")) return@withContext emptyMap()
        val omdbKeys = listOf("trilogy", "b7da8d63", "72bc447a")
        val client = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()

        for (key in omdbKeys) {
            try {
                val url = "https://www.omdbapi.com/?i=$imdbId&Season=$seasonNumber&apikey=$key"
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank()) {
                            val json = JSONObject(body)
                            if (json.optString("Response") == "True") {
                                val episodesArray = json.optJSONArray("Episodes")
                                if (episodesArray != null) {
                                    val result = mutableMapOf<Int, OmdbEpisodeData>()
                                    for (i in 0 until episodesArray.length()) {
                                        val epObj = episodesArray.getJSONObject(i)
                                        val epNum = epObj.optString("Episode").toIntOrNull() ?: continue
                                        val rating = epObj.optString("imdbRating", "").takeIf { it.isNotBlank() && it != "N/A" }
                                        val released = epObj.optString("Released", "").takeIf { it.isNotBlank() && it != "N/A" }
                                        val epImdbId = epObj.optString("imdbID", "").takeIf { it.isNotBlank() && it != "N/A" }
                                        result[epNum] = OmdbEpisodeData(
                                            episodeNumber = epNum,
                                            imdbRating = rating,
                                            released = released,
                                            imdbId = epImdbId
                                        )
                                    }
                                    return@withContext result
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("MovieRepository", "Error fetching OMDB season $seasonNumber for $imdbId with key $key", e)
            }
        }
        emptyMap()
    }

    private suspend fun fetchAndEnrichTvEpisodes(
        tvId: Int,
        apiKey: String,
        metaVideos: List<StremioVideo>?,
        seasons: List<com.example.data.network.model.TmdbSeasonSummary>?,
        defaultImdbId: String,
        backdropUrl: String?
    ): List<StremioVideo>? = kotlinx.coroutines.coroutineScope {
        val validSeasons = seasons?.mapNotNull { it.seasonNumber }?.filter { it > 0 }
            ?.takeIf { it.isNotEmpty() }
            ?: metaVideos?.map { it.season }?.distinct()?.filter { it > 0 }
            ?: emptyList()

        if (validSeasons.isEmpty()) return@coroutineScope metaVideos

        var seriesImdbId = if (defaultImdbId.startsWith("tt")) defaultImdbId else ""
        if (seriesImdbId.isBlank() && apiKey.isNotBlank()) {
            try {
                val tvDetails = tmdbApiService.getTvDetails(tvId, apiKey)
                seriesImdbId = tvDetails.externalIds?.imdbId ?: ""
            } catch (e: Exception) {
                Log.w("MovieRepository", "Could not fetch externalIds for tv $tvId", e)
            }
        }

        val prefLang = getPreferredTmdbLang()
        val seasonDeferreds = validSeasons.map { sNum ->
            async(Dispatchers.IO) {
                try {
                    var sDetails = tmdbApiService.getSeasonDetails(tvId, sNum, apiKey, language = prefLang)
                    if (prefLang != "en-US") {
                        try {
                            val enDetails = tmdbApiService.getSeasonDetails(tvId, sNum, apiKey, language = "en-US")
                            val enEpsMap = enDetails.episodes?.associateBy { it.episodeNumber } ?: emptyMap()
                            val mergedEps = sDetails.episodes?.map { ep ->
                                val enEp = enEpsMap[ep.episodeNumber]
                                ep.copy(
                                    name = if (!ep.name.isNullOrBlank()) ep.name else enEp?.name,
                                    overview = if (!ep.overview.isNullOrBlank()) ep.overview else enEp?.overview
                                )
                            }
                            if (mergedEps != null) {
                                sDetails = sDetails.copy(episodes = mergedEps)
                            }
                        } catch (e: Exception) {
                            // ignore fallback exception
                        }
                    }
                    sNum to sDetails
                } catch (e: Exception) {
                    Log.e("MovieRepository", "Error fetching season $sNum details for tv $tvId", e)
                    sNum to null
                }
            }
        }

        val omdbSeasonDeferreds = if (seriesImdbId.startsWith("tt")) {
            validSeasons.map { sNum ->
                async(Dispatchers.IO) {
                    sNum to fetchOmdbSeasonEpisodes(seriesImdbId, sNum)
                }
            }
        } else emptyList()

        val seasonDetailsMap = seasonDeferreds.awaitAll().mapNotNull { (sNum, details) ->
            if (details != null) sNum to details else null
        }.toMap()

        val omdbDetailsMap = omdbSeasonDeferreds.awaitAll().toMap()

        if (seasonDetailsMap.isEmpty()) return@coroutineScope metaVideos

        val enrichedList = mutableListOf<StremioVideo>()
        val existingVideosMap = metaVideos?.associateBy { "${it.season}:${it.episode}" } ?: emptyMap()

        for (sNum in validSeasons.sorted()) {
            val sDetails = seasonDetailsMap[sNum]
            val omdbEps = omdbDetailsMap[sNum] ?: emptyMap()
            val tmdbEpisodes = sDetails?.episodes
            if (!tmdbEpisodes.isNullOrEmpty()) {
                for (ep in tmdbEpisodes) {
                    val epNum = ep.episodeNumber ?: continue
                    val existing = existingVideosMap["$sNum:$epNum"]
                    val omdbEp = omdbEps[epNum]

                    val videoId = existing?.id ?: if (seriesImdbId.isNotBlank()) "$seriesImdbId:$sNum:$epNum" else "$defaultImdbId:$sNum:$epNum"
                    val epTitle = ep.name?.takeIf { it.isNotBlank() } ?: existing?.title ?: "Epizoda $epNum"

                    val epReleased = omdbEp?.released?.takeIf { it.isNotBlank() }
                        ?: ep.airDate?.takeIf { it.isNotBlank() }
                        ?: existing?.released?.takeIf { it.isNotBlank() }

                    val epStill = ep.stillPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                        ?: existing?.thumbnail
                        ?: sDetails.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                        ?: backdropUrl
                    val epOverview = ep.overview?.takeIf { it.isNotBlank() } ?: existing?.overview

                    val epRating = omdbEp?.imdbRating?.takeIf { it.isNotBlank() }
                        ?: ep.voteAverage?.takeIf { it > 0.0 }?.let { String.format(java.util.Locale.US, "%.1f", it) }
                        ?: existing?.imdbRating?.takeIf { it.isNotBlank() && it != "0" }
                        ?: existing?.rating?.takeIf { it.isNotBlank() && it != "0" }

                    enrichedList.add(
                        StremioVideo(
                            id = videoId,
                            title = epTitle,
                            released = epReleased,
                            thumbnail = epStill,
                            episode = epNum,
                            season = sNum,
                            overview = epOverview,
                            rating = epRating,
                            imdbRating = epRating
                        )
                    )
                }
            } else {
                val existingForSeason = metaVideos?.filter { it.season == sNum }
                if (!existingForSeason.isNullOrEmpty()) {
                    val enrichedExisting = existingForSeason.map { v ->
                        val omdbEp = omdbEps[v.episode]
                        if (omdbEp != null) {
                            v.copy(
                                released = omdbEp.released?.takeIf { it.isNotBlank() } ?: v.released,
                                rating = omdbEp.imdbRating?.takeIf { it.isNotBlank() } ?: v.rating,
                                imdbRating = omdbEp.imdbRating?.takeIf { it.isNotBlank() } ?: v.imdbRating,
                                id = omdbEp.imdbId ?: v.id
                            )
                        } else v
                    }
                    enrichedList.addAll(enrichedExisting)
                }
            }
        }

        if (enrichedList.isNotEmpty()) enrichedList else metaVideos
    }

    private suspend fun convertTmdbTvToMetaDetail(tv: com.example.data.network.model.TmdbTvDetails, apiKey: String? = null): StremioMetaDetail {
        val posterUrl = tv.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
        val backdropUrl = tv.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
        val logoUrl = (tv.images?.logos?.find { it.iso == "en" } ?: tv.images?.logos?.firstOrNull())?.filePath?.let { "https://image.tmdb.org/t/p/original$it" }
        val resolvedLang = resolveLanguageFromTmdb(tv.originalLanguage, tv.spokenLanguages)
        val prodCountries = tv.productionCountries?.mapNotNull { it.name }?.filter { it.isNotBlank() }?.joinToString(", ")
        val imdbRating = tv.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }
        val castList = tv.credits?.cast?.take(10)?.mapNotNull { cast ->
            cast.name?.let {
                CastMember(
                    name = it,
                    character = cast.character,
                    profilePic = cast.profilePath?.let { path -> "https://image.tmdb.org/t/p/w185$path" },
                    tmdbPersonId = cast.id
                )
            }
        }
        val castNames = tv.credits?.cast?.take(10)?.mapNotNull { it.name }
        val directors = tv.credits?.crew?.filter { it.job == "Director" || it.job == "Executive Producer" }?.mapNotNull { it.name }

        val tvRating = tv.contentRatings?.results?.find { it.iso == "US" }?.rating?.takeIf { it.isNotBlank() }
            ?: tv.contentRatings?.results?.mapNotNull { it.rating }?.firstOrNull { it.isNotBlank() }

        val firstYear = tv.firstAirDate?.take(4)
        val releaseInfoText = if (firstYear != null) {
            val lastYear = if (tv.inProduction == true) "Present" else tv.lastAirDate?.take(4)
            if (lastYear != null && lastYear != firstYear) "$firstYear - $lastYear" else firstYear
        } else null

        val runtimeText = tv.episodeRunTime?.firstOrNull()?.let { "$it min" } ?: "45 min"

        val imdbId = tv.externalIds?.imdbId ?: "tmdb:${tv.id}"

        val effectiveApiKey = apiKey ?: tmdbApiKeys.firstOrNull() ?: ""
        val enrichedVideos = if (effectiveApiKey.isNotBlank()) {
            fetchAndEnrichTvEpisodes(
                tvId = tv.id,
                apiKey = effectiveApiKey,
                metaVideos = null,
                seasons = tv.seasons,
                defaultImdbId = imdbId,
                backdropUrl = backdropUrl
            )
        } else null

        val finalVideos = enrichedVideos ?: run {
            val generatedVideos = mutableListOf<StremioVideo>()
            tv.seasons?.filter { season -> (season.seasonNumber ?: 0) > 0 }?.forEach { season ->
                val sNum = season.seasonNumber ?: 1
                val epCount = season.episodeCount ?: 10
                for (e in 1..epCount) {
                    generatedVideos.add(
                        StremioVideo(
                            id = "$imdbId:$sNum:$e",
                            title = "Epizoda $e",
                            released = null,
                            thumbnail = season.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: backdropUrl,
                            episode = e,
                            season = sNum,
                            overview = season.overview
                        )
                    )
                }
            }
            generatedVideos.takeIf { it.isNotEmpty() }
        }

        val creators = tv.createdBy?.mapNotNull { it.name }?.takeIf { it.isNotEmpty() }
            ?: directors

        val seasonPostersMap = tv.seasons?.mapNotNull { season ->
            val sNum = season.seasonNumber
            val pPath = season.posterPath
            if (sNum != null && !pPath.isNullOrBlank()) {
                sNum to "https://image.tmdb.org/t/p/w500$pPath"
            } else null
        }?.toMap()

        return StremioMetaDetail(
            id = imdbId,
            type = "series",
            name = tv.name ?: "Unknown",
            poster = posterUrl,
            background = backdropUrl,
            logo = logoUrl,
            language = resolvedLang,
            country = prodCountries,
            description = tv.overview,
            releaseInfo = releaseInfoText,
            imdbRating = imdbRating,
            genres = tv.genres?.mapNotNull { it.name },
            cast = castNames,
            director = creators,
            runtime = runtimeText,
            videos = finalVideos,
            castMembers = castList,
            contentRating = tvRating,
            seasonPosters = seasonPostersMap
        )
    }

    suspend fun getMetaDetail(type: String, id: String, addonUrl: String? = null): StremioMetaDetail? = withContext(Dispatchers.IO) {
        val prefLang = getPreferredTmdbLang()
        val normalizedType = if (type == "tv" || type == "show") "series" else type
        val detailCacheKey = "detail_${normalizedType}_${id}_$prefLang"
        (metaDetailCache[detailCacheKey])?.let { return@withContext it }

        var queryId = id
        var tmdbFallback: StremioMetaDetail? = null

        // 1. If ID is tmdb: parsed ID, attempt fetching TMDB info first to obtain IMDb ID and TMDB fallback
        if (queryId.startsWith("tmdb:")) {
            val rawId = queryId.removePrefix("tmdb:").toIntOrNull()
            if (rawId != null) {
                for (apiKey in tmdbApiKeys) {
                    try {
                        if (normalizedType == "series") {
                            val tvDetails = tmdbApiService.getTvDetails(rawId, apiKey)
                            tmdbFallback = convertTmdbTvToMetaDetail(tvDetails, apiKey)
                            val imdb = tvDetails.externalIds?.imdbId
                            if (!imdb.isNullOrBlank()) {
                                queryId = imdb
                            }
                        } else {
                            val movieDetails = tmdbApiService.getMovieDetails(rawId, apiKey)
                            tmdbFallback = convertTmdbMovieToMetaDetail(movieDetails, apiKey)
                            val imdb = movieDetails.imdbId
                            if (!imdb.isNullOrBlank()) {
                                queryId = imdb
                            }
                        }
                        break
                    } catch (e: Exception) {
                        Log.e("MovieRepository", "Error resolving tmdb id $rawId", e)
                    }
                }
            }
        }

        // 2. Try Cinemeta or Domaci Addon with queryId if queryId is an IMDb ID or standard Stremio ID
        if (!queryId.startsWith("tmdb:")) {
            try {
                val domaciAddonUrl = "https://domaci-filmovi-addon.vercel.app"
                // For IMDb tt... IDs, Cinemeta is the fast primary catalog. For others, try Domaci first.
                val basesToTry = if (queryId.startsWith("tt")) {
                    listOfNotNull(addonUrl, fallbackCatalogUrl, domaciAddonUrl).distinct()
                } else {
                    listOfNotNull(addonUrl, domaciAddonUrl, fallbackCatalogUrl).distinct()
                }

                var domaciMeta: StremioMetaDetail? = null

                for (base in basesToTry) {
                    try {
                        val cleanBase = base.removeSuffix("/")
                        val url = "$cleanBase/meta/$normalizedType/$queryId.json"
                        val response = apiService.getMetaDetail(url)
                        val meta = response.meta
                        if (meta != null) {
                            if (cleanBase == domaciAddonUrl || cleanBase == addonUrl) {
                                domaciMeta = meta
                                break
                            } else {
                                val enriched = try { enrichWithTmdb(meta) } catch (e: Exception) { meta }
                                val result = if (enriched.videos.isNullOrEmpty() && !domaciMeta?.videos.isNullOrEmpty()) {
                                    enriched.copy(videos = domaciMeta!!.videos)
                                } else enriched
                                metaDetailCache[detailCacheKey] = result
                                return@withContext result
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("MovieRepository", "Error fetching meta detail from $base for $normalizedType $queryId", e)
                    }
                }

                if (domaciMeta != null) {
                    val enriched = try { enrichWithTmdb(domaciMeta) } catch (e: Exception) { domaciMeta }
                    val result = if (enriched.videos.isNullOrEmpty() && !domaciMeta.videos.isNullOrEmpty()) {
                        enriched.copy(videos = domaciMeta.videos)
                    } else enriched
                    metaDetailCache[detailCacheKey] = result
                    return@withContext result
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching meta detail from Cinemeta/Domaci for $normalizedType $queryId", e)
            }
        }

        // 3. Fallback to TMDB detail if Cinemeta failed or was skipped
        if (tmdbFallback == null) {
            for (apiKey in tmdbApiKeys) {
                try {
                    if (queryId.startsWith("tt")) {
                        val findResponse = tmdbApiService.findByImdbId(queryId, apiKey)
                        val movieId = findResponse.movieResults?.firstOrNull()?.id
                        val tvId = findResponse.tvResults?.firstOrNull()?.id
                        if (normalizedType == "series" && tvId != null) {
                            val tvDetails = tmdbApiService.getTvDetails(tvId, apiKey)
                            tmdbFallback = convertTmdbTvToMetaDetail(tvDetails, apiKey)
                            break
                        } else if (normalizedType != "series" && movieId != null) {
                            val movieDetails = tmdbApiService.getMovieDetails(movieId, apiKey)
                            tmdbFallback = convertTmdbMovieToMetaDetail(movieDetails, apiKey)
                            break
                        }
                    }
                } catch (e: Exception) {
                    Log.e("MovieRepository", "Error resolving TMDB fallback for $queryId", e)
                }
            }
        }

        // Enrich series episodes from domaci-filmovi-addon if TMDB fallback lacked them
        if (tmdbFallback != null && normalizedType == "series" && tmdbFallback.videos.isNullOrEmpty()) {
            try {
                val domaciUrl = "https://domaci-filmovi-addon.vercel.app/meta/series/$queryId.json"
                val domaciMeta = apiService.getMetaDetail(domaciUrl).meta
                if (domaciMeta?.videos != null) {
                    tmdbFallback = tmdbFallback.copy(videos = domaciMeta.videos)
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching domaci episode videos for TMDB fallback: $queryId", e)
            }
        }

        if (tmdbFallback != null) {
            metaDetailCache[detailCacheKey] = tmdbFallback
        }
        return@withContext tmdbFallback
    }

    suspend fun searchCatalog(query: String, type: String, addonUrl: String? = null): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        try {
            val base = (addonUrl ?: fallbackCatalogUrl).removeSuffix("/")
            val encodedQuery = "search=" + URLEncoder.encode(query, "UTF-8")
            val typesToSearch = when (type) {
                "all" -> listOf("movie", "series")
                "series" -> listOf("series")
                else -> listOf("movie")
            }

            val searchJobs = typesToSearch.map { t ->
                async {
                    try {
                        val url = "$base/catalog/$t/top/$encodedQuery.json"
                        val response = apiService.getCatalog(url)
                        response.metas ?: emptyList()
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }

            // Also search Domaći addon for domestic movies/series
            val domaciJob = async {
                try {
                    val domaciUrl = "https://domaci-filmovi-addon.vercel.app/catalog/movie/top/$encodedQuery.json"
                    apiService.getCatalog(domaciUrl).metas ?: emptyList()
                } catch (e: Exception) {
                    emptyList()
                }
            }

            val results = (searchJobs.awaitAll().flatten() + domaciJob.await()).distinctBy { it.id }
            enrichSummaryList(results)
        } catch (e: Exception) {
            Log.e("MovieRepository", "Error searching catalog for '$query'", e)
            emptyList()
        }
    }

    private suspend fun resolveFileUploadUrlIfNeeded(stream: StremioStream): StremioStream {
        var s = stream

        val rawUrl = s.url ?: return s

        val defaultHeaders = mapOf(
            "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",
            "Referer" to "https://file-upload.org/",
            "Origin" to "https://file-upload.org"
        )

        // Clean spaces and prepare direct HTTP/HTTPS URLs
        if (rawUrl.contains("bilosta.org")) {
            val cleanUrl = rawUrl.trim().replace(" ", "%20")
            val bilostaHeaders = mapOf(
                "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",
                "Referer" to "https://storage.bilosta.org/",
                "Origin" to "https://storage.bilosta.org"
            )
            val existingHeaders = s.behaviorHints?.headers ?: s.headers ?: emptyMap()
            val mergedHeaders = bilostaHeaders + existingHeaders
            return s.copy(
                url = cleanUrl,
                headers = mergedHeaders,
                behaviorHints = StremioStreamBehaviorHints(headers = mergedHeaders)
            )
        } else if (rawUrl.contains(" ")) {
            s = s.copy(url = rawUrl.trim().replace(" ", "%20"))
        }

        val currentUrl = s.url ?: return s

        // Case 1: Direct stream download link from file-upload (.file-upload.download)
        if (currentUrl.contains(".file-upload.download")) {
            val existingHeaders = s.behaviorHints?.headers ?: s.headers ?: emptyMap()
            val mergedHeaders = defaultHeaders + existingHeaders
            return s.copy(
                headers = mergedHeaders,
                behaviorHints = StremioStreamBehaviorHints(headers = mergedHeaders)
            )
        }

        // Case 2: Embed / page link from file-upload.org needing client-side resolution
        if (currentUrl.contains("file-upload.")) {
            try {
                val mediaId = currentUrl.substringAfterLast("/").removePrefix("embed-").substringBefore(".")
                if (mediaId.isNotBlank()) {
                    val embedUrl = "https://www.file-upload.org/embed-$mediaId.html"
                    val request = okhttp3.Request.Builder()
                        .url(embedUrl)
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0")
                        .header("Referer", "https://file-upload.org/")
                        .header("Origin", "https://file-upload.org")
                        .build()

                    val response = client.newCall(request).execute()
                    val html = response.body?.string() ?: ""

                    val directMediaMatch = Regex("https?://[^\\s\"']+\\.(?:mp4|m3u8|mkv|ts|avi)(?:\\?[^\\s\"']*)?").find(html)
                    if (directMediaMatch != null) {
                        return s.copy(
                            url = directMediaMatch.value,
                            headers = defaultHeaders,
                            behaviorHints = StremioStreamBehaviorHints(headers = defaultHeaders)
                        )
                    }

                    val keysMatch = Regex("'([^']+)'\\.split\\('\\|'\\)").find(html)
                    if (keysMatch != null) {
                        val keys = keysMatch.groupValues[1].split('|')
                        val subdomain = keys.find { it.matches(Regex("^f\\d+$")) }
                        val port = keys.find { it.matches(Regex("^\\d{2,5}$")) && (it.toIntOrNull() ?: 0) in 80..65535 && it != "1080" && it != "720" }
                        val hash = keys.find { it.length in 25..80 && it.all { c -> c.isLetterOrDigit() || c == '_' || c == '-' } }

                        if (subdomain != null && hash != null) {
                            val resolvedUrl = if (port != null) {
                                "https://$subdomain.file-upload.download:$port/d/$hash/video.mp4"
                            } else {
                                "https://$subdomain.file-upload.download/d/$hash/video.mp4"
                            }
                            return s.copy(
                                url = resolvedUrl,
                                headers = defaultHeaders,
                                behaviorHints = StremioStreamBehaviorHints(headers = defaultHeaders)
                            )
                        }
                    }

                    val filePropMatch = Regex("(?:file|src|url)\\s*:\\s*[\"'](https?://[^\"']+)[\"']", RegexOption.IGNORE_CASE).find(html)
                    if (filePropMatch != null) {
                        return s.copy(
                            url = filePropMatch.groupValues[1],
                            headers = defaultHeaders,
                            behaviorHints = StremioStreamBehaviorHints(headers = defaultHeaders)
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error resolving file-upload link on client: $currentUrl", e)
            }
        }

        return s
    }

    suspend fun getStreams(type: String, id: String, streamAddonUrls: List<String>): List<StremioStream> = withContext(Dispatchers.IO) {
        val normalizedType = if (type == "series" || type == "tv" || type == "show") "series" else type
        var queryId = id

        // Extract season/episode suffix if present (e.g. ":1:1")
        val seasonEpSuffix = if (queryId.contains(":") && !queryId.startsWith("kitsu:")) {
            ":" + queryId.substringAfter(":")
        } else ""

        val baseId = if (queryId.contains(":") && !queryId.startsWith("kitsu:")) {
            queryId.substringBefore(":")
        } else queryId

        if (baseId.startsWith("tmdb:")) {
            val rawId = baseId.removePrefix("tmdb:").toIntOrNull()
            if (rawId != null) {
                val mapped = if (normalizedType == "series") tmdbToImdbTvMap[rawId] else tmdbToImdbMovieMap[rawId]
                if (mapped != null) {
                    queryId = mapped + seasonEpSuffix
                } else {
                    for (apiKey in tmdbApiKeys) {
                        try {
                            if (normalizedType == "series") {
                                val tvDetails = tmdbApiService.getTvDetails(rawId, apiKey)
                                val imdb = tvDetails.externalIds?.imdbId
                                if (!imdb.isNullOrBlank()) {
                                    queryId = imdb + seasonEpSuffix
                                    break
                                }
                            } else {
                                val movieDetails = tmdbApiService.getMovieDetails(rawId, apiKey)
                                val imdb = movieDetails.imdbId
                                if (!imdb.isNullOrBlank()) {
                                    queryId = imdb + seasonEpSuffix
                                    break
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("MovieRepository", "Error converting tmdb id for streams: $rawId", e)
                        }
                    }
                }
            }
        } else if (baseId.all { it.isDigit() }) {
            val rawId = baseId.toIntOrNull()
            if (rawId != null) {
                val mapped = if (normalizedType == "series") tmdbToImdbTvMap[rawId] else tmdbToImdbMovieMap[rawId]
                if (mapped != null) {
                    queryId = mapped + seasonEpSuffix
                } else {
                    for (apiKey in tmdbApiKeys) {
                        try {
                            if (normalizedType == "series") {
                                val tvDetails = tmdbApiService.getTvDetails(rawId, apiKey)
                                val imdb = tvDetails.externalIds?.imdbId
                                if (!imdb.isNullOrBlank()) {
                                    queryId = imdb + seasonEpSuffix
                                    break
                                }
                            } else {
                                val movieDetails = tmdbApiService.getMovieDetails(rawId, apiKey)
                                val imdb = movieDetails.imdbId
                                if (!imdb.isNullOrBlank()) {
                                    queryId = imdb + seasonEpSuffix
                                    break
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("MovieRepository", "Error converting numeric tmdb id: $rawId", e)
                        }
                    }
                }
            }
        }

        val domaciAddonUrl = "https://domaci-filmovi-addon.vercel.app"
        val penguAddonUrl = "https://pengu.uk/zbcmxDoIwFEDRf-nsAChG-AHUgUSJDi5NoS-0trbY11aJ8d-dMIY43nNfBG1wHdCVElyElpTEGrKY9GajhNY-_zFyJyPgbEU2aDaCm7HgvWDOxxlnA3RKw6QOkGbpOvntNNl8m0tkrQbKpYPOT8qCF9RbBYaUZLlzQ1EzPKv94WjQyK0L4yXvdRWLe1I1j_pUXMXK5w2S9wc"
        val allAddonUrls = (listOf(domaciAddonUrl, penguAddonUrl) + streamAddonUrls).distinct()

        val rawStreams = coroutineScope {
            allAddonUrls.map { addonUrl ->
                async {
                    kotlinx.coroutines.withTimeoutOrNull(4000L) {
                        try {
                            val base = addonUrl.removeSuffix("/")
                            val effectiveQueryId = if (normalizedType == "series" && !queryId.contains(":")) {
                                "$queryId:1:1"
                            } else {
                                queryId
                            }

                            val url = "$base/stream/$normalizedType/$effectiveQueryId.json"
                            val response = apiService.getStreams(url)
                            response.streams?.map { rawStream ->
                                rawStream.copy(name = rawStream.name ?: addonUrl.removePrefix("https://").removePrefix("http://").substringBefore("/"))
                            } ?: emptyList()
                        } catch (e: Exception) {
                            Log.e("MovieRepository", "Error fetching streams from $addonUrl for $type $queryId", e)
                            emptyList()
                        }
                    } ?: emptyList()
                }
            }.awaitAll().flatten()
        }

        val resolvedStreams = coroutineScope {
            rawStreams.map { s ->
                async {
                    kotlinx.coroutines.withTimeoutOrNull(3500L) {
                        resolveFileUploadUrlIfNeeded(s)
                    } ?: s
                }
            }.awaitAll()
        }

        // Strictly filter for direct HTTP/HTTPS media streams (removing torrents and unresolvable HTML pages)
        val directHttpStreams = resolvedStreams.filter { s ->
            val u = s.url ?: ""
            val isDirectHttp = u.startsWith("http://", ignoreCase = true) || u.startsWith("https://", ignoreCase = true)
            val isNotTorrent = !u.startsWith("magnet:", ignoreCase = true) &&
                    !u.contains("torrent.strem.fun", ignoreCase = true) &&
                    s.infoHash.isNullOrBlank()
            val isNotUnresolvedHtml = !u.endsWith(".html", ignoreCase = true) && !u.contains("/embed-", ignoreCase = true)
            isDirectHttp && isNotTorrent && isNotUnresolvedHtml
        }

        // Smart quality sorting: prioritize Pengu Play direct streams, Domaći addon, 4K / 2160p / REMUX and 1080p FHD
        directHttpStreams.sortedByDescending { s ->
            var score = 0
            val u = s.url ?: ""
            if (u.startsWith("https://")) score += 500
            
            val titleLower = (s.title ?: "").lowercase()
            val nameLower = (s.name ?: "").lowercase()

            if (nameLower.contains("pengu") || titleLower.contains("pengu")) {
                score += 1000 // Highest priority for Pengu Play direct links
            }
            if (nameLower.contains("domaci") || titleLower.contains("domaci") || u.contains("bilosta") || u.contains("file-upload")) {
                score += 900 // High priority for Domaći addon links
            }

            if (titleLower.contains("1080p") || titleLower.contains("fhd")) {
                score += 500
            } else if (titleLower.contains("720p")) {
                score += 350
            } else if (titleLower.contains("4k") || titleLower.contains("2160p") || titleLower.contains("uhd") || titleLower.contains("remux")) {
                score += 250
            }

            score
        }
    }

    suspend fun fetchSubtitles(
        type: String,
        id: String,
        season: Int? = null,
        episode: Int? = null,
        subtitleAddonUrls: List<String> = listOf("https://opensubtitles-v3.strem.io")
    ): List<StremioSubtitle> = withContext(Dispatchers.IO) {
        val normalizedType = if (type == "series" || type == "tv" || type == "show") "series" else "movie"
        var queryId = id

        if (normalizedType == "series") {
            if (!queryId.contains(":") && season != null && episode != null) {
                queryId = "$queryId:$season:$episode"
            }
        }

        val seasonEpSuffix = if (queryId.contains(":") && !queryId.startsWith("kitsu:")) {
            ":" + queryId.substringAfter(":")
        } else ""

        val baseId = if (queryId.contains(":") && !queryId.startsWith("kitsu:")) {
            queryId.substringBefore(":")
        } else queryId

        if (baseId.startsWith("tmdb:")) {
            val rawId = baseId.removePrefix("tmdb:").toIntOrNull()
            if (rawId != null) {
                val mapped = if (normalizedType == "series") tmdbToImdbTvMap[rawId] else tmdbToImdbMovieMap[rawId]
                if (mapped != null) {
                    queryId = mapped + seasonEpSuffix
                } else {
                    for (apiKey in tmdbApiKeys) {
                        try {
                            if (normalizedType == "series") {
                                val tvDetails = tmdbApiService.getTvDetails(rawId, apiKey)
                                val imdb = tvDetails.externalIds?.imdbId
                                if (!imdb.isNullOrBlank()) {
                                    queryId = imdb + seasonEpSuffix
                                    break
                                }
                            } else {
                                val movieDetails = tmdbApiService.getMovieDetails(rawId, apiKey)
                                val imdb = movieDetails.imdbId
                                if (!imdb.isNullOrBlank()) {
                                    queryId = imdb + seasonEpSuffix
                                    break
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("MovieRepository", "Error converting tmdb id for subtitles: $rawId", e)
                        }
                    }
                }
            }
        }

        val urlsToTry = if (subtitleAddonUrls.isEmpty()) {
            listOf("https://opensubtitles-v3.strem.io")
        } else {
            subtitleAddonUrls.distinct()
        }

        val results = mutableListOf<StremioSubtitle>()

        for (addonUrl in urlsToTry) {
            val baseUrl = addonUrl.trim().removeSuffix("/").removeSuffix("/manifest.json")
            val subApiUrl = "$baseUrl/subtitles/$normalizedType/$queryId.json"
            try {
                val resp = apiService.getSubtitles(subApiUrl)
                resp.subtitles?.let { list ->
                    results.addAll(list)
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching subtitles from $subApiUrl", e)
            }
        }

        results
    }

    private val tmdbToImdbMovieMap = mapOf(
        1100782 to "tt24169886", // The Instigators
        957452 to "tt7097896",   // F1
        533535 to "tt6263850",   // Deadpool & Wolverine
        872585 to "tt15398776",  // Oppenheimer
        693134 to "tt15239678",  // Dune: Part Two
        718821 to "tt12584954",  // Twisters
        1022789 to "tt22022452", // Inside Out 2
        786892 to "tt12037194",  // Furiosa: A Mad Max Saga
        762441 to "tt13433802",  // A Quiet Place: Day One
        519182 to "tt13510524",  // Despicable Me 4
        945961 to "tt18412256",  // Alien: Romulus
        365177 to "tt4978420"    // Borderlands
    )

    private val tmdbToImdbTvMap = mapOf(
        278567 to "tt34820241", // Sto se bore misli moje
        239503 to "tt22862686", // Tunel
        125988 to "tt14688458",  // Silo
        94997 to "tt11198330",   // House of the Dragon
        76479 to "tt1190634",    // The Boys
        79093 to "tt2798596",    // Shogun
        139352 to "tt14452718",  // The Bear
        211116 to "tt17729250",  // Presumed Innocent
        135157 to "tt13641562",  // The Acolyte
        97546 to "tt10986410",   // Ted Lasso
        106388 to "tt12637874",  // Fallout
        77169 to "tt7282856"     // Cobra Kai
    )

    private val fallbackTop10Movies = listOf(
        StremioMetaSummary(
            id = "tt24169886",
            type = "movie",
            name = "The Instigators",
            poster = "https://image.tmdb.org/t/p/w500/or06mS60bZgI7vS97Z40RclK8as.jpg",
            background = "https://image.tmdb.org/t/p/original/or06mS60bZgI7vS97Z40RclK8as.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "6.3",
            genres = listOf("Action", "Comedy"),
            primaryGenre = "Action",
            overview = "Two thieves and their therapist go on the run after a robbery goes wrong."
        ),
        StremioMetaSummary(
            id = "tt7097896",
            type = "movie",
            name = "F1",
            poster = "https://image.tmdb.org/t/p/w500/x5IOfvP7fN4v20G7kGvF847Cq1n.jpg",
            background = "https://image.tmdb.org/t/p/original/x5IOfvP7fN4v20G7kGvF847Cq1n.jpg",
            logo = null,
            releaseInfo = "2025",
            imdbRating = "7.2",
            genres = listOf("Action", "Drama", "Sport"),
            primaryGenre = "Action",
            overview = "A former driver returns to Formula One, racing alongside a younger teammate."
        ),
        StremioMetaSummary(
            id = "tt6263850",
            type = "movie",
            name = "Deadpool & Wolverine",
            poster = "https://image.tmdb.org/t/p/w500/8cdWv6g7hYm9vR6gygU9vR6gygU.jpg",
            background = "https://image.tmdb.org/t/p/original/8cdWv6g7hYm9vR6gygU9vR6gygU.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "8.1",
            genres = listOf("Action", "Comedy", "Sci-Fi"),
            primaryGenre = "Action",
            overview = "A weary Wolverine finds himself recovering from his injuries when he crosses paths with Deadpool."
        ),
        StremioMetaSummary(
            id = "tt15398776",
            type = "movie",
            name = "Oppenheimer",
            poster = "https://image.tmdb.org/t/p/w500/8Gxv8g74g4p67OHz9m9x7H5p6V7.jpg",
            background = "https://image.tmdb.org/t/p/original/8Gxv8g74g4p67OHz9m9x7H5p6V7.jpg",
            logo = null,
            releaseInfo = "2023",
            imdbRating = "8.9",
            genres = listOf("Drama", "History", "Biography"),
            primaryGenre = "Drama",
            overview = "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb."
        ),
        StremioMetaSummary(
            id = "tt15239678",
            type = "movie",
            name = "Dune: Part Two",
            poster = "https://image.tmdb.org/t/p/w500/czembba3Vl34g4p67OHz9m9x7H5p6V7.jpg",
            background = "https://image.tmdb.org/t/p/original/czembba3Vl34g4p67OHz9m9x7H5p6V7.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "8.6",
            genres = listOf("Action", "Adventure", "Sci-Fi"),
            primaryGenre = "Sci-Fi",
            overview = "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family."
        ),
        StremioMetaSummary(
            id = "tt12584954",
            type = "movie",
            name = "Twisters",
            poster = "https://image.tmdb.org/t/p/w500/p6Eb796Y3u0vR6gygU9vR6gygU.jpg",
            background = "https://image.tmdb.org/t/p/original/p6Eb796Y3u0vR6gygU9vR6gygU.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "6.9",
            genres = listOf("Action", "Adventure", "Thriller"),
            primaryGenre = "Action",
            overview = "An update to the 1996 film 'Twister', which centered on tornado chase teams."
        ),
        StremioMetaSummary(
            id = "tt12037194",
            type = "movie",
            name = "Furiosa",
            poster = "https://image.tmdb.org/t/p/w500/iADOZ6z070606g6Y3u0vR6gygU.jpg",
            background = "https://image.tmdb.org/t/p/original/iADOZ6z070606g6Y3u0vR6gygU.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "7.6",
            genres = listOf("Action", "Adventure", "Sci-Fi"),
            primaryGenre = "Action",
            overview = "The origin story of renegade warrior Furiosa before her encounter and teamup with Mad Max."
        ),
        StremioMetaSummary(
            id = "tt22022452",
            type = "movie",
            name = "Inside Out 2",
            poster = "https://image.tmdb.org/t/p/w500/vpn9g69U6gSpAatvveZgih9IIn.jpg",
            background = "https://image.tmdb.org/t/p/original/vpn9g69U6gSpAatvveZgih9IIn.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "7.8",
            genres = listOf("Animation", "Family", "Comedy"),
            primaryGenre = "Animation",
            overview = "Follow Riley, in her teenage years, encountering new emotions."
        ),
        StremioMetaSummary(
            id = "tt13510524",
            type = "movie",
            name = "Despicable Me 4",
            poster = "https://image.tmdb.org/t/p/w500/w9g69U6gSpAatvveZgih9IIn.jpg",
            background = "https://image.tmdb.org/t/p/original/w9g69U6gSpAatvveZgih9IIn.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "6.2",
            genres = listOf("Animation", "Family", "Comedy"),
            primaryGenre = "Animation",
            overview = "Gru, Lucy, Margo, Edith, and Agnes welcome a new member to the family, Gru Jr."
        ),
        StremioMetaSummary(
            id = "tt13433802",
            type = "movie",
            name = "A Quiet Place: Day One",
            poster = "https://image.tmdb.org/t/p/w500/7g69U6gSpAatvveZgih9IIn.jpg",
            background = "https://image.tmdb.org/t/p/original/7g69U6gSpAatvveZgih9IIn.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "6.4",
            genres = listOf("Horror", "Sci-Fi", "Thriller"),
            primaryGenre = "Horror",
            overview = "Experience the day the world went silent."
        )
    )

    private val fallbackTop10Tv = listOf(
        StremioMetaSummary(
            id = "tt14688458",
            type = "series",
            name = "Silo",
            poster = "https://image.tmdb.org/t/p/w500/7Y6b0v9M0VWhgCgX7e87bXz0wW6.jpg",
            background = "https://image.tmdb.org/t/p/original/7Y6b0v9M0VWhgCgX7e87bXz0wW6.jpg",
            logo = null,
            releaseInfo = "2023-",
            imdbRating = "8.1",
            genres = listOf("Sci-Fi", "Drama"),
            primaryGenre = "Sci-Fi",
            overview = "Men and women live in a giant underground silo governed by strict regulations."
        ),
        StremioMetaSummary(
            id = "tt11198330",
            type = "series",
            name = "House of the Dragon",
            poster = "https://image.tmdb.org/t/p/w500/z2Y670X4ArQA966967m786U6OHI.jpg",
            background = "https://image.tmdb.org/t/p/original/z2Y670X4ArQA966967m786U6OHI.jpg",
            logo = null,
            releaseInfo = "2022-",
            imdbRating = "8.4",
            genres = listOf("Action", "Drama", "Fantasy"),
            primaryGenre = "Action",
            overview = "The story of the House Targaryen, set 200 years before the events of Game of Thrones."
        ),
        StremioMetaSummary(
            id = "tt10986410",
            type = "series",
            name = "Ted Lasso",
            poster = "https://image.tmdb.org/t/p/w500/5S069g69U6gSpAatvveZgih9IIn.jpg",
            background = "https://image.tmdb.org/t/p/original/5S069g69U6gSpAatvveZgih9IIn.jpg",
            logo = null,
            releaseInfo = "2020-2023",
            imdbRating = "8.8",
            genres = listOf("Comedy", "Drama", "Sport"),
            primaryGenre = "Comedy",
            overview = "American football coach Ted Lasso is hired to manage a British soccer team."
        ),
        StremioMetaSummary(
            id = "tt1190634",
            type = "series",
            name = "The Boys",
            poster = "https://image.tmdb.org/t/p/w500/7NsMvKUfDcx6V76F9U7p2u76F9U.jpg",
            background = "https://image.tmdb.org/t/p/original/7NsMvKUfDcx6V76F9U7p2u76F9U.jpg",
            logo = null,
            releaseInfo = "2019-",
            imdbRating = "8.7",
            genres = listOf("Action", "Sci-Fi"),
            primaryGenre = "Sci-Fi",
            overview = "A group of vigilantes set out to take down corrupt superheroes who abuse their superpowers."
        ),
        StremioMetaSummary(
            id = "tt14452718",
            type = "series",
            name = "The Bear",
            poster = "https://image.tmdb.org/t/p/w500/d976H3g936S667Ygqg4r1MvOQp0.jpg",
            background = "https://image.tmdb.org/t/p/original/d976H3g936S667Ygqg4r1MvOQp0.jpg",
            logo = null,
            releaseInfo = "2022-",
            imdbRating = "8.6",
            genres = listOf("Drama", "Comedy"),
            primaryGenre = "Drama",
            overview = "A young chef from the fine dining world returns to Chicago to run his family sandwich shop."
        ),
        StremioMetaSummary(
            id = "tt2798596",
            type = "series",
            name = "Shōgun",
            poster = "https://image.tmdb.org/t/p/w500/7O4iV6g6Y3u0vR6gygU9vR6gygU.jpg",
            background = "https://image.tmdb.org/t/p/original/7O4iV6g6Y3u0vR6gygU9vR6gygU.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "8.7",
            genres = listOf("Drama", "History", "War"),
            primaryGenre = "Drama",
            overview = "In Japan in the year 1600, Lord Yoshii Toranaga struggles for his life against rivals on the Council of Regents."
        ),
        StremioMetaSummary(
            id = "tt17729250",
            type = "series",
            name = "Presumed Innocent",
            poster = "https://image.tmdb.org/t/p/w500/9SskV7t4g4p67OHz9m9x7H5p6V7.jpg",
            background = "https://image.tmdb.org/t/p/original/9SskV7t4g4p67OHz9m9x7H5p6V7.jpg",
            logo = null,
            releaseInfo = "2024-",
            imdbRating = "7.8",
            genres = listOf("Mystery", "Drama", "Crime"),
            primaryGenre = "Mystery",
            overview = "A horrific murder upends the Chicago Prosecuting Attorney's office when one of its own is suspected of the crime."
        ),
        StremioMetaSummary(
            id = "tt12637874",
            type = "series",
            name = "Fallout",
            poster = "https://image.tmdb.org/t/p/w500/2m11g696Y3u0vR6gygU9vR6gygU.jpg",
            background = "https://image.tmdb.org/t/p/original/2m11g696Y3u0vR6gygU9vR6gygU.jpg",
            logo = null,
            releaseInfo = "2024-",
            imdbRating = "8.4",
            genres = listOf("Action", "Sci-Fi", "Adventure"),
            primaryGenre = "Action",
            overview = "In a future, post-apocalyptic Los Angeles, citizens must live in underground bunkers to protect themselves."
        ),
        StremioMetaSummary(
            id = "tt13641562",
            type = "series",
            name = "The Acolyte",
            poster = "https://image.tmdb.org/t/p/w500/ww9pAatvveZgih9IIn.jpg",
            background = "https://image.tmdb.org/t/p/original/ww9pAatvveZgih9IIn.jpg",
            logo = null,
            releaseInfo = "2024",
            imdbRating = "5.2",
            genres = listOf("Action", "Sci-Fi", "Adventure"),
            primaryGenre = "Sci-Fi",
            overview = "An investigation into a shocking crime spree pits a respected Jedi Master against a dangerous warrior."
        ),
        StremioMetaSummary(
            id = "tt7282856",
            type = "series",
            name = "Cobra Kai",
            poster = "https://image.tmdb.org/t/p/w500/77169.jpg",
            background = "https://image.tmdb.org/t/p/original/77169.jpg",
            logo = null,
            releaseInfo = "2018-",
            imdbRating = "8.5",
            genres = listOf("Action", "Comedy", "Drama"),
            primaryGenre = "Action",
            overview = "Decades after their 1984 All Valley Karate Tournament bout, a middle-aged Daniel LaRusso and Johnny Lawrence face off again."
        )
    )

    suspend fun getTmdbTop10Movies(): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val prefLang = getPreferredTmdbLang()
        val cacheKey = "tmdb_top10_movies_$prefLang"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        for (apiKey in tmdbApiKeys) {
            try {
                val trendingMoviesResponse = tmdbApiService.getTrendingMovies(apiKey, language = prefLang)
                val movieResults = trendingMoviesResponse.results ?: emptyList()
                if (movieResults.isNotEmpty()) {
                    val top10 = movieResults.take(10).mapNotNull { item ->
                        val finalImdbId = tmdbToImdbMovieMap[item.id] ?: "tmdb:${item.id}"
                        val primaryGenre = item.genreIds?.firstOrNull()?.let { tmdbGenresMap[it] } ?: "Action"
                        val finalName = item.title ?: item.name ?: ""
                        if (finalName.isBlank()) return@mapNotNull null
                        val finalPoster = item.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                        val finalBackground = item.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                        val ratingStr = item.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }

                        StremioMetaSummary(
                            id = finalImdbId,
                            type = "movie",
                            name = finalName,
                            poster = finalPoster,
                            background = finalBackground,
                            logo = null,
                            releaseInfo = null as String?,
                            imdbRating = ratingStr,
                            genres = item.genreIds?.mapNotNull { tmdbGenresMap[it] },
                            primaryGenre = primaryGenre,
                            overview = item.overview
                        )
                    }
                    if (top10.isNotEmpty()) {
                        val merged = (top10 + fallbackTop10Movies).distinctBy { it.id }.take(10)
                        memoryCache[cacheKey] = merged
                        return@withContext merged
                    }
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching TMDB top 10 movies", e)
            }
        }
        return@withContext fallbackTop10Movies
    }

    suspend fun getTmdbTop10Tv(): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val prefLang = getPreferredTmdbLang()
        val cacheKey = "tmdb_top10_tv_$prefLang"
        (memoryCache[cacheKey] as? List<StremioMetaSummary>)?.let { return@withContext it }

        for (apiKey in tmdbApiKeys) {
            try {
                val trendingTvResponse = tmdbApiService.getTrendingTv(apiKey, language = prefLang)
                val tvResults = trendingTvResponse.results ?: emptyList()
                if (tvResults.isNotEmpty()) {
                    val top10 = tvResults.take(10).mapNotNull { item ->
                        val finalImdbId = tmdbToImdbTvMap[item.id] ?: "tmdb:${item.id}"
                        val primaryGenre = item.genreIds?.firstOrNull()?.let { tmdbGenresMap[it] } ?: "Drama"
                        val finalName = item.name ?: item.title ?: ""
                        if (finalName.isBlank()) return@mapNotNull null
                        val finalPoster = item.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
                        val finalBackground = item.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                        val ratingStr = item.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }

                        StremioMetaSummary(
                            id = finalImdbId,
                            type = "series",
                            name = finalName,
                            poster = finalPoster,
                            background = finalBackground,
                            logo = null,
                            releaseInfo = null as String?,
                            imdbRating = ratingStr,
                            genres = item.genreIds?.mapNotNull { tmdbGenresMap[it] },
                            primaryGenre = primaryGenre,
                            overview = item.overview
                        )
                    }
                    if (top10.isNotEmpty()) {
                        val merged = (top10 + fallbackTop10Tv).distinctBy { it.id }.take(10)
                        memoryCache[cacheKey] = merged
                        return@withContext merged
                    }
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching TMDB top 10 TV", e)
            }
        }
        return@withContext fallbackTop10Tv
    }

    suspend fun getRelatedItems(type: String, id: String, meta: StremioMetaDetail? = null): List<StremioMetaSummary> = withContext(Dispatchers.IO) {
        val results = mutableListOf<StremioMetaSummary>()
        for (apiKey in tmdbApiKeys) {
            try {
                var tmdbId: Int? = null
                if (id.startsWith("tt")) {
                    val findResponse = tmdbApiService.findByImdbId(id, apiKey)
                    tmdbId = if (type == "series") {
                        findResponse.tvResults?.firstOrNull()?.id
                    } else {
                        findResponse.movieResults?.firstOrNull()?.id
                    }
                } else {
                    val rawId = id.removePrefix("tmdb:")
                    tmdbId = rawId.toIntOrNull()
                }

                if (tmdbId == null && meta != null) {
                    val year = meta.releaseInfo?.take(4)
                    if (type == "series") {
                        val searchTv = tmdbApiService.searchTv(meta.name, apiKey, year)
                        tmdbId = searchTv.tvResults?.firstOrNull()?.id
                    } else {
                        val searchMovie = tmdbApiService.searchMovie(meta.name, apiKey, year)
                        tmdbId = searchMovie.movieResults?.firstOrNull()?.id
                    }
                }

                if (tmdbId != null) {
                    val recResponse = if (type == "series") {
                        tmdbApiService.getTvRecommendations(tmdbId, apiKey)
                    } else {
                        tmdbApiService.getMovieRecommendations(tmdbId, apiKey)
                    }

                    val recList = recResponse.results.orEmpty().filter { !it.posterPath.isNullOrBlank() }
                    if (recList.isNotEmpty()) {
                        recList.take(15).forEach { rec ->
                            val recTitle = rec.title ?: rec.name ?: "Unknown"
                            val posterUrl = "https://image.tmdb.org/t/p/w500${rec.posterPath}"
                            val backdropUrl = rec.backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                            val firstGenreId = rec.genreIds?.firstOrNull()
                            val primaryGenre = firstGenreId?.let { tmdbGenresMap[it] } ?: if (type == "series") "TV Serija" else "Film"
                            val releaseYear = rec.releaseDate?.take(4) ?: rec.firstAirDate?.take(4)
                            val ratingStr = rec.voteAverage?.let { String.format(java.util.Locale.US, "%.1f", it) }

                            results.add(
                                StremioMetaSummary(
                                    id = "tmdb:${rec.id}",
                                    type = type,
                                    name = recTitle,
                                    poster = posterUrl,
                                    background = backdropUrl,
                                    logo = null,
                                    releaseInfo = releaseYear,
                                    imdbRating = ratingStr,
                                    genres = rec.genreIds?.mapNotNull { tmdbGenresMap[it] },
                                    primaryGenre = primaryGenre,
                                    overview = rec.overview
                                )
                            )
                        }
                        if (results.isNotEmpty()) {
                            return@withContext results
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("MovieRepository", "Error fetching recommendations from TMDB key $apiKey", e)
            }
        }

        // Fallback: Return top movies/series excluding current item
        try {
            val fallback = if (type == "series") getTopSeries() else getTopMovies()
            return@withContext fallback.filter { it.id != id }.take(12)
        } catch (e: Exception) {
            return@withContext emptyList()
        }
    }
}
