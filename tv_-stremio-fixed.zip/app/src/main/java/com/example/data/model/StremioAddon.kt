package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stremio_addons")
data class StremioAddon(
    @PrimaryKey val url: String, // Base URL of the addon (e.g. "https://v3-cinemeta.strem.io")
    val name: String,
    val description: String?,
    val icon: String?,
    val type: String, // "catalog", "stream", "both", "other"
    val isActive: Boolean = true,
    val isBuiltIn: Boolean = false
)
