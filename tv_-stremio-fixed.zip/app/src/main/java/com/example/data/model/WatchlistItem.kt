package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watchlist")
data class WatchlistItem(
    @PrimaryKey val id: String, // IMDb ID (e.g. tt1234567)
    val title: String,
    val type: String, // "movie" or "series"
    val poster: String?,
    val backdrop: String?,
    val year: String?,
    val rating: String?,
    val timestamp: Long = System.currentTimeMillis()
)
