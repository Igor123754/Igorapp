package com.example.data.network.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class StremioStreamResponse(
    val streams: List<StremioStream>?
)

@JsonClass(generateAdapter = true)
data class StremioStreamBehaviorHints(
    val notWebReady: Boolean? = null,
    val headers: Map<String, String>? = null,
    val proxyHeaders: Map<String, Map<String, String>>? = null
)

@JsonClass(generateAdapter = true)
data class StremioStream(
    val title: String?, // Descriptive name containing qualities/seeds (e.g., "1080p HEVC...")
    val name: String?,  // Addon or provider name (e.g., "Torrentio")
    val url: String?,   // HTTP direct stream link
    val externalUrl: String?,
    val ytId: String?,  // YouTube ID
    val infoHash: String?, // Torrent InfoHash
    val fileIdx: Int?,
    val headers: Map<String, String>? = null,
    val behaviorHints: StremioStreamBehaviorHints? = null
)
