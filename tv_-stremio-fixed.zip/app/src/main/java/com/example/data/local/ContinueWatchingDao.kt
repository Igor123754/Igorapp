package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ContinueWatchingItem
import kotlinx.coroutines.flow.Flow

@Dao
interface ContinueWatchingDao {
    @Query("SELECT * FROM continue_watching ORDER BY timestamp DESC")
    fun getContinueWatchingFlow(): Flow<List<ContinueWatchingItem>>

    @Query("SELECT * FROM continue_watching WHERE id = :id LIMIT 1")
    suspend fun getContinueWatchingItem(id: String): ContinueWatchingItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: ContinueWatchingItem)

    @Query("DELETE FROM continue_watching WHERE id = :id")
    suspend fun deleteContinueWatchingItem(id: String)

    @Query("DELETE FROM continue_watching")
    suspend fun clearAll()
}
