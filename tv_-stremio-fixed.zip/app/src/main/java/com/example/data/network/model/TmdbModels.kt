package com.example.data.network.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class TmdbFindResponse(
    @Json(name = "movie_results") val movieResults: List<TmdbFindResult>? = null,
    @Json(name = "tv_results") val tvResults: List<TmdbFindResult>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbFindResult(
    val id: Int = 0,
    val name: String? = null,
    val title: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    val overview: String? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null,
    @Json(name = "genre_ids") val genreIds: List<Int>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbReleaseDatesResults(
    val results: List<TmdbReleaseDateCountry>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbReleaseDateCountry(
    @Json(name = "iso_3166_1") val iso: String? = null,
    @Json(name = "release_dates") val releaseDates: List<TmdbReleaseDateItem>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbReleaseDateItem(
    val certification: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbContentRatingsResults(
    val results: List<TmdbContentRatingItem>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbContentRatingItem(
    @Json(name = "iso_3166_1") val iso: String? = null,
    val rating: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCollectionInfo(
    val id: Int = 0,
    val name: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCollectionDetails(
    val id: Int = 0,
    val name: String? = null,
    val overview: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    val parts: List<TmdbTrendingResult>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbSpokenLanguage(
    @Json(name = "english_name") val englishName: String? = null,
    @Json(name = "iso_639_1") val iso6391: String? = null,
    val name: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbProductionCountry(
    @Json(name = "iso_3166_1") val iso31661: String? = null,
    val name: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbMovieDetails(
    val id: Int = 0,
    val title: String? = null,
    val overview: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    val budget: Long? = null,
    val credits: TmdbCredits? = null,
    val images: TmdbImages? = null,
    @Json(name = "imdb_id") val imdbId: String? = null,
    val genres: List<TmdbGenre>? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null,
    @Json(name = "original_language") val originalLanguage: String? = null,
    @Json(name = "spoken_languages") val spokenLanguages: List<TmdbSpokenLanguage>? = null,
    @Json(name = "production_countries") val productionCountries: List<TmdbProductionCountry>? = null,
    @Json(name = "release_dates") val releaseDates: TmdbReleaseDatesResults? = null,
    @Json(name = "belongs_to_collection") val belongsToCollection: TmdbCollectionInfo? = null
)

@JsonClass(generateAdapter = true)
data class TmdbGenre(
    val id: Int = 0,
    val name: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCreator(
    val id: Int = 0,
    val name: String? = null,
    @Json(name = "profile_path") val profilePath: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbSeasonSummary(
    val id: Int = 0,
    @Json(name = "season_number") val seasonNumber: Int? = null,
    @Json(name = "episode_count") val episodeCount: Int? = null,
    val name: String? = null,
    val overview: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbSeasonDetails(
    val id: Int = 0,
    @Json(name = "season_number") val seasonNumber: Int? = null,
    val name: String? = null,
    val overview: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    val episodes: List<TmdbEpisode>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbEpisode(
    val id: Int = 0,
    val name: String? = null,
    val overview: String? = null,
    @Json(name = "air_date") val airDate: String? = null,
    @Json(name = "episode_number") val episodeNumber: Int? = null,
    @Json(name = "season_number") val seasonNumber: Int? = null,
    @Json(name = "still_path") val stillPath: String? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null
)

@JsonClass(generateAdapter = true)
data class TmdbTvDetails(
    val id: Int = 0,
    val name: String? = null,
    val overview: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    val credits: TmdbCredits? = null,
    val images: TmdbImages? = null,
    @Json(name = "external_ids") val externalIds: TmdbExternalIds? = null,
    val genres: List<TmdbGenre>? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null,
    @Json(name = "original_language") val originalLanguage: String? = null,
    @Json(name = "spoken_languages") val spokenLanguages: List<TmdbSpokenLanguage>? = null,
    @Json(name = "production_countries") val productionCountries: List<TmdbProductionCountry>? = null,
    @Json(name = "content_ratings") val contentRatings: TmdbContentRatingsResults? = null,
    @Json(name = "first_air_date") val firstAirDate: String? = null,
    @Json(name = "last_air_date") val lastAirDate: String? = null,
    @Json(name = "in_production") val inProduction: Boolean? = null,
    @Json(name = "episode_run_time") val episodeRunTime: List<Int>? = null,
    @Json(name = "created_by") val createdBy: List<TmdbCreator>? = null,
    @Json(name = "number_of_seasons") val numberOfSeasons: Int? = null,
    @Json(name = "number_of_episodes") val numberOfEpisodes: Int? = null,
    val seasons: List<TmdbSeasonSummary>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbExternalIds(
    @Json(name = "imdb_id") val imdbId: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbTrendingResponse(
    val results: List<TmdbTrendingResult>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbTrendingResult(
    val id: Int = 0,
    val title: String? = null,
    val name: String? = null,
    @Json(name = "media_type") val mediaType: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    val overview: String? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null,
    @Json(name = "genre_ids") val genreIds: List<Int>? = null,
    @Json(name = "release_date") val releaseDate: String? = null,
    @Json(name = "first_air_date") val firstAirDate: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCredits(
    val cast: List<TmdbCast>? = null,
    val crew: List<TmdbCrew>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCast(
    val id: Int? = null,
    val name: String? = null,
    @Json(name = "profile_path") val profilePath: String? = null,
    val character: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCrew(
    val id: Int? = null,
    val name: String? = null,
    val job: String? = null,
    val department: String? = null,
    @Json(name = "profile_path") val profilePath: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbImages(
    val logos: List<TmdbLogo>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbLogo(
    @Json(name = "file_path") val filePath: String? = null,
    @Json(name = "aspect_ratio") val aspectRatio: Double? = null,
    @Json(name = "iso_639_1") val iso: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbSearchPersonResponse(
    val results: List<TmdbPersonSearchResult>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbPersonSearchResult(
    val id: Int = 0,
    val name: String? = null,
    @Json(name = "profile_path") val profilePath: String? = null,
    @Json(name = "known_for_department") val knownForDepartment: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbPersonDetailsResponse(
    val id: Int = 0,
    val name: String? = null,
    val biography: String? = null,
    val birthday: String? = null,
    @Json(name = "place_of_birth") val placeOfBirth: String? = null,
    @Json(name = "profile_path") val profilePath: String? = null,
    @Json(name = "known_for_department") val knownForDepartment: String? = null,
    @Json(name = "combined_credits") val combinedCredits: TmdbCombinedCredits? = null,
    @Json(name = "external_ids") val externalIds: TmdbPersonExternalIds? = null
)

@JsonClass(generateAdapter = true)
data class TmdbPersonExternalIds(
    @Json(name = "imdb_id") val imdbId: String? = null,
    @Json(name = "instagram_id") val instagramId: String? = null,
    @Json(name = "twitter_id") val twitterId: String? = null
)

@JsonClass(generateAdapter = true)
data class TmdbCombinedCredits(
    val cast: List<TmdbPersonCredit>? = null,
    val crew: List<TmdbPersonCredit>? = null
)

@JsonClass(generateAdapter = true)
data class TmdbPersonCredit(
    val id: Int = 0,
    val title: String? = null,
    val name: String? = null,
    @Json(name = "media_type") val mediaType: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    val overview: String? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null,
    val character: String? = null,
    val job: String? = null,
    val department: String? = null,
    @Json(name = "release_date") val releaseDate: String? = null,
    @Json(name = "first_air_date") val firstAirDate: String? = null,
    @Json(name = "genre_ids") val genreIds: List<Int>? = null
)
