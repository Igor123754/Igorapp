package com.example.data.network.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class StremioManifest(
    val id: String,
    val name: String,
    val version: String,
    val description: String?,
    val icon: String?,
    val resources: List<String>,
    val types: List<String>,
    val idPrefixes: List<String>?,
    val catalogs: List<StremioCatalogDefinition>?
)

@JsonClass(generateAdapter = true)
data class StremioCatalogDefinition(
    val type: String,
    val id: String,
    val name: String,
    val extra: List<StremioCatalogExtra>?
)

@JsonClass(generateAdapter = true)
data class StremioCatalogExtra(
    val name: String,
    val isRequired: Boolean?,
    val options: List<String>?
)
