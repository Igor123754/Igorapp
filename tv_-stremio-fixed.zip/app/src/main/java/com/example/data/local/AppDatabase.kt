package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ContinueWatchingItem
import com.example.data.model.StremioAddon
import com.example.data.model.UserProfile
import com.example.data.model.WatchlistItem
import com.example.data.model.AvatarCatalog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [WatchlistItem::class, StremioAddon::class, ContinueWatchingItem::class, UserProfile::class], version = 4, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchlistDao(): WatchlistDao
    abstract fun addonDao(): AddonDao
    abstract fun continueWatchingDao(): ContinueWatchingDao
    abstract fun userProfileDao(): UserProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tvplus_stremio_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(AppDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    val addonDao = database.addonDao()
                    // Pre-populate with standard open Stremio addons
                    addonDao.insertAddon(
                        StremioAddon(
                            url = "https://v3-cinemeta.strem.io",
                            name = "Cinemeta Catalog",
                            description = "Official Stremio movie & series metadata provider.",
                            icon = null,
                            type = "catalog",
                            isActive = true,
                            isBuiltIn = true
                        )
                    )
                    addonDao.insertAddon(
                        StremioAddon(
                            url = "https://torrentio.strem.fun",
                            name = "Torrentio Stream Provider",
                            description = "Retrieves high-speed streaming torrent links for movie and series titles.",
                            icon = null,
                            type = "stream",
                            isActive = true,
                            isBuiltIn = true
                        )
                    )
                    addonDao.insertAddon(
                        StremioAddon(
                            url = "https://domaci-filmovi-addon.vercel.app",
                            name = "Домаћи Филмови и Серије",
                            description = "Katalog i strimovi za domaće filmove i serije.",
                            icon = null,
                            type = "both",
                            isActive = true,
                            isBuiltIn = true
                        )
                    )
                    addonDao.insertAddon(
                        StremioAddon(
                            url = "https://opensubtitles-v3.strem.io",
                            name = "OpenSubtitles v3",
                            description = "Provajder titlova za filmove i serije.",
                            icon = null,
                            type = "subtitles",
                            isActive = true,
                            isBuiltIn = true
                        )
                    )

                    // Pre-populate default profiles
                    val profileDao = database.userProfileDao()
                    if (profileDao.getProfileCount() == 0) {
                        profileDao.insertProfile(
                            UserProfile(
                                name = "Игор",
                                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
                                isPrimary = true
                            )
                        )
                        profileDao.insertProfile(
                            UserProfile(
                                name = "Милица",
                                avatarUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400",
                                isPrimary = false
                            )
                        )
                    }
                }
            }
        }
    }
}
