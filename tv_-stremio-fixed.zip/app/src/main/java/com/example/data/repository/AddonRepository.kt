package com.example.data.repository

import com.example.data.local.AddonDao
import com.example.data.model.StremioAddon
import com.example.data.network.StremioApiService
import kotlinx.coroutines.flow.Flow
import java.util.Locale

class AddonRepository(
    private val addonDao: AddonDao,
    private val apiService: StremioApiService = StremioApiService.instance
) {
    val allAddons: Flow<List<StremioAddon>> = addonDao.getAllAddons()

    suspend fun getActiveCatalogAddons(): List<StremioAddon> = addonDao.getActiveCatalogAddons()

    suspend fun getActiveStreamAddons(): List<StremioAddon> = addonDao.getActiveStreamAddons()

    suspend fun updateAddonStatus(url: String, isActive: Boolean) = addonDao.updateAddonStatus(url, isActive)

    suspend fun deleteAddonByUrl(url: String) = addonDao.deleteAddonByUrl(url)

    suspend fun insertAddon(addon: StremioAddon) = addonDao.insertAddon(addon)

    suspend fun ensureDefaultAddons() {
        try {
            val defaults = listOf(
                StremioAddon(
                    url = "https://domaci-filmovi-addon.vercel.app",
                    name = "Домаћи Филмови и Серије",
                    description = "Sistemski katalog i strimovi za domaće filmove i serije.",
                    icon = null,
                    type = "both",
                    isActive = true,
                    isBuiltIn = true
                ),
                StremioAddon(
                    url = "https://pengu.uk/zbcmxDoIwFEDRf-nsAChG-AHUgUSJDi5NoS-0trbY11aJ8d-dMIY43nNfBG1wHdCVElyElpTEGrKY9GajhNY-_zFyJyPgbEU2aDaCm7HgvWDOxxlnA3RKw6QOkGbpOvntNNl8m0tkrQbKpYPOT8qCF9RbBYaUZLlzQ1EzPKv94WjQyK0L4yXvdRWLe1I1j_pUXMXK5w2S9wc",
                    name = "Pengu Premium Streams Engine",
                    description = "Sistemski 4K motor za strane filmove i serije.",
                    icon = null,
                    type = "stream",
                    isActive = true,
                    isBuiltIn = true
                ),
                StremioAddon(
                    url = "https://torrentio.strem.fun",
                    name = "Torrentio Stream Engine",
                    description = "Sistemski motor za agregaciju najkvalitetnijih video izvora.",
                    icon = null,
                    type = "stream",
                    isActive = true,
                    isBuiltIn = true
                ),
                StremioAddon(
                    url = "https://v3-cinemeta.strem.io",
                    name = "Cinemeta Catalog",
                    description = "Sistemski katalog za globalne filmove i serije.",
                    icon = null,
                    type = "catalog",
                    isActive = true,
                    isBuiltIn = true
                ),
                StremioAddon(
                    url = "https://opensubtitles-v3.strem.io",
                    name = "OpenSubtitles v3",
                    description = "Sistemski provajder titlova za filmove i serije.",
                    icon = null,
                    type = "subtitles",
                    isActive = true,
                    isBuiltIn = true
                )
            )

            for (addon in defaults) {
                val existing = addonDao.getAddonByUrl(addon.url)
                if (existing == null) {
                    addonDao.insertAddon(addon)
                } else if (!existing.isActive) {
                    addonDao.updateAddonStatus(addon.url, true)
                }
            }
        } catch (e: Exception) {
            // Log or ignore
        }
    }

    /**
     * Validates and registers a Stremio addon by its base URL.
     * Fetches its manifest.json and parses its capabilities.
     */
    suspend fun registerAddon(baseUrl: String): Result<StremioAddon> {
        return try {
            // Normalize URL to always point to manifest.json for manifest fetch
            val normalizedUrl = baseUrl.trim().removeSuffix("/")
            val manifestUrl = if (normalizedUrl.endsWith(".json")) normalizedUrl else "$normalizedUrl/manifest.json"
            val baseAddonUrl = manifestUrl.removeSuffix("/manifest.json")

            val manifest = apiService.getManifest(manifestUrl)

            // Determine if it provides catalogs or streams
            val hasCatalog = manifest.resources.contains("catalog") || !manifest.catalogs.isNullOrEmpty()
            val hasStream = manifest.resources.contains("stream")
            
            val type = when {
                hasCatalog && hasStream -> "both"
                hasCatalog -> "catalog"
                hasStream -> "stream"
                else -> "other"
            }

            val addon = StremioAddon(
                url = baseAddonUrl,
                name = manifest.name,
                description = manifest.description ?: "Custom Stremio Addon",
                icon = manifest.icon,
                type = type,
                isActive = true,
                isBuiltIn = false
            )

            addonDao.insertAddon(addon)
            Result.success(addon)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
