package com.example.data.network.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class StremioMetaResponse(
    val meta: StremioMetaDetail?
)

@JsonClass(generateAdapter = true)
data class StremioTrailerStream(
    val title: String? = null,
    @Json(name = "ytId") val ytId: String? = null,
    @Json(name = "yt") val yt: String? = null,
    @Json(name = "source") val source: String? = null,
    val url: String? = null
) {
    fun getEffectiveYtId(): String? {
        return ytId?.takeIf { it.isNotBlank() }
            ?: yt?.takeIf { it.isNotBlank() }
            ?: source?.takeIf { it.isNotBlank() }
    }
}

@JsonClass(generateAdapter = true)
data class CastMember(
    val name: String,
    val character: String? = null,
    val role: String? = "Actor",
    val profilePic: String? = null,
    val tmdbPersonId: Int? = null
)

@JsonClass(generateAdapter = true)
data class StremioMetaLink(
    val name: String,
    val category: String,
    val url: String? = null
)

@JsonClass(generateAdapter = true)
data class StremioMetaDetail(
    val id: String,
    val type: String,
    val name: String,
    val poster: String?,
    val background: String?,
    val logo: String?,
    val releaseInfo: String?,
    val imdbRating: String?,
    val description: String?,
    val runtime: String?,
    val genres: List<String>?,
    val cast: List<String>?,
    val director: List<String>?,
    @Json(name = "directors") val directors: List<String>? = null,
    val videos: List<StremioVideo>?,
    val budget: String? = null,
    val year: String? = null,
    val country: String? = null,
    val language: String? = null,
    @Json(name = "trailers") val trailers: List<StremioTrailerStream>? = null,
    @Json(name = "trailerStreams") val trailerStreams: List<StremioTrailerStream>? = null,
    @Json(name = "trailer_yt_id") val trailer_yt_id: String? = null,
    val castMembers: List<CastMember>? = null,
    val links: List<StremioMetaLink>? = null,
    @Json(name = "certification") val certification: String? = null,
    @Json(name = "contentRating") val contentRating: String? = null,
    val collectionItems: List<StremioMetaSummary>? = null,
    val collectionName: String? = null,
    val seasonPosters: Map<Int, String>? = null
) {
    fun getEffectiveCertification(): String {
        val cert = certification?.takeIf { it.isNotBlank() }
            ?: contentRating?.takeIf { it.isNotBlank() }
        if (cert != null) return cert

        val isSeries = type == "series"
        val genreList = genres.orEmpty()
        return when {
            genreList.any { it.contains("Animation", ignoreCase = true) || it.contains("Family", ignoreCase = true) || it.contains("Children", ignoreCase = true) } -> if (isSeries) "TV-PG" else "PG"
            genreList.any { it.contains("Horror", ignoreCase = true) || it.contains("Crime", ignoreCase = true) || it.contains("Thriller", ignoreCase = true) } -> if (isSeries) "TV-MA" else "R"
            else -> if (isSeries) "TV-14" else "PG-13"
        }
    }
    fun getEffectiveCastMembers(): List<CastMember> {
        if (!castMembers.isNullOrEmpty()) return castMembers
        val result = mutableListOf<CastMember>()
        val allDirectors = (director.orEmpty() + directors.orEmpty() + links?.filter { it.category == "director" }?.map { it.name }.orEmpty()).distinct()
        allDirectors.forEach { dir ->
            if (dir.isNotBlank()) {
                result.add(CastMember(name = dir.trim(), role = "Director", character = "Reditelj"))
            }
        }
        val allCast = (cast.orEmpty() + links?.filter { it.category == "cast" || it.category == "actor" }?.map { it.name }.orEmpty()).distinct()
        allCast.forEach { actor ->
            if (actor.isNotBlank()) {
                result.add(CastMember(name = actor.trim(), role = "Actor", character = null))
            }
        }
        return result.distinctBy { it.name }
    }
}

@JsonClass(generateAdapter = true)
data class StremioVideo(
    val id: String, // Season-episode identifier: e.g. "tt0903747:1:1"
    val title: String,
    val season: Int,
    val episode: Int,
    val released: String?,
    val thumbnail: String?,
    val overview: String? = null,
    val rating: String? = null,
    @Json(name = "imdbRating") val imdbRating: String? = null
) {
    fun getEffectiveRating(fallbackMetaRating: String? = null): String? {
        val r = rating?.takeIf { it.isNotBlank() }
            ?: imdbRating?.takeIf { it.isNotBlank() }
            ?: fallbackMetaRating?.takeIf { it.isNotBlank() }
        return r?.let {
            val d = it.toDoubleOrNull()
            if (d != null && d > 0.0) {
                String.format(java.util.Locale.US, "%.1f", d)
            } else if (d == 0.0) {
                null
            } else it
        }
    }
}
