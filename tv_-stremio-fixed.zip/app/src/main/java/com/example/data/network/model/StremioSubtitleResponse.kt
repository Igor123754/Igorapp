package com.example.data.network.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class StremioSubtitleResponse(
    val subtitles: List<StremioSubtitle>? = null
)

@JsonClass(generateAdapter = true)
data class StremioSubtitle(
    val id: String? = null,
    val url: String? = null,
    val lang: String? = null,
    val language: String? = null
)
