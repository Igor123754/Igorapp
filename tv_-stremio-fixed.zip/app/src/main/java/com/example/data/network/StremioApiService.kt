package com.example.data.network

import com.example.data.network.model.StremioCatalogResponse
import com.example.data.network.model.StremioManifest
import com.example.data.network.model.StremioMetaResponse
import com.example.data.network.model.StremioStreamResponse
import com.example.data.network.model.StremioSubtitleResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Url
import java.util.concurrent.TimeUnit

interface StremioApiService {

    @GET
    suspend fun getManifest(@Url url: String): StremioManifest

    @GET
    suspend fun getCatalog(@Url url: String): StremioCatalogResponse

    @GET
    suspend fun getMetaDetail(@Url url: String): StremioMetaResponse

    @GET
    suspend fun getStreams(@Url url: String): StremioStreamResponse

    @GET
    suspend fun getSubtitles(@Url url: String): StremioSubtitleResponse

    companion object {
        private val moshi: Moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

        private val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.NONE
        }

        private val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .connectionPool(okhttp3.ConnectionPool(32, 5, TimeUnit.MINUTES))
            .addInterceptor(loggingInterceptor)
            .build()

        // Since we are using dynamic URLs, we need a placeholder base URL for Retrofit.
        private const val PLACEHOLDER_BASE_URL = "https://placeholder.com/"

        val instance: StremioApiService by lazy {
            Retrofit.Builder()
                .baseUrl(PLACEHOLDER_BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(StremioApiService::class.java)
        }
    }
}
