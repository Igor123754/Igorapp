package com.example.data.model

data class AvatarItem(
    val id: String,
    val name: String,
    val category: String,
    val url: String
)

object AvatarCatalog {
    val defaultAvatar = AvatarItem(
        id = "igor",
        name = "Игор",
        category = "Glavni",
        url = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500"
    )

    val avatars: List<AvatarItem> = listOf(
        // Glavni & Popularni Portreti
        AvatarItem("igor", "Игор", "Popularno", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500"),
        AvatarItem("milica", "Милица", "Popularno", "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500"),
        AvatarItem("portrait_male1", "Miloš", "Popularno", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500"),
        AvatarItem("portrait_female1", "Ana", "Popularno", "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=500"),
        AvatarItem("portrait_male2", "Stefan", "Popularno", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500"),
        AvatarItem("portrait_female2", "Elena", "Popularno", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500"),

        // Filmovi & Serije
        AvatarItem("cyberpunk", "Cyberpunk", "Sci-Fi", "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=500"),
        AvatarItem("neo", "Neo", "Sci-Fi", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500"),
        AvatarItem("sparrow", "Jack", "Filmovi", "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=500"),
        AvatarItem("daenerys", "Daenerys", "Serije", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500"),
        AvatarItem("jon", "Jon", "Serije", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500"),
        AvatarItem("wednesday", "Wednesday", "Serije", "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=500"),

        // High Quality Animated & Stylized
        AvatarItem("aang", "Aang", "Animirani", "https://api.dicebear.com/7.x/bottts/png?seed=Aang&backgroundColor=0288d1"),
        AvatarItem("katara", "Katara", "Animirani", "https://api.dicebear.com/7.x/bottts/png?seed=Katara&backgroundColor=0097a7"),
        AvatarItem("gojo", "Gojo", "Animirani", "https://api.dicebear.com/7.x/bottts/png?seed=GojoSatoru&backgroundColor=512da8"),
        AvatarItem("goku", "Goku", "Animirani", "https://api.dicebear.com/7.x/bottts/png?seed=Goku&backgroundColor=f57c00"),
        AvatarItem("levi", "Levi", "Animirani", "https://api.dicebear.com/7.x/bottts/png?seed=LeviAckerman&backgroundColor=303f9f"),
        AvatarItem("naruto", "Naruto", "Animirani", "https://api.dicebear.com/7.x/bottts/png?seed=Naruto&backgroundColor=ffa000"),
        AvatarItem("cyberbot", "CyberBot", "3D", "https://api.dicebear.com/7.x/bottts/png?seed=CyberBotX&backgroundColor=e50914"),
        AvatarItem("zen", "Zen Master", "3D", "https://api.dicebear.com/7.x/bottts/png?seed=ZenMaster&backgroundColor=111111")
    )
}
