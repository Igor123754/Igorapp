package com.example.data.network.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class StremioCatalogResponse(
    val metas: List<StremioMetaSummary>?
)

@JsonClass(generateAdapter = true)
data class StremioMetaSummary(
    val id: String,
    val type: String,
    val name: String,
    val poster: String?,
    val background: String?,
    val logo: String?,
    val releaseInfo: String?,
    val imdbRating: String?,
    val genres: List<String>? = null,
    val primaryGenre: String? = null,
    val overview: String? = null
)
