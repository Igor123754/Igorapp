package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.StremioAddon
import kotlinx.coroutines.flow.Flow

@Dao
interface AddonDao {
    @Query("SELECT * FROM stremio_addons")
    fun getAllAddons(): Flow<List<StremioAddon>>

    @Query("SELECT * FROM stremio_addons WHERE url = :url LIMIT 1")
    suspend fun getAddonByUrl(url: String): StremioAddon?

    @Query("SELECT * FROM stremio_addons WHERE isActive = 1")
    suspend fun getActiveAddons(): List<StremioAddon>

    @Query("SELECT * FROM stremio_addons WHERE isActive = 1 AND (type = 'catalog' OR type = 'both')")
    suspend fun getActiveCatalogAddons(): List<StremioAddon>

    @Query("SELECT * FROM stremio_addons WHERE isActive = 1 AND (type = 'stream' OR type = 'both')")
    suspend fun getActiveStreamAddons(): List<StremioAddon>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAddon(addon: StremioAddon)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAddons(addons: List<StremioAddon>)

    @Query("UPDATE stremio_addons SET isActive = :isActive WHERE url = :url")
    suspend fun updateAddonStatus(url: String, isActive: Boolean)

    @Delete
    suspend fun deleteAddon(addon: StremioAddon)

    @Query("DELETE FROM stremio_addons WHERE url = :url")
    suspend fun deleteAddonByUrl(url: String)
}
