package com.example.data.repository

import com.example.data.local.AppPreferences
import com.example.data.local.UserProfileDao
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ProfileRepository(private val userProfileDao: UserProfileDao) {

    val allProfiles: Flow<List<UserProfile>> = userProfileDao.getAllProfiles()

    private val _isProfileUnlocked = MutableStateFlow(false)
    val isProfileUnlocked: StateFlow<Boolean> = _isProfileUnlocked.asStateFlow()

    suspend fun getProfileById(id: Long): UserProfile? {
        return userProfileDao.getProfileById(id)
    }

    suspend fun createProfile(name: String, avatarUrl: String, pin: String?): Boolean {
        val count = userProfileDao.getProfileCount()
        if (count >= 6) return false

        val newProfile = UserProfile(
            name = name,
            avatarUrl = avatarUrl,
            pin = if (pin.isNull_or_empty_pin()) null else pin,
            isPrimary = (count == 0)
        )
        val id = userProfileDao.insertProfile(newProfile)
        AppPreferences.setActiveProfileId(id)
        _isProfileUnlocked.value = (pin.isNull_or_empty_pin())
        return true
    }

    private fun String?.isNull_or_empty_pin(): Boolean {
        return this.isNullOrBlank()
    }

    suspend fun updateProfile(profile: UserProfile) {
        userProfileDao.updateProfile(profile)
    }

    suspend fun deleteProfile(profile: UserProfile) {
        userProfileDao.deleteProfile(profile)
        val remaining = userProfileDao.getAllProfilesList()
        if (remaining.isNotEmpty()) {
            val activeId = AppPreferences.getActiveProfileId()
            if (activeId == profile.id) {
                AppPreferences.setActiveProfileId(remaining.first().id)
                _isProfileUnlocked.value = remaining.first().pin.isNullOrEmpty()
            }
        }
    }

    fun unlockProfile(profile: UserProfile, pinInput: String): Boolean {
        if (profile.pin.isNullOrEmpty() || profile.pin == pinInput) {
            _isProfileUnlocked.value = true
            return true
        }
        return false
    }

    fun selectProfile(profile: UserProfile) {
        AppPreferences.setActiveProfileId(profile.id)
        _isProfileUnlocked.value = profile.pin.isNullOrEmpty()
    }

    fun lockCurrentProfile() {
        _isProfileUnlocked.value = false
    }

    suspend fun ensureDefaultProfiles() {
        if (userProfileDao.getProfileCount() == 0) {
            userProfileDao.insertProfile(
                UserProfile(
                    name = "Игор",
                    avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
                    isPrimary = true
                )
            )
            userProfileDao.insertProfile(
                UserProfile(
                    name = "Милица",
                    avatarUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400",
                    isPrimary = false
                )
            )
        }
    }
}
