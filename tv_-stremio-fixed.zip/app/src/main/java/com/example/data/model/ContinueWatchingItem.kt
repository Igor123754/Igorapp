package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "continue_watching")
data class ContinueWatchingItem(
    @PrimaryKey val id: String, // IMDb ID of movie or series (e.g. tt1234567)
    val title: String, // Name of movie or series (e.g. "Breaking Bad")
    val type: String, // "movie" or "series"
    val poster: String?,
    val backdrop: String?,
    val logoUrl: String? = null,
    val episodeThumbnail: String? = null,
    val year: String?,
    val rating: String?,
    
    // Playback state info
    val lastPlayedTitle: String?, // Full title of what was played (e.g. "Breaking Bad - S1E1: Pilot")
    val lastPlayedUrl: String?, // URL of stream
    val lastPlayedVideoId: String?, // Season-episode video id if series (e.g., tt0903747:1:1)
    val season: Int? = null,
    val episode: Int? = null,
    val progress: Float = 0f, // 0.0 to 1.0
    val lastWatchedPosition: Long = 0L, // millisecond position
    val duration: Long = 0L, // millisecond duration
    
    val timestamp: Long = System.currentTimeMillis()
)
