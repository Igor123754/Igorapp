package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AppPreferences {
    private const val PREFS_NAME = "app_preferences"
    private const val KEY_LANGUAGE = "selected_language"
    private const val KEY_ACTIVE_PROFILE_ID = "active_profile_id"

    const val LANG_SR = "sr"
    const val LANG_EN = "en"

    private var sharedPreferences: SharedPreferences? = null

    private val _currentLanguage = MutableStateFlow(LANG_SR)
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _activeProfileId = MutableStateFlow<Long>(1L)
    val activeProfileId: StateFlow<Long> = _activeProfileId.asStateFlow()

    fun init(context: Context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedLang = sharedPreferences?.getString(KEY_LANGUAGE, LANG_SR) ?: LANG_SR
            _currentLanguage.value = savedLang
            val savedProfileId = sharedPreferences?.getLong(KEY_ACTIVE_PROFILE_ID, 1L) ?: 1L
            _activeProfileId.value = savedProfileId
        }
    }

    fun setActiveProfileId(profileId: Long) {
        _activeProfileId.value = profileId
        sharedPreferences?.edit()?.putLong(KEY_ACTIVE_PROFILE_ID, profileId)?.apply()
    }

    fun getActiveProfileId(): Long {
        return _activeProfileId.value
    }

    fun setLanguage(lang: String) {
        val validLang = if (lang == LANG_EN) LANG_EN else LANG_SR
        _currentLanguage.value = validLang
        sharedPreferences?.edit()?.putString(KEY_LANGUAGE, validLang)?.apply()
    }

    fun getLanguage(): String {
        return _currentLanguage.value
    }
}
