package com.example.data.repository

import com.example.data.local.ContinueWatchingDao
import com.example.data.model.ContinueWatchingItem
import kotlinx.coroutines.flow.Flow

class ContinueWatchingRepository(private val continueWatchingDao: ContinueWatchingDao) {
    val continueWatchingList: Flow<List<ContinueWatchingItem>> = continueWatchingDao.getContinueWatchingFlow()

    suspend fun getContinueWatchingItem(id: String): ContinueWatchingItem? = continueWatchingDao.getContinueWatchingItem(id)

    suspend fun insertOrUpdate(item: ContinueWatchingItem) = continueWatchingDao.insertOrUpdate(item)

    suspend fun deleteContinueWatchingItem(id: String) = continueWatchingDao.deleteContinueWatchingItem(id)

    suspend fun clearAll() = continueWatchingDao.clearAll()
}
