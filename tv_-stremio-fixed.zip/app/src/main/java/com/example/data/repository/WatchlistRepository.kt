package com.example.data.repository

import com.example.data.local.WatchlistDao
import com.example.data.model.WatchlistItem
import kotlinx.coroutines.flow.Flow

class WatchlistRepository(private val watchlistDao: WatchlistDao) {
    val watchlist: Flow<List<WatchlistItem>> = watchlistDao.getWatchlist()

    fun isInWatchlistFlow(id: String): Flow<Boolean> = watchlistDao.isInWatchlistFlow(id)

    suspend fun isInWatchlist(id: String): Boolean = watchlistDao.isInWatchlist(id)

    suspend fun addToWatchlist(item: WatchlistItem) = watchlistDao.addToWatchlist(item)

    suspend fun removeFromWatchlist(id: String) = watchlistDao.removeFromWatchlist(id)
}
