package com.example.util

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

data class SubtitleCue(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val startStr: String,
    val endStr: String,
    var text: String
)

object GeminiSubtitleEngine {

    private const val TAG = "GeminiSubtitleEngine"
    private const val GEMINI_MODEL = "gemini-3.5-flash"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Returns the Gemini API key from BuildConfig (populated from the local,
     * untracked .env file), or null if none is configured. Callers must treat
     * a null key as "feature unavailable" rather than falling back to a
     * shared/embedded key.
     */
    private fun getApiKey(): String? {
        val buildKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        return buildKey.takeIf { it.isNotBlank() && it != "MY_GEMINI_API_KEY" }
    }

    /**
     * Downloads subtitle from [subtitleUrl], parses cues, and uses Gemini AI
     * to translate/polish to Serbian and synchronize cues into a clean VTT file.
     */
    suspend fun prepareAndEnhanceSubtitle(
        context: Context,
        subtitleUrl: String,
        sourceLang: String = "auto",
        offsetMs: Long = 0L,
        onStatusUpdate: (String) -> Unit = {}
    ): File? = withContext(Dispatchers.IO) {
        try {
            onStatusUpdate("Preuzimanje titla...")
            val rawText = downloadSubtitleText(subtitleUrl)
            if (rawText.isNullOrBlank()) {
                Log.e(TAG, "Failed to download subtitle text from $subtitleUrl")
                return@withContext null
            }

            var cues = parseSubtitleCues(rawText)
            if (cues.isEmpty()) {
                Log.e(TAG, "No cues parsed from subtitle text")
                return@withContext null
            }

            val apiKey = getApiKey()
            val isEnglishOrForeign = sourceLang.lowercase(Locale.ROOT).startsWith("en") ||
                    !isSerbianLanguage(sourceLang, null)

            if (apiKey.isNullOrBlank()) {
                Log.w(TAG, "No Gemini API key configured — skipping AI subtitle enhancement")
            } else if (isEnglishOrForeign) {
                onStatusUpdate("✨ Gemini AI Prevođenje i Sinhronizacija...")
                val enhancedCues = translateAndSyncWithGemini(cues, apiKey, onStatusUpdate)
                if (enhancedCues.isNotEmpty()) {
                    cues = enhancedCues
                }
            } else {
                onStatusUpdate("✨ Gemini AI Provera Sinhronizacije...")
                val polishedCues = polishSerbianSyncWithGemini(cues, apiKey)
                if (polishedCues.isNotEmpty()) {
                    cues = polishedCues
                }
            }

            if (offsetMs != 0L) {
                cues = cues.map { cue ->
                    val newStart = (cue.startMs + offsetMs).coerceAtLeast(0L)
                    val newEnd = (cue.endMs + offsetMs).coerceAtLeast(newStart + 100L)
                    cue.copy(
                        startMs = newStart,
                        endMs = newEnd,
                        startStr = msToVttTimestamp(newStart),
                        endStr = msToVttTimestamp(newEnd)
                    )
                }
            }

            onStatusUpdate("Priprema titla za prikaz...")
            val vttContent = generateWebVttString(cues)
            val cacheFile = File(context.cacheDir, "gemini_sub_serbian.vtt")
            cacheFile.writeText(vttContent, Charsets.UTF_8)
            Log.d(TAG, "Successfully generated Gemini enhanced VTT subtitle at ${cacheFile.absolutePath}")
            cacheFile
        } catch (e: Exception) {
            Log.e(TAG, "Error enhancing subtitle with Gemini AI", e)
            null
        }
    }

    /**
     * Shifts existing cues by [offsetMs] and generates an updated local VTT file.
     */
    fun shiftSubtitleSync(
        context: Context,
        originalCues: List<SubtitleCue>,
        offsetMs: Long
    ): File? {
        return try {
            val shiftedCues = originalCues.map { cue ->
                val newStart = (cue.startMs + offsetMs).coerceAtLeast(0L)
                val newEnd = (cue.endMs + offsetMs).coerceAtLeast(newStart + 100L)
                cue.copy(
                    startMs = newStart,
                    endMs = newEnd,
                    startStr = msToVttTimestamp(newStart),
                    endStr = msToVttTimestamp(newEnd)
                )
            }
            val vttContent = generateWebVttString(shiftedCues)
            val cacheFile = File(context.cacheDir, "gemini_sub_serbian.vtt")
            cacheFile.writeText(vttContent, Charsets.UTF_8)
            cacheFile
        } catch (e: Exception) {
            Log.e(TAG, "Error shifting subtitle sync", e)
            null
        }
    }

    private fun downloadSubtitleText(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Stremio/4.4.168")
            .build()
        val response = okHttpClient.newCall(request).execute()
        return if (response.isSuccessful) {
            response.body?.string()
        } else {
            null
        }
    }

    fun parseSubtitleCues(raw: String): List<SubtitleCue> {
        val lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        val cues = mutableListOf<SubtitleCue>()

        var currentIndex = 1
        var idx = 0
        val timeRegex = Regex("""(\d{1,2}:\d{2}:\d{2}[.,]\d{3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[.,]\d{3})""")

        while (idx < lines.size) {
            val line = lines[idx].trim()
            val match = timeRegex.find(line)
            if (match != null) {
                val startStr = match.groupValues[1]
                val endStr = match.groupValues[2]
                val startMs = parseTimestampToMs(startStr)
                val endMs = parseTimestampToMs(endStr)

                idx++
                val textBuilder = StringBuilder()
                while (idx < lines.size && lines[idx].trim().isNotEmpty()) {
                    if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                    textBuilder.append(lines[idx].trim())
                    idx++
                }

                val cleanText = cleanHtmlTags(textBuilder.toString())
                if (cleanText.isNotBlank()) {
                    cues.add(
                        SubtitleCue(
                            index = currentIndex++,
                            startMs = startMs,
                            endMs = endMs,
                            startStr = msToVttTimestamp(startMs),
                            endStr = msToVttTimestamp(endMs),
                            text = cleanText
                        )
                    )
                }
            }
            idx++
        }
        return cues
    }

    private suspend fun translateAndSyncWithGemini(
        cues: List<SubtitleCue>,
        apiKey: String,
        onStatusUpdate: (String) -> Unit
    ): List<SubtitleCue> = withContext(Dispatchers.IO) {
        val chunkSize = 35
        val chunks = cues.chunked(chunkSize)
        val resultCues = mutableListOf<SubtitleCue>()

        for ((index, chunk) in chunks.withIndex()) {
            onStatusUpdate("Gemini AI Prevođenje (${index + 1}/${chunks.size})...")
            val promptBuilder = StringBuilder()
            promptBuilder.append("Prevedi sledeće titlove sa engleskog na savršeni, prirodni srpski jezik (srpska latinica). ")
            promptBuilder.append("Format izlaza mora biti numerisana lista sa identičnim brojevima [ID]. ")
            promptBuilder.append("Primer izlaza:\n[1] Zdravo, dobrodošli u film.\n[2] Kako si danas?\n\nUlaz:\n")

            chunk.forEach { cue ->
                promptBuilder.append("[${cue.index}] ${cue.text.replace("\n", " ")}\n")
            }

            val systemInstruction = "Ti si profesionalni prevodilac za Apple TV+ streaming servis. Prevedi svaku rečenicu na savremen, prirodan i gramatički ispravan srpski jezik (latinica). Sačuvaj numeraciju [ID] za svaku stavku."
            val translatedMap = callGeminiTranslationApi(apiKey, promptBuilder.toString(), systemInstruction)

            chunk.forEach { cue ->
                val translatedText = translatedMap[cue.index] ?: cue.text
                resultCues.add(cue.copy(text = translatedText))
            }
        }
        resultCues
    }

    private suspend fun polishSerbianSyncWithGemini(
        cues: List<SubtitleCue>,
        apiKey: String
    ): List<SubtitleCue> = withContext(Dispatchers.IO) {
        // Take a small sample to polish and align formatting
        val sample = cues.take(40)
        val promptBuilder = StringBuilder()
        promptBuilder.append("Popravi i uglačaj sledeće srpske titlove (isravi pravopisne/kucane greške i loše lomljenje redova):\n")
        sample.forEach { cue ->
            promptBuilder.append("[${cue.index}] ${cue.text.replace("\n", " ")}\n")
        }

        val systemInstruction = "Ti si ekspert za obradu i stilizaciju titlova za Apple TV+. Popravi pravopis, slova sa kvačicama (č, ć, š, ž, đ) i prirodan tok teksta u srpskom jeziku."
        val polishedMap = callGeminiTranslationApi(apiKey, promptBuilder.toString(), systemInstruction)

        cues.map { cue ->
            val newText = polishedMap[cue.index] ?: cue.text
            cue.copy(text = newText)
        }
    }

    private fun callGeminiTranslationApi(
        apiKey: String,
        prompt: String,
        systemInstruction: String
    ): Map<Int, String> {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent?key=$apiKey"
        val map = mutableMapOf<Int, String>()

        try {
            val jsonReq = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemInstruction))
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.3)
                })
            }

            val body = jsonReq.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val respStr = response.body?.string() ?: ""
                val respJson = JSONObject(respStr)
                val candidates = respJson.optJSONArray("candidates")
                val firstPart = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                val textOutput = firstPart?.optString("text") ?: ""

                // Parse [ID] Translated text lines
                val lineRegex = Regex("""\[(\d+)]\s*(.+)""")
                textOutput.lines().forEach { line ->
                    val match = lineRegex.find(line.trim())
                    if (match != null) {
                        val id = match.groupValues[1].toIntOrNull()
                        val content = match.groupValues[2].trim()
                        if (id != null && content.isNotBlank()) {
                            map[id] = content
                        }
                    }
                }
            } else {
                Log.e(TAG, "Gemini API call failed with code ${response.code}: ${response.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception calling Gemini API", e)
        }
        return map
    }

    private fun parseTimestampToMs(ts: String): Long {
        return try {
            val clean = ts.trim().replace(',', '.')
            val parts = clean.split(":")
            if (parts.size == 3) {
                val hours = parts[0].toLong()
                val minutes = parts[1].toLong()
                val secParts = parts[2].split(".")
                val seconds = secParts[0].toLong()
                val millis = if (secParts.size > 1) secParts[1].padEnd(3, '0').take(3).toLong() else 0L
                (hours * 3600 + minutes * 60 + seconds) * 1000 + millis
            } else if (parts.size == 2) {
                val minutes = parts[0].toLong()
                val secParts = parts[1].split(".")
                val seconds = secParts[0].toLong()
                val millis = if (secParts.size > 1) secParts[1].padEnd(3, '0').take(3).toLong() else 0L
                (minutes * 60 + seconds) * 1000 + millis
            } else 0L
        } catch (e: Exception) {
            0L
        }
    }

    private fun msToVttTimestamp(ms: Long): String {
        val hours = ms / 3600000
        val minutes = (ms % 3600000) / 60000
        val seconds = (ms % 60000) / 1000
        val millis = ms % 1000
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    }

    private fun cleanHtmlTags(input: String): String {
        return input.replace(Regex("<[^>]*>"), "").trim()
    }

    private fun generateWebVttString(cues: List<SubtitleCue>): String {
        val sb = StringBuilder("WEBVTT\n\n")
        cues.forEach { cue ->
            sb.append("${cue.index}\n")
            sb.append("${cue.startStr} --> ${cue.endStr}\n")
            sb.append("${cue.text}\n\n")
        }
        return sb.toString()
    }

    fun isSerbianLanguage(code: String?, name: String?): Boolean {
        val c = code?.lowercase(Locale.ROOT) ?: ""
        val n = name?.lowercase(Locale.ROOT) ?: ""
        return c in listOf("srp", "sr", "srb", "hrv", "hr", "bos", "bs", "cnr") ||
                n.contains("serbian") || n.contains("srpski") || n.contains("hrvatski") || n.contains("bosanski")
    }

    fun isEnglishLanguage(code: String?, name: String?): Boolean {
        val c = code?.lowercase(Locale.ROOT) ?: ""
        val n = name?.lowercase(Locale.ROOT) ?: ""
        return c in listOf("eng", "en") || n.contains("english") || n.contains("engleski")
    }
}
