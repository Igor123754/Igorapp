package com.example.trailer

import java.net.Inet4Address
import java.net.InetAddress
import okhttp3.Dns

class IPv4FirstDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        return try {
            val addresses = Dns.SYSTEM.lookup(hostname)
            val (ipv4, ipv6) = addresses.partition { it is Inet4Address }
            ipv4 + ipv6
        } catch (e: Exception) {
            Dns.SYSTEM.lookup(hostname)
        }
    }
}
