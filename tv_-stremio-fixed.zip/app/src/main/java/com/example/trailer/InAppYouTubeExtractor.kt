package com.example.trailer

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

internal const val TRAILER_EXTRACTOR_TAG = "InAppYouTubeExtractor"
internal const val TRAILER_REQUEST_TIMEOUT_MS = 20_000L

private const val EXTRACTOR_TIMEOUT_MS = 30_000L
private const val PREFERRED_SEPARATE_CLIENT = "android_vr"

private val VIDEO_ID_REGEX = Regex("^[a-zA-Z0-9_-]{11}$")
private val API_KEY_REGEX = Regex("\"INNERTUBE_API_KEY\":\"([^\"]+)\"")
private val VISITOR_DATA_REGEX = Regex("\"VISITOR_DATA\":\"([^\"]+)\"")
private val QUALITY_LABEL_REGEX = Regex("(\\d{2,4})p")

private data class YouTubeClient(
    val key: String,
    val id: String,
    val version: String,
    val userAgent: String,
    val context: JSONObject,
    val priority: Int
)

private data class WatchConfig(
    val apiKey: String?,
    val visitorData: String?
)

internal data class StreamCandidate(
    val client: String,
    val priority: Int,
    val url: String,
    val score: Double,
    val hasN: Boolean,
    val height: Int,
    val fps: Int,
    val ext: String
)

private data class ManifestBestVariant(
    val url: String,
    val width: Int,
    val height: Int,
    val bandwidth: Long
)

internal data class ManifestCandidate(
    val client: String,
    val priority: Int,
    val manifestUrl: String,
    val selectedVariantUrl: String,
    val height: Int,
    val bandwidth: Long
)

class InAppYouTubeExtractor {

    suspend fun extractPlaybackSource(youtubeUrl: String): TrailerPlaybackSource? = withContext(Dispatchers.Default) {
        if (youtubeUrl.isBlank()) return@withContext null

        runCatching {
            withTimeout(EXTRACTOR_TIMEOUT_MS) {
                extractPlaybackSourceInternal(youtubeUrl)
            }
        }.onFailure {
            Log.w(TRAILER_EXTRACTOR_TAG, "Trailer extractor failed for $youtubeUrl: ${it.message}")
        }.getOrNull()
    }

    private suspend fun extractPlaybackSourceInternal(youtubeUrl: String): TrailerPlaybackSource? {
        val videoId = extractVideoId(youtubeUrl) ?: return null

        val watchUrl = "https://www.youtube.com/watch?v=$videoId&hl=en"
        val watchResponse = runCatching {
            TrailerExtractionPlatform.performRequest(
                url = watchUrl,
                method = "GET",
                headers = TrailerExtractionPlatform.defaultHeaders,
                body = null,
                timeoutMillis = TRAILER_REQUEST_TIMEOUT_MS
            )
        }.getOrNull()

        val watchConfig = if (watchResponse != null && watchResponse.ok) {
            getWatchConfig(watchResponse.body)
        } else {
            WatchConfig(apiKey = null, visitorData = null)
        }

        val apiKey = watchConfig.apiKey ?: "AIzaSyAO_FJ2SlqU8S4p94Apd13g2O2_P_M"

        val clients = listOf(
            YouTubeClient(
                key = "android_vr",
                id = "28",
                version = "1.56.21",
                userAgent = "com.google.android.apps.youtube.vr.oculus/1.56.21 " +
                    "(Linux; U; Android 12; en_US; Quest 3; Build/SQ3A.220605.009.A1) gzip",
                context = JSONObject().apply {
                    put("clientName", "ANDROID_VR")
                    put("clientVersion", "1.56.21")
                    put("deviceMake", "Oculus")
                    put("deviceModel", "Quest 3")
                    put("osName", "Android")
                    put("osVersion", "12")
                    put("platform", "MOBILE")
                    put("androidSdkVersion", 32)
                    put("hl", "en")
                    put("gl", "US")
                },
                priority = 0
            ),
            YouTubeClient(
                key = "android",
                id = "3",
                version = "20.10.35",
                userAgent = "com.google.android.youtube/20.10.35 (Linux; U; Android 14; en_US) gzip",
                context = JSONObject().apply {
                    put("clientName", "ANDROID")
                    put("clientVersion", "20.10.35")
                    put("osName", "Android")
                    put("osVersion", "14")
                    put("platform", "MOBILE")
                    put("androidSdkVersion", 34)
                    put("hl", "en")
                    put("gl", "US")
                },
                priority = 1
            ),
            YouTubeClient(
                key = "ios",
                id = "5",
                version = "20.10.1",
                userAgent = "com.google.ios.youtube/20.10.1 (iPhone16,2; U; CPU iOS 17_4 like Mac OS X)",
                context = JSONObject().apply {
                    put("clientName", "IOS")
                    put("clientVersion", "20.10.1")
                    put("deviceModel", "iPhone16,2")
                    put("osName", "iPhone")
                    put("osVersion", "17.4.0.21E219")
                    put("platform", "MOBILE")
                    put("hl", "en")
                    put("gl", "US")
                },
                priority = 2
            )
        )

        val progressive = mutableListOf<StreamCandidate>()
        val adaptiveVideo = mutableListOf<StreamCandidate>()
        val adaptiveAudio = mutableListOf<StreamCandidate>()
        val manifestUrls = mutableListOf<Triple<String, Int, String>>()

        for (client in clients) {
            runCatching {
                val playerResponse = fetchPlayerResponse(
                    apiKey = apiKey,
                    videoId = videoId,
                    client = client,
                    visitorData = watchConfig.visitorData
                )

                val streamingData = playerResponse.optJSONObject("streamingData") ?: return@runCatching
                val hlsManifestUrl = streamingData.optString("hlsManifestUrl")
                if (!hlsManifestUrl.isNullOrBlank()) {
                    manifestUrls += Triple(client.key, client.priority, hlsManifestUrl)
                }

                val formats = streamingData.optJSONArray("formats")
                if (formats != null) {
                    for (i in 0 until formats.length()) {
                        val format = formats.optJSONObject(i) ?: continue
                        var url = format.optString("url")
                        if (url.isNullOrBlank()) {
                            url = extractUrlFromCipher(format.optString("signatureCipher").ifBlank { format.optString("cipher") })
                        }
                        if (url.isNullOrBlank()) continue
                        val mimeType = format.optString("mimeType")
                        if (!mimeType.contains("video/") && mimeType.isNotBlank()) continue

                        val height = format.optInt("height", parseQualityLabel(format.optString("qualityLabel")) ?: 0)
                        val fps = format.optInt("fps", 0)
                        val bitrate = format.optDouble("bitrate", format.optDouble("averageBitrate", 0.0))

                        progressive += StreamCandidate(
                            client = client.key,
                            priority = client.priority,
                            url = url,
                            score = videoScore(height, fps, bitrate),
                            hasN = hasNParam(url),
                            height = height,
                            fps = fps,
                            ext = if (mimeType.contains("webm")) "webm" else "mp4"
                        )
                    }
                }

                val adaptiveFormats = streamingData.optJSONArray("adaptiveFormats")
                if (adaptiveFormats != null) {
                    for (i in 0 until adaptiveFormats.length()) {
                        val format = adaptiveFormats.optJSONObject(i) ?: continue
                        var url = format.optString("url")
                        if (url.isNullOrBlank()) {
                            url = extractUrlFromCipher(format.optString("signatureCipher").ifBlank { format.optString("cipher") })
                        }
                        if (url.isNullOrBlank()) continue
                        val mimeType = format.optString("mimeType")
                        val hasVideo = mimeType.contains("video/")
                        val hasAudio = mimeType.contains("audio/") || mimeType.startsWith("audio/")

                        if (hasVideo) {
                            val height = format.optInt("height", parseQualityLabel(format.optString("qualityLabel")) ?: 0)
                            val fps = format.optInt("fps", 0)
                            val bitrate = format.optDouble("bitrate", format.optDouble("averageBitrate", 0.0))

                            adaptiveVideo += StreamCandidate(
                                client = client.key,
                                priority = client.priority,
                                url = url,
                                score = videoScore(height, fps, bitrate),
                                hasN = hasNParam(url),
                                height = height,
                                fps = fps,
                                ext = if (mimeType.contains("webm")) "webm" else "mp4"
                            )
                        } else if (hasAudio) {
                            val bitrate = format.optDouble("bitrate", format.optDouble("averageBitrate", 0.0))
                            val audioSampleRate = format.optDouble("audioSampleRate", 0.0)

                            adaptiveAudio += StreamCandidate(
                                client = client.key,
                                priority = client.priority,
                                url = url,
                                score = audioScore(bitrate, audioSampleRate),
                                hasN = hasNParam(url),
                                height = 0,
                                fps = 0,
                                ext = if (mimeType.contains("webm")) "webm" else "m4a"
                            )
                        }
                    }
                }
            }
        }

        if (manifestUrls.isEmpty() && progressive.isEmpty() && adaptiveVideo.isEmpty() && adaptiveAudio.isEmpty()) {
            return null
        }

        var bestManifest: ManifestCandidate? = null
        for ((clientKey, priority, manifestUrl) in manifestUrls) {
            runCatching {
                val variant = parseHlsManifest(manifestUrl) ?: return@runCatching
                val candidate = ManifestCandidate(
                    client = clientKey,
                    priority = priority,
                    manifestUrl = manifestUrl,
                    selectedVariantUrl = variant.url,
                    height = variant.height,
                    bandwidth = variant.bandwidth
                )
                if (
                    bestManifest == null ||
                    candidate.height > bestManifest!!.height ||
                    (candidate.height == bestManifest!!.height && candidate.bandwidth > bestManifest!!.bandwidth)
                ) {
                    bestManifest = candidate
                }
            }
        }

        val bestProgressive = sortCandidates(progressive).firstOrNull()
        val bestVideo = pickBestForClient(adaptiveVideo, PREFERRED_SEPARATE_CLIENT)
        val bestAudio = pickBestForClient(adaptiveAudio, PREFERRED_SEPARATE_CLIENT)

        return TrailerExtractionPlatform.buildPlaybackSource(
            bestManifest = bestManifest,
            bestProgressive = bestProgressive,
            bestVideo = bestVideo,
            bestAudio = bestAudio
        )
    }

    private suspend fun fetchPlayerResponse(
        apiKey: String,
        videoId: String,
        client: YouTubeClient,
        visitorData: String?
    ): JSONObject {
        val endpoint = "https://www.youtube.com/youtubei/v1/player?key=$apiKey"

        val headers = mutableMapOf<String, String>().apply {
            putAll(TrailerExtractionPlatform.defaultHeaders)
            put("content-type", "application/json")
            put("origin", "https://www.youtube.com")
            put("x-youtube-client-name", client.id)
            put("x-youtube-client-version", client.version)
            put("user-agent", client.userAgent)
            if (!visitorData.isNullOrBlank()) put("x-goog-visitor-id", visitorData)
        }

        val payload = JSONObject().apply {
            put("videoId", videoId)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
            put("context", JSONObject().apply {
                put("client", client.context)
            })
            put("playbackContext", JSONObject().apply {
                put("contentPlaybackContext", JSONObject().apply {
                    put("html5Preference", "HTML5_PREF_WANTS")
                })
            })
        }

        val response = TrailerExtractionPlatform.performRequest(
            url = endpoint,
            method = "POST",
            headers = headers,
            body = payload.toString(),
            timeoutMillis = TRAILER_REQUEST_TIMEOUT_MS
        )

        if (!response.ok) {
            val preview = response.body.take(200)
            throw IllegalStateException("player API ${client.key} failed (${response.status}): $preview")
        }

        return JSONObject(response.body)
    }

    private suspend fun parseHlsManifest(manifestUrl: String): ManifestBestVariant? {
        val response = TrailerExtractionPlatform.performRequest(
            url = manifestUrl,
            method = "GET",
            headers = TrailerExtractionPlatform.defaultHeaders,
            body = null,
            timeoutMillis = TRAILER_REQUEST_TIMEOUT_MS
        )
        if (!response.ok) {
            throw IllegalStateException("Failed to fetch HLS manifest (${response.status})")
        }

        val lines = response.body
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        var bestVariant: ManifestBestVariant? = null
        for (index in lines.indices) {
            val line = lines[index]
            if (!line.startsWith("#EXT-X-STREAM-INF:")) continue

            val attrs = parseHlsAttributeList(line)
            val nextLine = lines.getOrNull(index + 1) ?: continue
            if (nextLine.startsWith("#")) continue

            val resolution = attrs["RESOLUTION"].orEmpty()
            val (width, height) = parseResolution(resolution)
            val bandwidth = attrs["BANDWIDTH"]?.toLongOrNull() ?: 0L

            val candidate = ManifestBestVariant(
                url = absolutizeUrl(manifestUrl, nextLine),
                width = width,
                height = height,
                bandwidth = bandwidth
            )

            if (
                bestVariant == null ||
                candidate.height > bestVariant!!.height ||
                (candidate.height == bestVariant!!.height && candidate.bandwidth > bestVariant!!.bandwidth) ||
                (
                    candidate.height == bestVariant!!.height &&
                        candidate.bandwidth == bestVariant!!.bandwidth &&
                        candidate.width > bestVariant!!.width
                    )
            ) {
                bestVariant = candidate
            }
        }

        return bestVariant
    }

    private fun extractVideoId(input: String): String? {
        val trimmed = input.trim()
        if (VIDEO_ID_REGEX.matches(trimmed)) return trimmed

        val uri = runCatching { android.net.Uri.parse(trimmed) }.getOrNull() ?: return null

        val host = uri.host.orEmpty().lowercase()
        if (host.endsWith("youtu.be")) {
            val id = uri.pathSegments.firstOrNull()
            if (!id.isNullOrBlank() && VIDEO_ID_REGEX.matches(id)) {
                return id
            }
        }

        val queryId = uri.getQueryParameter("v")
        if (!queryId.isNullOrBlank() && VIDEO_ID_REGEX.matches(queryId)) {
            return queryId
        }

        val segments = uri.pathSegments
        if (segments.size >= 2) {
            val first = segments[0]
            val second = segments[1]
            if ((first == "embed" || first == "shorts" || first == "live") && VIDEO_ID_REGEX.matches(second)) {
                return second
            }
        }

        return null
    }

    private fun getWatchConfig(html: String): WatchConfig {
        val apiKey = API_KEY_REGEX.find(html)?.groupValues?.getOrNull(1)
        val visitorData = VISITOR_DATA_REGEX.find(html)?.groupValues?.getOrNull(1)
        return WatchConfig(apiKey = apiKey, visitorData = visitorData)
    }

    private fun parseHlsAttributeList(line: String): Map<String, String> {
        val index = line.indexOf(':')
        if (index == -1) return emptyMap()

        val raw = line.substring(index + 1)
        val out = LinkedHashMap<String, String>()
        val key = StringBuilder()
        val value = StringBuilder()
        var inKey = true
        var inQuote = false

        for (ch in raw) {
            if (inKey) {
                if (ch == '=') {
                    inKey = false
                } else {
                    key.append(ch)
                }
                continue
            }

            if (ch == '"') {
                inQuote = !inQuote
                continue
            }

            if (ch == ',' && !inQuote) {
                val parsedKey = key.toString().trim()
                if (parsedKey.isNotEmpty()) {
                    out[parsedKey] = value.toString().trim()
                }
                key.clear()
                value.clear()
                inKey = true
                continue
            }

            value.append(ch)
        }

        val lastKey = key.toString().trim()
        if (lastKey.isNotEmpty()) {
            out[lastKey] = value.toString().trim()
        }

        return out
    }

    private fun parseResolution(raw: String): Pair<Int, Int> {
        val parts = raw.split('x')
        if (parts.size != 2) return 0 to 0
        val width = parts[0].toIntOrNull() ?: 0
        val height = parts[1].toIntOrNull() ?: 0
        return width to height
    }

    private fun parseQualityLabel(label: String?): Int? {
        if (label.isNullOrBlank()) return null
        return QUALITY_LABEL_REGEX.find(label)?.groupValues?.getOrNull(1)?.toIntOrNull()
    }

    private fun hasNParam(url: String): Boolean {
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull()
        return uri?.getQueryParameter("n")?.isNotBlank() == true
    }

    private fun videoScore(height: Int, fps: Int, bitrate: Double): Double {
        return height * 1_000_000_000.0 + fps * 1_000_000.0 + bitrate
    }

    private fun audioScore(bitrate: Double, audioSampleRate: Double): Double {
        return bitrate * 1_000_000.0 + audioSampleRate
    }

    private fun sortCandidates(items: List<StreamCandidate>): List<StreamCandidate> {
        return items.sortedWith(
            compareByDescending<StreamCandidate> { it.score }
                .thenBy { if (it.hasN) 1 else 0 }
                .thenBy { containerPreference(it.ext) }
                .thenBy { it.priority }
        )
    }

    private fun pickBestForClient(items: List<StreamCandidate>, clientKey: String): StreamCandidate? {
        val sameClient = items.filter { it.client == clientKey }
        if (sameClient.isNotEmpty()) {
            return sortCandidates(sameClient).firstOrNull()
        }
        return sortCandidates(items).firstOrNull()
    }

    private fun containerPreference(ext: String): Int {
        return when (ext.lowercase()) {
            "mp4", "m4a" -> 0
            "webm" -> 1
            else -> 2
        }
    }

    private fun extractUrlFromCipher(cipher: String): String {
        if (cipher.isBlank()) return ""
        return runCatching {
            val params = cipher.split("&").associate {
                val parts = it.split("=")
                if (parts.size >= 2) android.net.Uri.decode(parts[0]) to android.net.Uri.decode(parts[1]) else "" to ""
            }
            val u = params["url"].orEmpty()
            val s = params["s"].orEmpty()
            val sp = params["sp"]?.ifEmpty { "sig" } ?: "sig"
            if (u.isNotBlank() && s.isBlank()) {
                u
            } else if (u.isNotBlank() && s.isNotBlank()) {
                "$u&$sp=$s"
            } else {
                ""
            }
        }.getOrDefault("")
    }

    private fun absolutizeUrl(baseUrl: String, maybeRelative: String): String {
        if (maybeRelative.startsWith("http://") || maybeRelative.startsWith("https://")) {
            return maybeRelative
        }
        if (maybeRelative.startsWith('/')) {
            val scheme = baseUrl.substringBefore("://", "https")
            val host = baseUrl.substringAfter("://", "").substringBefore('/')
            return if (host.isNotBlank()) "$scheme://$host$maybeRelative" else maybeRelative
        }
        val baseDir = baseUrl.substringBeforeLast('/', missingDelimiterValue = baseUrl)
        return "$baseDir/$maybeRelative"
    }
}
