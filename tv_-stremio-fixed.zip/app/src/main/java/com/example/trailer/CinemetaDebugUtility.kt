package com.example.trailer

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class CinemetaDiagnosticReport(
    val imdbId: String,
    val type: String,
    val title: String?,
    val trailerYtId: String?,
    val trailersList: List<TrailerEntryInfo>,
    val trailerStreamsList: List<TrailerEntryInfo>,
    val fullRawJson: String,
    val isValidTrailerFound: Boolean,
    val diagnosticSummary: String
)

data class TrailerEntryInfo(
    val title: String?,
    val ytId: String?,
    val yt: String?,
    val source: String?,
    val url: String?
)

object CinemetaDebugUtility {
    private const val TAG = "CinemetaDebug"
    private const val BASE_CINEMETA_URL = "https://v3-cinemeta.strem.io"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Fetches the full raw JSON response from Cinemeta for a given type and IMDb ID,
     * logs it completely to Logcat, parses all trailer-related fields,
     * and returns a comprehensive diagnostic report.
     */
    suspend fun inspectAndLogCinemetaResponse(
        type: String,
        imdbId: String,
        addonUrl: String? = null
    ): CinemetaDiagnosticReport = withContext(Dispatchers.IO) {
        val baseUrl = (addonUrl ?: BASE_CINEMETA_URL).removeSuffix("/")
        val endpointUrl = "$baseUrl/meta/$type/$imdbId.json"

        Log.i(TAG, "==========================================================")
        Log.i(TAG, "CINEMETA INSPECTION START for $type ID: $imdbId")
        Log.i(TAG, "Request URL: $endpointUrl")

        var rawJson = ""
        var responseCode = -1

        try {
            val request = Request.Builder()
                .url(endpointUrl)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                responseCode = response.code
                rawJson = response.body?.string().orEmpty()
            }
        } catch (e: Exception) {
            Log.e(TAG, "HTTP Request failed for Cinemeta endpoint: $endpointUrl", e)
            val errSummary = "Failed to fetch Cinemeta payload: ${e.localizedMessage}"
            return@withContext CinemetaDiagnosticReport(
                imdbId = imdbId,
                type = type,
                title = null,
                trailerYtId = null,
                trailersList = emptyList(),
                trailerStreamsList = emptyList(),
                fullRawJson = "",
                isValidTrailerFound = false,
                diagnosticSummary = errSummary
            )
        }

        Log.i(TAG, "HTTP Status: $responseCode | Response Size: ${rawJson.length} bytes")

        // Print raw JSON in 3000-char chunks to avoid Android Logcat line truncation
        Log.i(TAG, "--- FULL RAW JSON RESPONSE FROM CINEMETA ---")
        val chunkSize = 3000
        var i = 0
        while (i < rawJson.length) {
            val end = (i + chunkSize).coerceAtMost(rawJson.length)
            Log.i(TAG, rawJson.substring(i, end))
            i += chunkSize
        }
        Log.i(TAG, "--- END OF RAW JSON RESPONSE ---")

        // Parse fields
        var title: String? = null
        var trailerYtId: String? = null
        val trailersList = mutableListOf<TrailerEntryInfo>()
        val trailerStreamsList = mutableListOf<TrailerEntryInfo>()

        runCatching {
            val rootObj = JSONObject(rawJson)
            val metaObj = rootObj.optJSONObject("meta")
            if (metaObj != null) {
                title = metaObj.optString("name", null)
                trailerYtId = metaObj.optString("trailer_yt_id", null)?.takeIf { it.isNotBlank() }

                val trailersArr = metaObj.optJSONArray("trailers")
                if (trailersArr != null) {
                    for (idx in 0 until trailersArr.length()) {
                        val item = trailersArr.optJSONObject(idx) ?: continue
                        trailersList.add(
                            TrailerEntryInfo(
                                title = item.optString("title", null)?.takeIf { it.isNotBlank() },
                                ytId = item.optString("ytId", null)?.takeIf { it.isNotBlank() },
                                yt = item.optString("yt", null)?.takeIf { it.isNotBlank() },
                                source = item.optString("source", null)?.takeIf { it.isNotBlank() },
                                url = item.optString("url", null)?.takeIf { it.isNotBlank() }
                            )
                        )
                    }
                }

                val streamsArr = metaObj.optJSONArray("trailerStreams")
                if (streamsArr != null) {
                    for (idx in 0 until streamsArr.length()) {
                        val item = streamsArr.optJSONObject(idx) ?: continue
                        trailerStreamsList.add(
                            TrailerEntryInfo(
                                title = item.optString("title", null)?.takeIf { it.isNotBlank() },
                                ytId = item.optString("ytId", null)?.takeIf { it.isNotBlank() },
                                yt = item.optString("yt", null)?.takeIf { it.isNotBlank() },
                                source = item.optString("source", null)?.takeIf { it.isNotBlank() },
                                url = item.optString("url", null)?.takeIf { it.isNotBlank() }
                            )
                        )
                    }
                }
            }
        }.onFailure { err ->
            Log.e(TAG, "Error parsing Cinemeta JSON payload", err)
        }

        val effectiveYtId = trailerYtId
            ?: trailersList.firstNotNullOfOrNull { it.ytId ?: it.yt ?: it.source }
            ?: trailerStreamsList.firstNotNullOfOrNull { it.ytId ?: it.yt ?: it.source }

        val directUrl = trailersList.firstNotNullOfOrNull { it.url }
            ?: trailerStreamsList.firstNotNullOfOrNull { it.url }

        val isValidTrailerFound = !effectiveYtId.isNullOrBlank() || !directUrl.isNullOrBlank()

        val summary = StringBuilder().apply {
            appendLine("Title: $title")
            appendLine("Direct trailer_yt_id field: $trailerYtId")
            appendLine("Trailers array count: ${trailersList.size}")
            trailersList.forEachIndexed { idx, item ->
                appendLine("  [trailers #$idx] title=${item.title}, ytId=${item.ytId}, yt=${item.yt}, source=${item.source}, url=${item.url}")
            }
            appendLine("TrailerStreams array count: ${trailerStreamsList.size}")
            trailerStreamsList.forEachIndexed { idx, item ->
                appendLine("  [trailerStreams #$idx] title=${item.title}, ytId=${item.ytId}, yt=${item.yt}, source=${item.source}, url=${item.url}")
            }
            appendLine("Effective YouTube ID resolved: $effectiveYtId")
            appendLine("Direct URL resolved: $directUrl")
            appendLine("Valid trailer source present: $isValidTrailerFound")
        }.toString()

        Log.i(TAG, "--- DIAGNOSTIC SUMMARY ---")
        Log.i(TAG, summary)
        Log.i(TAG, "CINEMETA INSPECTION END for $type ID: $imdbId")
        Log.i(TAG, "==========================================================")

        CinemetaDiagnosticReport(
            imdbId = imdbId,
            type = type,
            title = title,
            trailerYtId = effectiveYtId,
            trailersList = trailersList,
            trailerStreamsList = trailerStreamsList,
            fullRawJson = rawJson,
            isValidTrailerFound = isValidTrailerFound,
            diagnosticSummary = summary
        )
    }

    /**
     * Dedicated debugging function to verify if 'trailer', 'trailer_yt_id', 'trailers', or 'trailerStreams'
     * properties exist in Cinemeta API response for a given IMDb ID.
     */
    suspend fun debugCinemetaTrailer(imdbId: String, type: String = "movie"): Boolean = withContext(Dispatchers.IO) {
        val report = inspectAndLogCinemetaResponse(type, imdbId)

        Log.d(TAG, "--------------------------------------------------")
        Log.d(TAG, "DEBUG CINEMETA TRAILER RESULT FOR ID: $imdbId")
        Log.d(TAG, "Title: ${report.title}")
        Log.d(TAG, "Valid Trailer Source Present: ${report.isValidTrailerFound}")
        Log.d(TAG, "Resolved Trailer YouTube ID: ${report.trailerYtId}")
        Log.d(TAG, "Trailers Count: ${report.trailersList.size}")
        Log.d(TAG, "TrailerStreams Count: ${report.trailerStreamsList.size}")
        Log.d(TAG, "--------------------------------------------------")

        report.isValidTrailerFound
    }
}

/**
     * Global top-level utility function to debug Cinemeta trailer response.
     */
suspend fun debugCinemetaTrailer(imdbId: String, type: String = "movie"): Boolean {
    return CinemetaDebugUtility.debugCinemetaTrailer(imdbId, type)
}

