package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.scale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tv
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MoviesScreen
import com.example.ui.screens.SeriesScreen
import com.example.ui.screens.PersonDetailScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SearchOverlayModal
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.theme.AppleBlack
import com.example.ui.theme.AppleCharcoal
import com.example.ui.theme.AppleLightGray
import com.example.ui.theme.AppleTvTheme
import com.example.ui.theme.AppleWhite
import com.example.viewmodel.DetailViewModel
import com.example.viewmodel.HomeViewModel
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.SearchViewModel

const val ROUTE_HOME = "home"
const val ROUTE_MOVIES = "movies"
const val ROUTE_SERIES = "series"
const val ROUTE_SEARCH = "search"
const val ROUTE_SETTINGS = "settings"
const val ROUTE_DETAIL = "detail/{type}/{id}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure high-performance image loader with aggressive memory & disk caching
        val imageLoader = coil.ImageLoader.Builder(this)
            .memoryCache {
                coil.memory.MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                coil.disk.DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(150L * 1024 * 1024)
                    .build()
            }
            .crossfade(true)
            .respectCacheHeaders(false)
            .build()
        coil.Coil.setImageLoader(imageLoader)

        setContent {
            AppleTvTheme {
                MainAppLayout()
            }
        }
    }
}

@Composable
fun MainAppLayout() {
    val navController = rememberNavController()
    val mainViewModel: MainViewModel = viewModel()
    val homeViewModel: HomeViewModel = viewModel()
    val detailViewModel: DetailViewModel = viewModel()
    val searchViewModel: SearchViewModel = viewModel()

    val currentPlayback by mainViewModel.currentPlayback.collectAsState()
    val activeDetailModal by mainViewModel.activeDetailModal.collectAsState()
    val activePersonModal by mainViewModel.activePersonModal.collectAsState()
    val searchOverlayOpen by mainViewModel.searchOverlayOpen.collectAsState()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Decide when to hide the Bottom Nav (inside Player and Detail/Person views)
    val isPlayerActive = currentPlayback != null
    val isDetailActive = (currentRoute != null && currentRoute.startsWith("detail")) || activeDetailModal != null || activePersonModal != null
    val showBottomNav = !isPlayerActive && !isDetailActive

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = AppleBlack
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(AppleBlack)
        ) {
            val isWideScreen = maxWidth >= 680.dp

            Row(modifier = Modifier.fillMaxSize()) {
                // Left Side: Dark-Themed Navigation Sidebar (on Wide Screens only)
                if (isWideScreen && showBottomNav) {
                    AppleTvSidebar(
                        currentRoute = currentRoute ?: ROUTE_HOME,
                        searchOverlayOpen = searchOverlayOpen,
                        mainViewModel = mainViewModel,
                        onNavigate = { route ->
                            navController.navigate(route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        onSearchClick = { mainViewModel.showSearchOverlay() }
                    )
                }

                // Main Content area (takes remaining width on wide screens)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    // Main Navigation Host
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable(ROUTE_HOME) {
                            HomeScreen(
                                mainViewModel = mainViewModel,
                                homeViewModel = homeViewModel,
                                onNavigateToDetail = { type, id ->
                                    mainViewModel.showDetailModal(type, id)
                                }
                            )
                        }
                        composable(ROUTE_MOVIES) {
                            MoviesScreen(
                                mainViewModel = mainViewModel,
                                homeViewModel = homeViewModel,
                                onNavigateToDetail = { type, id ->
                                    mainViewModel.showDetailModal(type, id)
                                }
                            )
                        }
                        composable(ROUTE_SERIES) {
                            SeriesScreen(
                                mainViewModel = mainViewModel,
                                homeViewModel = homeViewModel,
                                onNavigateToDetail = { type, id ->
                                    mainViewModel.showDetailModal(type, id)
                                }
                            )
                        }
                        composable(ROUTE_SEARCH) {
                            SearchScreen(
                                searchViewModel = searchViewModel,
                                mainViewModel = mainViewModel,
                                onNavigateToDetail = { type, id ->
                                    mainViewModel.showDetailModal(type, id)
                                }
                            )
                        }
                        composable(ROUTE_SETTINGS) {
                            SettingsScreen(mainViewModel = mainViewModel)
                        }
                        composable(
                            route = ROUTE_DETAIL,
                            arguments = listOf(
                                navArgument("type") { type = NavType.StringType },
                                navArgument("id") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val type = backStackEntry.arguments?.getString("type") ?: "movie"
                            val id = backStackEntry.arguments?.getString("id") ?: ""
                            DetailScreen(
                                type = type,
                                id = id,
                                mainViewModel = mainViewModel,
                                detailViewModel = detailViewModel,
                                onBack = {
                                    detailViewModel.reset()
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }

            // Elegant, glassmorphic Apple TV+ floating bottom navigation bar (only on mobile)
            AnimatedVisibility(
                visible = showBottomNav && !isWideScreen,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 24.dp)
            ) {
                AppleTvBottomNav(
                    currentRoute = currentRoute ?: ROUTE_HOME,
                    mainViewModel = mainViewModel,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }

            // Fullscreen dynamic detail modal overlay
            AnimatedVisibility(
                visible = activeDetailModal != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                activeDetailModal?.let { modal ->
                    DetailScreen(
                        type = modal.type,
                        id = modal.id,
                        mainViewModel = mainViewModel,
                        detailViewModel = detailViewModel,
                        onBack = {
                            detailViewModel.reset()
                            mainViewModel.dismissDetailModal()
                        }
                    )
                }
            }

            // Fullscreen dynamic person detail modal overlay
            AnimatedVisibility(
                visible = activePersonModal != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                activePersonModal?.let { modal ->
                    PersonDetailScreen(
                        personName = modal.personName,
                        tmdbPersonId = modal.tmdbPersonId,
                        initialProfilePic = modal.initialProfilePic,
                        mainViewModel = mainViewModel,
                        onBack = { mainViewModel.dismissPersonModal() },
                        onNavigateToDetail = { type, id ->
                            mainViewModel.dismissPersonModal()
                            mainViewModel.showDetailModal(type, id)
                        }
                    )
                }
            }

            // Fullscreen search overlay modal
            AnimatedVisibility(
                visible = searchOverlayOpen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                SearchOverlayModal(
                    searchViewModel = searchViewModel,
                    mainViewModel = mainViewModel,
                    onDismiss = { mainViewModel.dismissSearchOverlay() },
                    onNavigateToDetail = { type, id ->
                        mainViewModel.showDetailModal(type, id)
                    }
                )
            }

            // Fullscreen dynamic media player overlay
            AnimatedVisibility(
                visible = isPlayerActive,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                currentPlayback?.let { playback ->
                    VideoPlayerScreen(
                        title = playback.title,
                        url = playback.url,
                        headers = playback.headers,
                        availableStreams = playback.availableStreams,
                        metaName = playback.metaName,
                        metaType = playback.metaType,
                        logoUrl = playback.logoUrl,
                        season = playback.season,
                        episode = playback.episode,
                        mediaId = playback.mediaId,
                        startPosition = playback.startPosition,
                        onProgressUpdate = { position, duration ->
                            mainViewModel.updatePlaybackProgress(playback.mediaId, position, duration)
                        },
                        onBack = { mainViewModel.stopVideo() }
                    )
                }
            }
        }
    }
}

@Composable
fun AppleTvBottomNav(
    currentRoute: String,
    mainViewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val activeProfile by mainViewModel.activeProfile.collectAsState()

    val items = listOf(
        NavigationItem(ROUTE_HOME, "Početna", Icons.Default.Home),
        NavigationItem(ROUTE_MOVIES, "Filmovi", Icons.Default.Movie),
        NavigationItem(ROUTE_SERIES, "Serije", Icons.Default.Tv),
        NavigationItem(ROUTE_SETTINGS, "Profile", Icons.Default.Settings)
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .wrapContentWidth()
            .height(62.dp)
    ) {
        // Main Navigation Pill Container
        BoxWithConstraints(
            modifier = Modifier
                .width(300.dp)
                .height(62.dp)
                .clip(RoundedCornerShape(31.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF222225).copy(alpha = 0.88f),
                            Color(0xFF101012).copy(alpha = 0.95f)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.35f),
                            Color.White.copy(alpha = 0.06f)
                        )
                    ),
                    shape = RoundedCornerShape(31.dp)
                )
                .testTag("liquid_glass_navigation")
        ) {
            val containerWidth = maxWidth
            val containerHeight = maxHeight
            val paddingSide = 8.dp
            val usableWidth = containerWidth - (paddingSide * 2)
            val itemWidth = usableWidth / items.size
            val pillWidth = 66.dp
            val pillHeight = 46.dp

            val selectedIndex = items.indexOfFirst { it.route == currentRoute }
            val isMainSelected = selectedIndex >= 0

            if (isMainSelected) {
                val animatedX by animateDpAsState(
                    targetValue = paddingSide + (itemWidth * selectedIndex) + (itemWidth - pillWidth) / 2,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "liquid_glass_x"
                )

                // High-fidelity liquid glass active bubble
                Box(
                    modifier = Modifier
                        .offset(x = animatedX, y = (containerHeight - pillHeight) / 2)
                        .size(width = pillWidth, height = pillHeight)
                        .clip(RoundedCornerShape(23.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.28f),
                                    Color.White.copy(alpha = 0.08f)
                                )
                            )
                        )
                        .border(
                            width = 1.2.dp,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.55f),
                                    Color.White.copy(alpha = 0.12f)
                                )
                            ),
                            shape = RoundedCornerShape(23.dp)
                        )
                ) {
                    // Specular glossy reflection line on top half of the active glass bubble
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(20.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.28f),
                                        Color.White.copy(alpha = 0.0f)
                                    )
                                )
                            )
                    )
                }
            }

            // Navigation items row
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = paddingSide),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEachIndexed { index, item ->
                    val isSelected = currentRoute == item.route

                    val scale by animateFloatAsState(
                        targetValue = if (isSelected) 1.08f else 1.0f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "item_scale"
                    )

                    Column(
                        modifier = Modifier
                            .width(itemWidth)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onNavigate(item.route) }
                            .padding(vertical = 4.dp)
                            .scale(scale),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (item.route == ROUTE_SETTINGS && activeProfile?.avatarUrl != null) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 0.8.dp,
                                        color = if (isSelected) Color(0xFFE50914) else Color.White.copy(alpha = 0.5f),
                                        shape = CircleShape
                                    )
                                    .background(AppleBlack),
                                contentAlignment = Alignment.Center
                            ) {
                                coil.compose.AsyncImage(
                                    model = activeProfile?.avatarUrl,
                                    contentDescription = activeProfile?.name,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        } else {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = if (isSelected) AppleWhite else AppleWhite.copy(alpha = 0.55f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.5.dp))
                        Text(
                            text = item.title,
                            color = if (isSelected) AppleWhite else AppleWhite.copy(alpha = 0.55f),
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Standalone Circular Floating Glass Search Button (Matches Apple TV+ design in Image 2)
        val isSearchSelected = currentRoute == ROUTE_SEARCH
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(
                    if (isSearchSelected) {
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.32f),
                                Color.White.copy(alpha = 0.12f)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF222225).copy(alpha = 0.88f),
                                Color(0xFF101012).copy(alpha = 0.95f)
                            )
                        )
                    }
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (isSearchSelected) 0.6f else 0.35f),
                            Color.White.copy(alpha = if (isSearchSelected) 0.2f else 0.06f)
                        )
                    ),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    onNavigate(ROUTE_SEARCH)
                }
                .testTag("floating_search_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Pretraga",
                tint = AppleWhite,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

data class NavigationItem(
    val route: String,
    val title: String,
    val icon: ImageVector
)
@Composable
fun AppleTvSidebar(
    currentRoute: String,
    searchOverlayOpen: Boolean,
    mainViewModel: MainViewModel,
    onNavigate: (String) -> Unit,
    onSearchClick: () -> Unit
) {
    val activeProfile by mainViewModel.activeProfile.collectAsState()

    val items = listOf(
        NavigationItem(ROUTE_HOME, "Početna", Icons.Default.Home),
        NavigationItem(ROUTE_MOVIES, "Filmovi", Icons.Default.Movie),
        NavigationItem(ROUTE_SERIES, "Serije", Icons.Default.Tv),
        NavigationItem(ROUTE_SEARCH, "Pretraga", Icons.Default.Search),
        NavigationItem(ROUTE_SETTINGS, "Profile", Icons.Default.Settings)
    )

    Row(
        modifier = Modifier
            .width(97.dp)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF1E1E1E).copy(alpha = 0.85f),
                            Color(0xFF0C0C0C).copy(alpha = 0.95f)
                        )
                    )
                )
                .padding(vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Logo / Title
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(AppleWhite)
                    .testTag("sidebar_logo"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "tv",
                    color = Color.Black,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // Vertical Navigation Items with custom Liquid Glass active bubble
            Column(
                modifier = Modifier.weight(1f).padding(vertical = 48.dp),
                verticalArrangement = Arrangement.spacedBy(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                items.forEachIndexed { index, item ->
                    val isSelected = if (item.route == ROUTE_SEARCH) {
                        searchOverlayOpen
                    } else {
                        currentRoute == item.route && !searchOverlayOpen
                    }
                    
                    val scale by animateFloatAsState(
                        targetValue = if (isSelected) 1.15f else 1.0f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "sidebar_item_scale"
                    )

                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                if (isSelected) {
                                    Color.White.copy(alpha = 0.12f)
                                } else {
                                    Color.Transparent
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) Color.White.copy(alpha = 0.25f) else Color.Transparent,
                                shape = RoundedCornerShape(18.dp)
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                if (item.route == ROUTE_SEARCH) {
                                    onSearchClick()
                                } else {
                                    onNavigate(item.route)
                                }
                            }
                            .scale(scale)
                            .testTag("sidebar_item_${item.route}"),
                        contentAlignment = Alignment.Center
                    ) {
                        // Liquid glass glossy shine overlay
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = 0.15f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (item.route == ROUTE_SETTINGS && activeProfile?.avatarUrl != null) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .border(
                                            width = if (isSelected) 1.5.dp else 0.8.dp,
                                            color = if (isSelected) Color(0xFFE50914) else Color.White.copy(alpha = 0.5f),
                                            shape = CircleShape
                                        )
                                        .background(AppleBlack),
                                    contentAlignment = Alignment.Center
                                ) {
                                    coil.compose.AsyncImage(
                                        model = activeProfile?.avatarUrl,
                                        contentDescription = activeProfile?.name,
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = if (isSelected) AppleWhite else AppleWhite.copy(alpha = 0.45f),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.title,
                                color = if (isSelected) AppleWhite else AppleWhite.copy(alpha = 0.45f),
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Subtitle or version info at bottom
            Text(
                text = "v1.0",
                color = AppleLightGray.copy(alpha = 0.3f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Subtle right border / divider
        Box(
            modifier = Modifier
                .width(1.dp)
                .fillMaxHeight()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.22f),
                            Color.White.copy(alpha = 0.02f)
                        )
                    )
                )
        )
    }
}
