package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.network.model.StremioMetaDetail
import com.example.data.network.model.StremioMetaSummary
import com.example.data.network.model.StremioStream
import com.example.data.network.model.StremioVideo
import com.example.data.repository.MovieRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface DetailUiState {
    object Loading : DetailUiState
    data class Success(
        val meta: StremioMetaDetail,
        val streams: List<StremioStream>,
        val seasons: List<Int>,
        val selectedSeason: Int,
        val filteredEpisodes: List<StremioVideo>,
        val streamsForActiveVideo: List<StremioStream> = emptyList(),
        val isFetchingStreams: Boolean = false,
        val relatedItems: List<StremioMetaSummary> = emptyList()
    ) : DetailUiState
    data class Error(val message: String) : DetailUiState
}

class DetailViewModel(private val movieRepository: MovieRepository = MovieRepository()) : ViewModel() {

    private val _uiState = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    private var activeId: String? = null
    private var activeType: String? = null

    fun reset() {
        activeId = null
        activeType = null
        _uiState.value = DetailUiState.Loading
    }

    fun loadDetails(type: String, id: String, streamAddonUrls: List<String>, forceRefresh: Boolean = false) {
        val currentMeta = (_uiState.value as? DetailUiState.Success)?.meta
        val isSameItem = !forceRefresh && (activeId == id || currentMeta?.id == id) && _uiState.value is DetailUiState.Success
        if (isSameItem) return

        _uiState.value = DetailUiState.Loading
        activeId = id
        activeType = type

        viewModelScope.launch {
            try {
                // 1. Fetch metadata details
                val meta = movieRepository.getMetaDetail(type, id)
                if (meta == null) {
                    _uiState.value = DetailUiState.Error("Failed to load details from catalog.")
                    return@launch
                }

                if (meta.id.isNotBlank()) {
                    activeId = meta.id
                }

                // Launch fetching related items in parallel with streams
                val relatedDeferred = async { movieRepository.getRelatedItems(type, id, meta) }

                // 2. Compute seasons if it's a series
                val isSeries = type == "series" || type == "tv" || type == "show" || meta.type == "series"
                val seasons = if (isSeries && !meta.videos.isNullOrEmpty()) {
                    meta.videos.map { it.season }.distinct().sorted()
                } else {
                    emptyList()
                }

                val initialSeason = seasons.firstOrNull() ?: 1
                val filteredEpisodes = if (isSeries && !meta.videos.isNullOrEmpty()) {
                    meta.videos.filter { it.season == initialSeason }.sortedBy { it.episode }
                } else {
                    emptyList()
                }

                // 3. Fetch streams for movie OR for the initial episode if it's a series
                val streamQueryId = if (isSeries && filteredEpisodes.isNotEmpty()) {
                    filteredEpisodes.first().id
                } else {
                    id
                }

                _uiState.value = DetailUiState.Success(
                    meta = meta,
                    streams = emptyList(), // we will load them next
                    seasons = seasons,
                    selectedSeason = initialSeason,
                    filteredEpisodes = filteredEpisodes,
                    isFetchingStreams = true,
                    relatedItems = emptyList()
                )

                // Fetch streams and related items
                val queryType = if (isSeries) "series" else "movie"
                val streams = movieRepository.getStreams(queryType, streamQueryId, streamAddonUrls)
                val relatedItems = relatedDeferred.await()

                val currentSuccess = _uiState.value as? DetailUiState.Success
                if (currentSuccess != null) {
                    _uiState.value = currentSuccess.copy(
                        streams = streams,
                        streamsForActiveVideo = streams,
                        isFetchingStreams = false,
                        relatedItems = relatedItems
                    )
                }

            } catch (e: Exception) {
                _uiState.value = DetailUiState.Error(e.localizedMessage ?: "Unknown error occurred")
            }
        }
    }

    fun selectSeason(season: Int) {
        val current = _uiState.value as? DetailUiState.Success ?: return
        val meta = current.meta
        val filtered = meta.videos?.filter { it.season == season }?.sortedBy { it.episode } ?: emptyList()

        _uiState.value = current.copy(
            selectedSeason = season,
            filteredEpisodes = filtered
        )
    }

    fun loadStreamsForEpisode(video: StremioVideo, streamAddonUrls: List<String>) {
        val current = _uiState.value as? DetailUiState.Success ?: return
        viewModelScope.launch {
            _uiState.value = current.copy(isFetchingStreams = true)
            try {
                val streams = movieRepository.getStreams("series", video.id, streamAddonUrls)
                _uiState.value = current.copy(
                    streamsForActiveVideo = streams,
                    isFetchingStreams = false
                )
            } catch (e: Exception) {
                _uiState.value = current.copy(isFetchingStreams = false)
            }
        }
    }

    suspend fun fetchStreamsDirect(type: String, queryId: String, streamAddonUrls: List<String>): List<StremioStream> {
        return try {
            movieRepository.getStreams(type, queryId, streamAddonUrls)
        } catch (e: Exception) {
            emptyList()
        }
    }
}
