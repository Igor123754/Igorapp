package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MovieRepository
import com.example.data.repository.PersonDetailData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface PersonUiState {
    object Loading : PersonUiState
    data class Success(val personDetail: PersonDetailData) : PersonUiState
    data class Error(val message: String) : PersonUiState
}

class PersonViewModel(
    private val movieRepository: MovieRepository = MovieRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<PersonUiState>(PersonUiState.Loading)
    val uiState: StateFlow<PersonUiState> = _uiState.asStateFlow()

    fun loadPersonDetails(personName: String, tmdbPersonId: Int? = null, initialProfilePic: String? = null) {
        viewModelScope.launch {
            _uiState.value = PersonUiState.Loading
            val details = movieRepository.getPersonDetails(personName, tmdbPersonId, initialProfilePic)
            if (details != null) {
                val finalDetails = if (details.profilePic.isNullOrEmpty() && !initialProfilePic.isNullOrEmpty()) {
                    details.copy(profilePic = initialProfilePic)
                } else {
                    details
                }
                _uiState.value = PersonUiState.Success(finalDetails)
            } else if (!initialProfilePic.isNullOrEmpty()) {
                _uiState.value = PersonUiState.Success(
                    PersonDetailData(
                        id = tmdbPersonId ?: personName.hashCode(),
                        name = personName,
                        biography = "Podaci o biografiji za $personName trenutno nisu dostupni.",
                        profilePic = initialProfilePic,
                        knownForDepartment = "Filmski radnik",
                        moviesCast = emptyList(),
                        tvCast = emptyList(),
                        directorCredits = emptyList(),
                        producerCredits = emptyList(),
                        writerCredits = emptyList()
                    )
                )
            } else {
                _uiState.value = PersonUiState.Error("Nisu pronađeni podaci za $personName")
            }
        }
    }

    suspend fun resolveImdbId(mediaType: String, tmdbId: Int): String? {
        return movieRepository.resolveImdbId(mediaType, tmdbId)
    }
}
