package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.network.model.StremioMetaSummary
import com.example.data.repository.MovieRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.async

sealed interface HomeUiState {
    object Loading : HomeUiState
    data class Success(
        val featured: StremioMetaSummary?,
        val featuredItems: List<StremioMetaSummary>,
        val popularMovies: List<StremioMetaSummary>,
        val popularSeries: List<StremioMetaSummary>,
        val tmdbTop10Movies: List<StremioMetaSummary> = emptyList(),
        val tmdbTop10Tv: List<StremioMetaSummary> = emptyList(),
        val domaciMovies: List<StremioMetaSummary> = emptyList(),
        val domaciSeries: List<StremioMetaSummary> = emptyList()
    ) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

class HomeViewModel(private val movieRepository: MovieRepository = MovieRepository()) : ViewModel() {

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Loading)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private var lastCatalogUrl: String? = null
    private var lastLanguage: String? = null
    private var isLoaded = false
    private var loadJob: kotlinx.coroutines.Job? = null

    init {
        loadContent()
    }

    fun loadContent(catalogAddonUrl: String? = null, forceRefresh: Boolean = false) {
        val currentLang = com.example.data.local.AppPreferences.getLanguage()
        if (!forceRefresh && isLoaded && lastCatalogUrl == catalogAddonUrl && lastLanguage == currentLang && _uiState.value is HomeUiState.Success) {
            return // Skip unnecessary re-fetching if already loaded
        }

        if (!forceRefresh && loadJob?.isActive == true && lastCatalogUrl == catalogAddonUrl && lastLanguage == currentLang) {
            return // Request already in flight
        }

        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (!forceRefresh && _uiState.value !is HomeUiState.Success) {
                _uiState.value = HomeUiState.Loading
            }
            lastCatalogUrl = catalogAddonUrl
            lastLanguage = currentLang

            try {
                // STAGE 1: Fast-path initial catalog load (Movies and Series)
                val moviesDeferred = async { movieRepository.getTopMovies(catalogAddonUrl) }
                val seriesDeferred = async { movieRepository.getTopSeries(catalogAddonUrl) }

                val movies = try { moviesDeferred.await() } catch (e: Exception) { emptyList() }
                val series = try { seriesDeferred.await() } catch (e: Exception) { emptyList() }

                val initialFeatured = movies.firstOrNull() ?: series.firstOrNull()
                val initialFeaturedItems = (movies.take(3) + series.take(3)).distinctBy { it.id }.take(6)

                // If primary content is available, display immediately (~300ms) without waiting for secondary content!
                if (movies.isNotEmpty() || series.isNotEmpty()) {
                    isLoaded = true
                    _uiState.value = HomeUiState.Success(
                        featured = initialFeatured,
                        featuredItems = initialFeaturedItems,
                        popularMovies = movies,
                        popularSeries = series,
                        tmdbTop10Movies = emptyList(),
                        tmdbTop10Tv = emptyList(),
                        domaciMovies = emptyList(),
                        domaciSeries = emptyList()
                    )
                }

                // STAGE 2: Secondary rows loaded concurrently in background
                val trendingDeferred = async { movieRepository.getTrendingHeroBannerItems() }
                val tmdbMoviesDeferred = async { movieRepository.getTmdbTop10Movies() }
                val tmdbSeriesDeferred = async { movieRepository.getTmdbTop10Tv() }
                val domaciMoviesDeferred = async { movieRepository.getDomaciMovies() }
                val domaciSeriesDeferred = async { movieRepository.getDomaciSeries() }

                val trendingItems = try { trendingDeferred.await() } catch (e: Exception) { emptyList() }
                val tmdbMovies = try { tmdbMoviesDeferred.await() } catch (e: Exception) { emptyList() }
                val tmdbSeries = try { tmdbSeriesDeferred.await() } catch (e: Exception) { emptyList() }
                val domaciMovies = try { domaciMoviesDeferred.await() } catch (e: Exception) { emptyList() }
                val domaciSeries = try { domaciSeriesDeferred.await() } catch (e: Exception) { emptyList() }

                val finalFeaturedItems = if (trendingItems.isNotEmpty()) {
                    trendingItems
                } else if (initialFeaturedItems.isNotEmpty()) {
                    initialFeaturedItems
                } else {
                    (movies.take(3) + series.take(3)).distinctBy { it.id }.take(6)
                }

                isLoaded = true
                _uiState.value = HomeUiState.Success(
                    featured = initialFeatured,
                    featuredItems = finalFeaturedItems,
                    popularMovies = movies,
                    popularSeries = series,
                    tmdbTop10Movies = tmdbMovies,
                    tmdbTop10Tv = tmdbSeries,
                    domaciMovies = domaciMovies,
                    domaciSeries = domaciSeries
                )
            } catch (e: Exception) {
                if (_uiState.value !is HomeUiState.Success) {
                    _uiState.value = HomeUiState.Error(e.localizedMessage ?: "Unknown error occurred")
                }
            }
        }
    }
}
