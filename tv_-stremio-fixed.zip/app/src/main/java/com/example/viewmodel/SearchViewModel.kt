package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.network.model.StremioMetaSummary
import com.example.data.repository.MovieRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch

sealed interface SearchUiState {
    object Idle : SearchUiState
    object Loading : SearchUiState
    data class Success(val results: List<StremioMetaSummary>) : SearchUiState
    data class Error(val message: String) : SearchUiState
}

class SearchViewModel(private val movieRepository: MovieRepository = MovieRepository()) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _selectedType = MutableStateFlow("all") // "all", "movie", or "series"
    val selectedType: StateFlow<String> = _selectedType.asStateFlow()

    private val _selectedAddonUrl = MutableStateFlow<String?>(null)
    val selectedAddonUrl: StateFlow<String?> = _selectedAddonUrl.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    init {
        setupSearchDebounce()
    }

    @OptIn(FlowPreview::class)
    private fun setupSearchDebounce() {
        viewModelScope.launch {
            _query
                .debounce(500)
                .distinctUntilChanged()
                .collect { q ->
                    if (q.isBlank()) {
                        _uiState.value = SearchUiState.Idle
                    } else {
                        performSearch(q, _selectedType.value, _selectedAddonUrl.value)
                    }
                }
        }
    }

    fun onQueryChanged(newQuery: String) {
        _query.value = newQuery
    }

    fun onTypeChanged(type: String) {
        _selectedType.value = type
        if (_query.value.isNotBlank()) {
            performSearch(_query.value, type, _selectedAddonUrl.value)
        }
    }

    fun onAddonChanged(addonUrl: String?) {
        _selectedAddonUrl.value = addonUrl
        if (_query.value.isNotBlank()) {
            performSearch(_query.value, _selectedType.value, addonUrl)
        }
    }

    fun performSearch(q: String, type: String, addonUrl: String? = _selectedAddonUrl.value) {
        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            try {
                val results = movieRepository.searchCatalog(q, type, addonUrl)
                _uiState.value = SearchUiState.Success(results)
            } catch (e: Exception) {
                _uiState.value = SearchUiState.Error(e.localizedMessage ?: "Unknown search error")
            }
        }
    }
}
