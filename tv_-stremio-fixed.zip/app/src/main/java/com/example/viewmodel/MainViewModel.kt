package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.model.ContinueWatchingItem
import com.example.data.model.StremioAddon
import com.example.data.network.model.StremioStream
import com.example.data.model.WatchlistItem
import com.example.data.repository.AddonRepository
import com.example.data.repository.ContinueWatchingRepository
import com.example.data.repository.MovieRepository
import com.example.data.repository.ProfileRepository
import com.example.data.repository.WatchlistRepository
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlaybackInfo(
    val title: String,
    val url: String,
    val mediaId: String,
    val isMock: Boolean = false,
    val headers: Map<String, String>? = null,
    val availableStreams: List<StremioStream> = emptyList(),
    
    // Continue watching metadata
    val metaName: String? = null,
    val metaType: String? = null,
    val poster: String? = null,
    val backdrop: String? = null,
    val logoUrl: String? = null,
    val episodeThumbnail: String? = null,
    val year: String? = null,
    val rating: String? = null,
    val season: Int? = null,
    val episode: Int? = null,
    val episodeId: String? = null,
    val startPosition: Long = 0L
)

data class DetailModalInfo(
    val type: String,
    val id: String
)

data class PersonModalInfo(
    val personName: String,
    val tmdbPersonId: Int? = null,
    val initialProfilePic: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val currentLanguage: StateFlow<String> = AppPreferences.currentLanguage

    fun setLanguage(lang: String) {
        AppPreferences.setLanguage(lang)
    }

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    
    val watchlistRepository = WatchlistRepository(database.watchlistDao())
    val addonRepository = AddonRepository(database.addonDao())
    val movieRepository = MovieRepository()
    val continueWatchingRepository = ContinueWatchingRepository(database.continueWatchingDao())
    val profileRepository = ProfileRepository(database.userProfileDao())

    init {
        AppPreferences.init(application)
        viewModelScope.launch {
            try {
                addonRepository.ensureDefaultAddons()
                profileRepository.ensureDefaultProfiles()
            } catch (e: Exception) {
                // Log or ignore
            }
        }
    }

    val allProfiles: StateFlow<List<UserProfile>> = profileRepository.allProfiles
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeProfileId: StateFlow<Long> = AppPreferences.activeProfileId

    val activeProfile: StateFlow<UserProfile?> = combine(allProfiles, activeProfileId) { profiles, id ->
        profiles.find { it.id == id } ?: profiles.firstOrNull()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val isProfileUnlocked: StateFlow<Boolean> = profileRepository.isProfileUnlocked

    fun selectProfile(profile: UserProfile) {
        profileRepository.selectProfile(profile)
    }

    fun unlockActiveProfile(pinInput: String): Boolean {
        val current = activeProfile.value ?: return false
        return profileRepository.unlockProfile(current, pinInput)
    }

    fun createProfile(name: String, avatarUrl: String, pin: String? = null) {
        viewModelScope.launch {
            profileRepository.createProfile(name, avatarUrl, pin)
        }
    }

    fun updateProfile(profile: UserProfile) {
        viewModelScope.launch {
            profileRepository.updateProfile(profile)
        }
    }

    fun deleteProfile(profile: UserProfile) {
        viewModelScope.launch {
            profileRepository.deleteProfile(profile)
        }
    }

    fun lockCurrentProfile() {
        profileRepository.lockCurrentProfile()
    }

    val watchlist: StateFlow<List<WatchlistItem>> = watchlistRepository.watchlist
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val continueWatchingList: StateFlow<List<ContinueWatchingItem>> = continueWatchingRepository.continueWatchingList
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val addons: StateFlow<List<StremioAddon>> = addonRepository.allAddons
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentPlayback = MutableStateFlow<PlaybackInfo?>(null)
    val currentPlayback: StateFlow<PlaybackInfo?> = _currentPlayback.asStateFlow()

    private val _activeDetailModal = MutableStateFlow<DetailModalInfo?>(null)
    val activeDetailModal: StateFlow<DetailModalInfo?> = _activeDetailModal.asStateFlow()

    private val _activePersonModal = MutableStateFlow<PersonModalInfo?>(null)
    val activePersonModal: StateFlow<PersonModalInfo?> = _activePersonModal.asStateFlow()

    private val _searchOverlayOpen = MutableStateFlow(false)
    val searchOverlayOpen: StateFlow<Boolean> = _searchOverlayOpen.asStateFlow()

    fun showSearchOverlay() {
        _searchOverlayOpen.value = true
    }

    fun dismissSearchOverlay() {
        _searchOverlayOpen.value = false
    }

    fun showDetailModal(type: String, id: String) {
        _activeDetailModal.value = DetailModalInfo(type, id)
    }

    fun dismissDetailModal() {
        _activeDetailModal.value = null
    }

    fun showPersonModal(personName: String, tmdbPersonId: Int? = null, initialProfilePic: String? = null) {
        _activePersonModal.value = PersonModalInfo(personName, tmdbPersonId, initialProfilePic)
    }

    fun dismissPersonModal() {
        _activePersonModal.value = null
    }

    fun playVideo(
        title: String,
        url: String,
        mediaId: String,
        isMock: Boolean = false,
        headers: Map<String, String>? = null,
        availableStreams: List<StremioStream> = emptyList(),
        metaName: String? = null,
        metaType: String? = null,
        poster: String? = null,
        backdrop: String? = null,
        logoUrl: String? = null,
        episodeThumbnail: String? = null,
        year: String? = null,
        rating: String? = null,
        season: Int? = null,
        episode: Int? = null,
        episodeId: String? = null
    ) {
        viewModelScope.launch {
            val existing = continueWatchingRepository.getContinueWatchingItem(mediaId)
            val startPosition = existing?.lastWatchedPosition ?: 0L

            _currentPlayback.value = PlaybackInfo(
                title = title,
                url = url,
                mediaId = mediaId,
                isMock = isMock,
                headers = headers,
                availableStreams = availableStreams,
                metaName = metaName,
                metaType = metaType,
                poster = poster,
                backdrop = backdrop,
                logoUrl = logoUrl,
                episodeThumbnail = episodeThumbnail,
                year = year,
                rating = rating,
                season = season,
                episode = episode,
                episodeId = episodeId,
                startPosition = startPosition
            )

            // Automatically save to Continue Watching if we have metaName
            if (!isMock && !metaName.isNullOrEmpty()) {
                saveOrUpdateContinueWatching(
                    id = mediaId,
                    title = metaName,
                    type = metaType ?: "movie",
                    poster = poster,
                    backdrop = backdrop,
                    logoUrl = logoUrl,
                    episodeThumbnail = episodeThumbnail,
                    year = year,
                    rating = rating,
                    lastPlayedTitle = title,
                    lastPlayedUrl = url,
                    lastPlayedVideoId = episodeId,
                    season = season,
                    episode = episode,
                    progress = existing?.progress ?: 0f,
                    lastWatchedPosition = startPosition,
                    duration = existing?.duration ?: 0L
                )
            }
        }
    }

    fun saveOrUpdateContinueWatching(
        id: String,
        title: String,
        type: String,
        poster: String?,
        backdrop: String?,
        logoUrl: String? = null,
        episodeThumbnail: String? = null,
        year: String?,
        rating: String?,
        lastPlayedTitle: String?,
        lastPlayedUrl: String?,
        lastPlayedVideoId: String? = null,
        season: Int? = null,
        episode: Int? = null,
        progress: Float = 0f,
        lastWatchedPosition: Long = 0L,
        duration: Long = 0L
    ) {
        viewModelScope.launch {
            val existing = continueWatchingRepository.getContinueWatchingItem(id)
            val updated = ContinueWatchingItem(
                id = id,
                title = title,
                type = type,
                poster = poster ?: existing?.poster,
                backdrop = backdrop ?: existing?.backdrop,
                logoUrl = logoUrl ?: existing?.logoUrl,
                episodeThumbnail = episodeThumbnail ?: existing?.episodeThumbnail,
                year = year ?: existing?.year,
                rating = rating ?: existing?.rating,
                lastPlayedTitle = lastPlayedTitle,
                lastPlayedUrl = lastPlayedUrl,
                lastPlayedVideoId = lastPlayedVideoId ?: existing?.lastPlayedVideoId,
                season = season ?: existing?.season,
                episode = episode ?: existing?.episode,
                progress = progress,
                lastWatchedPosition = lastWatchedPosition,
                duration = duration,
                timestamp = System.currentTimeMillis()
            )
            continueWatchingRepository.insertOrUpdate(updated)
        }
    }

    fun updatePlaybackProgress(mediaId: String, position: Long, duration: Long) {
        viewModelScope.launch {
            val item = continueWatchingRepository.getContinueWatchingItem(mediaId)
            if (item != null && duration > 0L) {
                val progress = position.toFloat() / duration.toFloat()
                val updated = item.copy(
                    progress = progress.coerceIn(0f, 1f),
                    lastWatchedPosition = position,
                    duration = duration,
                    timestamp = System.currentTimeMillis()
                )
                continueWatchingRepository.insertOrUpdate(updated)
            }
        }
    }

    fun removeFromContinueWatching(id: String) {
        viewModelScope.launch {
            continueWatchingRepository.deleteContinueWatchingItem(id)
        }
    }

    fun stopVideo() {
        _currentPlayback.value = null
    }

    fun toggleAddon(url: String, isActive: Boolean) {
        viewModelScope.launch {
            addonRepository.updateAddonStatus(url, isActive)
        }
    }

    fun deleteAddon(url: String) {
        viewModelScope.launch {
            addonRepository.deleteAddonByUrl(url)
        }
    }

    fun toggleWatchlist(item: WatchlistItem, isInList: Boolean) {
        viewModelScope.launch {
            if (isInList) {
                watchlistRepository.removeFromWatchlist(item.id)
            } else {
                watchlistRepository.addToWatchlist(item.copy(timestamp = System.currentTimeMillis()))
            }
        }
    }
}
